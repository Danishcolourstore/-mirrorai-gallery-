import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  studioName?: string;
  eventName?: string;
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export const GalleryInstallPrompt = ({ studioName, eventName }: Props) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Don't show if already dismissed this session
    if (sessionStorage.getItem('pwa_prompt_dismissed') === 'true') return;

    // Don't show if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) return;

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // Slight delay so it doesn't pop immediately on load
      setTimeout(() => setVisible(true), 3000);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setVisible(false);
    }
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    sessionStorage.setItem('pwa_prompt_dismissed', 'true');
    setDismissed(true);
    setVisible(false);
  };

  if (!visible || dismissed) return null;

  return (
    <div
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-sm"
      style={{
        animation: 'slideUp 0.35s cubic-bezier(0.16,1,0.3,1)',
      }}
    >
      <div className="bg-card border border-border rounded-lg shadow-xl px-4 py-3.5 flex items-center gap-3">

        {/* Icon */}
        <div className="w-9 h-9 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
          <Download className="h-4 w-4 text-primary" />
        </div>

        {/* Text */}
        <div className="flex-1 min-w-0">
          <p className="text-[12px] font-semibold text-foreground font-sans leading-tight truncate">
            {eventName ? `Save ${eventName}` : 'Add to Home Screen'}
          </p>
          <p className="text-[10px] text-muted-foreground/60 font-sans mt-0.5 leading-tight">
            {studioName
              ? `Quick access to your gallery by ${studioName}`
              : 'Quick access to your gallery'}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <Button
            onClick={handleInstall}
            size="sm"
            className="h-7 px-3 text-[10px] tracking-[0.08em] uppercase font-semibold rounded-sm"
          >
            Install
          </Button>
          <button
            onClick={handleDismiss}
            aria-label="Dismiss install prompt"
            className="w-6 h-6 flex items-center justify-center text-muted-foreground/40 hover:text-muted-foreground/70 transition-colors"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      </div><style>{`
        @keyframes slideUp {
          from { opacity: 0; transform: translate(-50%, 16px); }
          to   { opacity: 1; transform: translate(-50%, 0); }
        }
      `}</style>
    </div>
  );
};

export default GalleryInstallPrompt;
