

## Problem Analysis

The Google OAuth is currently using `lovable.auth.signInWithOAuth("google", ...)` from `@lovable.dev/cloud-auth-js`, which is the **correct** approach for this Lovable Cloud project. The user's suggestion to switch to raw `supabase.auth.signInWithOAuth` would actually break things — Lovable Cloud manages Google OAuth automatically.

The likely issue is that after the Google OAuth redirect completes and the session is set, the app doesn't properly detect the new session and redirect the user. The `handleGoogleLogin` sets loading to false immediately, but the OAuth flow redirects the browser — so when the user returns, the `AuthRoute` component needs to pick up the session.

### Root Causes

1. **`setGoogleLoading(false)` in `finally` block resets loading state before the redirect happens** — the `lovable.auth.signInWithOAuth` returns a `result.redirected` flag, but the code still hits `finally` and resets the loading spinner before the browser navigates away. This can cause a brief flash or confusion.

2. **After OAuth redirect back, the session is set but the `AuthRoute` redirect logic may not fire** — if the user lands back on `/login`, the `AuthRoute` component checks for `user` and redirects. This should work, but the `useEffect` dependency array includes `[user, loading]` which is correct.

3. **No visible error feedback if the OAuth token exchange fails** — the `lovable` module catches errors internally but the Auth page may not display them properly since the page reloads.

### Plan

1. **Fix `handleGoogleLogin` to not reset loading on redirect** — check `result.redirected` and skip the `finally` block reset when the browser is navigating away.

2. **Add URL error parameter handling on Auth page mount** — after OAuth redirect failure, check URL for error params and display them.

3. **Improve error display** — ensure any OAuth error from the Lovable module is shown clearly with a toast AND inline error message.

4. **Keep using `lovable.auth.signInWithOAuth`** — do NOT switch to raw Supabase OAuth as that would break the Lovable Cloud managed Google integration.

5. **Do NOT touch** `/dashboard/book`, email/password login, or the lovable integration file.

### Changes

**File: `src/pages/Auth.tsx`**
- Update `handleGoogleLogin` to handle `result.redirected` properly — don't reset loading state if the browser is about to redirect
- Add `useEffect` on mount to check URL hash/params for OAuth errors (e.g., `error_description`) and display them
- Add toast notification for OAuth errors in addition to inline error display

**No new routes needed** — the Lovable Cloud auth module handles the OAuth callback internally via `/~oauth`. No `/auth/callback` route is needed.

**No Supabase config changes needed** — Google OAuth is managed automatically by Lovable Cloud.

