import { supabase } from '@/integrations/supabase/client';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 3000;
const DB_INSERT_RETRIES = 3;
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const UPLOAD_TIMEOUT = 120_000; // 2 minutes per upload

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function connectionError() {
  return new Error('Cannot connect to upload server. Check your internet connection.');
}

async function getSessionToken() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Not authenticated — please log in again');
  return session.access_token;
}

async function parseJsonSafe(res: Response) {
  return res.json().catch(() => ({} as Record<string, any>));
}

async function fetchWithTimeout(input: RequestInfo | URL, init: RequestInit = {}, timeoutMs = 15000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(input, {
      ...init,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timer);
  }
}

export async function testUploadServerConnection(): Promise<void> {
  const token = await getSessionToken();
  console.log('[R2Upload] Connection test: starting');

  let res: Response;
  try {
    res = await fetchWithTimeout(`${SUPABASE_URL}/functions/v1/upload-to-r2`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ ping: true }),
    }, 10_000);
  } catch (e) {
    console.error('[R2Upload] Connection test failed (network)', e);
    throw connectionError();
  }

  if (!res.ok) {
    const err = await parseJsonSafe(res);
    console.error('[R2Upload] Connection test failed (server)', { status: res.status, err });
    throw connectionError();
  }

  console.log('[R2Upload] Connection test: OK');
}

/**
 * Upload flow:
 * 1) request presigned URL from upload-to-r2
 * 2) PUT file directly to R2 with XHR + progress
 * 3) insert metadata into photos table (with dedicated DB retries)
 */
export async function uploadPhotoToR2(
  file: File | Blob,
  fileName: string,
  eventId: string,
  userId: string,
  onProgress?: (loaded: number, total: number) => void,
): Promise<string> {
  if (file.size > MAX_FILE_SIZE) {
    throw new Error(`File too large. Max 50MB per photo. "${fileName}" is ${(file.size / (1024 * 1024)).toFixed(1)}MB.`);
  }

  const contentType = file.type || 'image/jpeg';
  const token = await getSessionToken();

  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      console.log(`[R2Upload] Step 1: Requesting presigned URL for "${fileName}" (attempt ${attempt})`);
      const presignRes = await fetchWithTimeout(`${SUPABASE_URL}/functions/v1/upload-to-r2`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ fileName, contentType, eventId }),
      }, 15_000);

      if (!presignRes.ok) {
        const errBody = await parseJsonSafe(presignRes);
        console.error('[R2Upload] Step 1 FAIL', { status: presignRes.status, errBody });
        throw new Error('Server error. Please try again.');
      }

      const { presignedUrl, publicUrl } = await parseJsonSafe(presignRes);
      if (!presignedUrl || !publicUrl) {
        console.error('[R2Upload] Step 1 FAIL: missing presignedUrl/publicUrl', { presignedUrl, publicUrl });
        throw new Error('Server error. Please try again.');
      }
      console.log('[R2Upload] Step 1 OK', { fileName, publicUrl });

      console.log(`[R2Upload] Step 2: PUT to R2 for "${fileName}" (${(file.size / 1024 / 1024).toFixed(1)}MB)`);
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('PUT', presignedUrl);
        xhr.setRequestHeader('Content-Type', contentType);
        xhr.timeout = UPLOAD_TIMEOUT;

        if (onProgress) {
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) onProgress(e.loaded, e.total);
          };
        }

        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            console.log('[R2Upload] Step 2 OK', { fileName, status: xhr.status });
            resolve();
            return;
          }

          const responseSnippet = xhr.responseText?.substring(0, 200) || '';
          console.error('[R2Upload] Step 2 FAIL', { fileName, status: xhr.status, responseSnippet });

          if (xhr.status === 403) {
            reject(new Error('Storage auth error. Contact support.'));
          } else if (xhr.status === 413) {
            reject(new Error('File too large. Max 50MB per photo.'));
          } else {
            reject(new Error(`Upload failed (HTTP ${xhr.status}). ${responseSnippet}`.trim()));
          }
        };

        xhr.onerror = () => {
          console.error('[R2Upload] Step 2 FAIL: network error', { fileName });
          reject(new Error('Connection timeout. Check your internet.'));
        };

        xhr.ontimeout = () => {
          console.error('[R2Upload] Step 2 FAIL: timeout', { fileName, timeoutMs: UPLOAD_TIMEOUT });
          reject(new Error('Connection timeout. Check your internet.'));
        };

        xhr.send(file);
      });

      console.log(`[R2Upload] Step 3: Insert metadata for "${fileName}"`);
      let insertError: Error | null = null;

      for (let dbAttempt = 1; dbAttempt <= DB_INSERT_RETRIES; dbAttempt++) {
        const { error } = await supabase.from('photos').insert({
          event_id: eventId,
          user_id: userId,
          url: publicUrl,
          file_name: fileName,
          file_size: file.size,
        });

        if (!error) {
          console.log('[R2Upload] Step 3 OK', { fileName, dbAttempt });
          return publicUrl;
        }

        insertError = new Error(error.message);
        console.error('[R2Upload] Step 3 FAIL', { fileName, dbAttempt, error });
        if (dbAttempt < DB_INSERT_RETRIES) {
          await sleep(1000 * dbAttempt);
        }
      }

      throw new Error(`Photo uploaded, but database save failed after retries: ${insertError?.message || 'Unknown DB error'}`);
    } catch (err: any) {
      lastError = err instanceof Error ? err : new Error(String(err));
      console.warn(`[R2Upload] Attempt ${attempt}/${MAX_RETRIES} failed for "${fileName}":`, lastError.message);

      if (lastError.message.includes('File too large')) {
        throw lastError;
      }

      if (attempt < MAX_RETRIES) {
        await sleep(RETRY_DELAY_MS * attempt);
      }
    }
  }

  throw lastError || new Error('Upload failed after retries');
}

