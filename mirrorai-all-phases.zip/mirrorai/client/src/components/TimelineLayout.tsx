import { useState, useEffect, useRef, useCallback } from 'react';
import { Heart, Download, Share2, Trash2, ChevronUp } from 'lucide-react';

interface Photo {
  id: string;
  url: string;
  is_favorite: boolean;
  file_name: string | null;
  section?: string | null;
}

interface TimelineLayoutProps {
  photos: Photo[];
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string) => void;
  canDownload?: boolean;
  isOwner?: boolean;
  onDelete?: (photo: Photo) => void;
  onShare?: (photo: Photo) => void;
  onDownload?: (photo: Photo) => void;
  watermarkText?: string | null;
  onPhotoClick?: (photoId: string) => void;
}

const DEFAULT_SECTIONS = ['Getting Ready', 'Ceremony', 'Reception', 'Highlights'];

export function TimelineLayout({
  photos, isFavorite, toggleFavorite, canDownload = false, isOwner = false,
  onDelete, onShare, onDownload, watermarkText, onPhotoClick,
}: TimelineLayoutProps) {
  const [activeSection, setActiveSection] = useState(0);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const sectionRefs = useRef<(HTMLDivElement | null)[]>([]);
  const navRef = useRef<HTMLDivElement>(null);

  // Group photos by section
  const sectionMap = new Map<string, Photo[]>();
  for (const photo of photos) {
    const section = photo.section || 'Highlights';
    if (!sectionMap.has(section)) sectionMap.set(section, []);
    sectionMap.get(section)!.push(photo);
  }

  // Use available sections or defaults
  const sections = sectionMap.size > 0
    ? Array.from(sectionMap.keys())
    : DEFAULT_SECTIONS;

  // Track scroll position
  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300);
      
      // Find which section is in view
      for (let i = sectionRefs.current.length - 1; i >= 0; i--) {
        const ref = sectionRefs.current[i];
        if (ref) {
          const rect = ref.getBoundingClientRect();
          if (rect.top <= 120) {
            setActiveSection(i);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (index: number) => {
    sectionRefs.current[index]?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const getSectionEmoji = (name: string) => {
    const lower = name.toLowerCase();
    if (lower.includes('getting ready')) return '🌅';
    if (lower.includes('ceremony')) return '💍';
    if (lower.includes('reception')) return '🎊';
    if (lower.includes('highlight')) return '✨';
    if (lower.includes('family')) return '👨‍👩‍👧‍👦';
    return '📸';
  };

  return (
    <div className="relative">
      {/* Sticky section navigation */}
      <div ref={navRef} className="sticky top-0 z-20 bg-background/95 backdrop-blur-sm border-b border-border/50">
        <div className="flex items-center gap-0 overflow-x-auto scrollbar-hide px-2 sm:px-4">
          {sections.map((section, i) => (
            <button
              key={section}
              onClick={() => scrollToSection(i)}
              className={`shrink-0 px-4 py-3 text-[11px] tracking-[0.08em] uppercase transition-colors border-b-[1.5px] -mb-px whitespace-nowrap ${
                activeSection === i
                  ? 'border-foreground text-foreground font-medium'
                  : 'border-transparent text-muted-foreground/50 hover:text-muted-foreground'
              }`}
            >
              {section}
            </button>
          ))}
        </div>
      </div>

      {/* Sections */}
      <div className="space-y-0">
        {sections.map((section, si) => {
          const sectionPhotos = sectionMap.get(section) || [];
          if (sectionPhotos.length === 0) return null;

          return (
            <div
              key={section}
              ref={(el) => { sectionRefs.current[si] = el; }}
              className="pt-8 pb-4"
            >
              {/* Section divider */}
              <div className="relative flex items-center justify-center mb-6 px-6">
                <div className="absolute inset-x-6 h-px bg-border/60" />
                <div className="relative bg-background px-4 flex items-center gap-2">
                  <span className="text-lg">{getSectionEmoji(section)}</span>
                  <h2 className="font-serif text-xl sm:text-2xl font-light text-foreground tracking-tight">{section}</h2>
                </div>
              </div>
              <div className="px-4 sm:px-6 mb-2">
                <p className="text-[11px] text-muted-foreground/50 font-sans">
                  {sectionPhotos.length} moment{sectionPhotos.length !== 1 ? 's' : ''}
                </p>
                <div className="w-8 h-[1.5px] bg-gold mt-2" />
              </div>

              {/* Photo grid — masonry */}
              <div className="columns-2 sm:columns-3 gap-[2px] sm:gap-[3px] px-0">
                {sectionPhotos.map((photo) => {
                  const fav = isFavorite(photo.id);
                  return (
                    <div key={photo.id} className="group relative mb-[2px] sm:mb-[3px] break-inside-avoid cursor-pointer"
                      onClick={() => onPhotoClick?.(photo.id)}>
                      <img src={photo.url} alt="" className="w-full block" loading="lazy" />
                      {watermarkText && (
                        <div className="absolute bottom-0 right-0 p-2 pointer-events-none select-none">
                          <span className="font-sans text-white/[0.25] text-[9px] tracking-[0.15em]">{watermarkText}</span>
                        </div>
                      )}
                      <button onClick={(e) => { e.stopPropagation(); toggleFavorite(photo.id); }}
                        className="absolute top-2 right-2 z-10 w-8 h-8 rounded-full bg-white/[0.85] backdrop-blur flex items-center justify-center transition-all duration-200 hover:bg-white active:scale-125">
                        <Heart className={`h-[18px] w-[18px] transition-all ${fav ? 'text-gold scale-110' : 'text-foreground/50'}`}
                          fill={fav ? 'hsl(var(--gold))' : 'none'} />
                      </button>
                      <div className="absolute bottom-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {onShare && <button onClick={(e) => { e.stopPropagation(); onShare(photo); }}
                          className="rounded-full bg-card/70 backdrop-blur-sm p-1.5"><Share2 className="h-3.5 w-3.5" /></button>}
                        {canDownload && onDownload && <button onClick={(e) => { e.stopPropagation(); onDownload(photo); }}
                          className="rounded-full bg-card/70 backdrop-blur-sm p-1.5"><Download className="h-3.5 w-3.5" /></button>}
                        {isOwner && onDelete && <button onClick={(e) => { e.stopPropagation(); onDelete(photo); }}
                          className="rounded-full bg-card/70 backdrop-blur-sm p-1.5 text-destructive"><Trash2 className="h-3.5 w-3.5" /></button>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Back to top */}
      {showBackToTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-24 right-4 z-30 w-10 h-10 rounded-full bg-gold text-foreground flex items-center justify-center shadow-lg transition-all hover:opacity-90 active:scale-95"
        >
          <ChevronUp className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}
