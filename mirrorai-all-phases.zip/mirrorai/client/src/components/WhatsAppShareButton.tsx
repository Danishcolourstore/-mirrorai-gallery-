import { Share2 } from 'lucide-react';

interface Props {
  eventSlug: string;
  pin?: string | null;
  className?: string;
  variant?: 'icon' | 'button';
}

export function WhatsAppShareButton({ eventSlug, pin, className = '', variant = 'button' }: Props) {
  const url = `${window.location.origin}/event/${eventSlug}`;
  let text = `See your forever. 🤍\n${url}`;
  if (pin) {
    text = `See your forever. 🤍\n${url}\nPassword: ${pin}`;
  }
  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;

  const handleClick = () => {
    window.open(whatsappUrl, '_blank');
  };

  if (variant === 'icon') {
    return (
      <button onClick={handleClick} className={`text-muted-foreground/60 hover:text-foreground transition-colors ${className}`} title="Share on WhatsApp">
        <Share2 className="h-4 w-4" />
      </button>
    );
  }

  return (
    <button onClick={handleClick}
      className={`inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.08em] text-primary hover:text-primary/80 transition-colors font-medium ${className}`}>
      <Share2 className="h-3.5 w-3.5" /> Share on WhatsApp
    </button>
  );
}
