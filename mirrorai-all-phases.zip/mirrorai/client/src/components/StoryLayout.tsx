import { useState, useEffect, useRef, useCallback } from 'react';
import { Heart, Download } from 'lucide-react';

interface Photo {
  id: string;
  url: string;
  is_favorite: boolean;
  file_name: string | null;
}

interface StoryLayoutProps {
  photos: Photo[];
  isFavorite: (id: string) => boolean;
  toggleFavorite: (id: string) => void;
  canDownload?: boolean;
  onDownload?: (photo: Photo) => void;
  watermarkText?: string | null;
}

export function StoryLayout({
  photos, isFavorite, toggleFavorite, canDownload = false, onDownload, watermarkText,
}: StoryLayoutProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const [heartBurst, setHeartBurst] = useState<string | null>(null);
  const lastTapRef = useRef<number>(0);

  // Scroll observer to track current photo
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            const idx = Number(entry.target.getAttribute('data-index'));
            if (!isNaN(idx)) setCurrentIndex(idx);
          }
        }
      },
      { root: container, threshold: 0.6 }
    );

    const slides = container.querySelectorAll('[data-index]');
    slides.forEach((slide) => observer.observe(slide));
    return () => observer.disconnect();
  }, [photos.length]);

  // Double tap to heart
  const handleTap = (photoId: string) => {
    const now = Date.now();
    if (now - lastTapRef.current < 350) {
      toggleFavorite(photoId);
      setHeartBurst(photoId);
      setTimeout(() => setHeartBurst(null), 800);
    }
    lastTapRef.current = now;
  };

  // Keyboard navigation
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const container = containerRef.current;
      if (!container) return;
      if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
        const next = Math.min(currentIndex + 1, photos.length - 1);
        const slide = container.querySelector(`[data-index="${next}"]`);
        slide?.scrollIntoView({ behavior: 'smooth' });
      } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
        const prev = Math.max(currentIndex - 1, 0);
        const slide = container.querySelector(`[data-index="${prev}"]`);
        slide?.scrollIntoView({ behavior: 'smooth' });
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [currentIndex, photos.length]);

  const scrollProgress = photos.length > 1 ? ((currentIndex) / (photos.length - 1)) * 100 : 100;

  return (
    <div
      ref={containerRef}
      className="h-[100dvh] overflow-y-auto snap-y snap-mandatory"
      style={{ scrollSnapType: 'y mandatory' }}
    >
      {photos.map((photo, i) => {
        const fav = isFavorite(photo.id);
        return (
          <div
            key={photo.id}
            data-index={i}
            className="relative h-[100dvh] w-full snap-start snap-always overflow-hidden"
            onClick={() => handleTap(photo.id)}
          >
            {/* Photo */}
            <img
              src={photo.url}
              alt=""
              className={`h-full w-full object-cover ${i === 0 ? 'animate-[ken-burns_1.5s_ease-out_forwards]' : ''}`}
              style={i === 0 ? { transform: 'scale(1.05)', animation: 'ken-burns 1.5s ease-out forwards' } : undefined}
              loading={i < 3 ? 'eager' : 'lazy'}
            />

            {/* Bottom gradient overlay */}
            <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />

            {/* Watermark */}
            {watermarkText && (
              <div className="absolute bottom-0 right-0 p-3 pointer-events-none">
                <span className="font-sans text-white/[0.2] text-[9px] tracking-[0.15em]">{watermarkText}</span>
              </div>
            )}

            {/* Photo counter */}
            <div className="absolute bottom-6 right-6 z-10">
              <span className="font-serif text-[13px] text-white/60 tracking-[0.2em]">
                {String(i + 1).padStart(2, '0')} / {String(photos.length).padStart(2, '0')}
              </span>
            </div>

            {/* Actions — bottom left */}
            <div className="absolute bottom-6 left-6 z-10 flex items-center gap-3">
              <button
                onClick={(e) => { e.stopPropagation(); toggleFavorite(photo.id); }}
                className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white transition-all hover:bg-white/20 active:scale-110"
              >
                <Heart className={`h-5 w-5 ${fav ? 'text-gold' : ''}`} fill={fav ? 'currentColor' : 'none'} />
              </button>
              {canDownload && onDownload && (
                <button
                  onClick={(e) => { e.stopPropagation(); onDownload(photo); }}
                  className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white transition-all hover:bg-white/20"
                >
                  <Download className="h-5 w-5" />
                </button>
              )}
            </div>

            {/* Double tap heart burst */}
            {heartBurst === photo.id && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                <Heart className="h-20 w-20 text-gold animate-ping" fill="currentColor" />
              </div>
            )}
          </div>
        );
      })}

      {/* Progress indicator — right edge */}
      <div className="fixed right-1.5 top-1/2 -translate-y-1/2 z-30 h-[30vh] w-[3px] rounded-full bg-white/10 overflow-hidden pointer-events-none">
        <div
          className="w-full bg-gold rounded-full transition-all duration-300"
          style={{ height: `${scrollProgress}%` }}
        />
      </div>
    </div>
  );
}
