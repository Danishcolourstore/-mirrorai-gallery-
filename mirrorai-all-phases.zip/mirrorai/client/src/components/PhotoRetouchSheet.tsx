import { useState, useRef, useEffect, useCallback } from 'react';
import { retouchPhoto, type RetouchType } from '@/lib/retouchService';
import { supabase } from '@/integrations/supabase/client';
import { X, Download, Sparkles } from 'lucide-react';

interface PhotoRetouchSheetProps {
  open: boolean;
  onClose: () => void;
  photoUrl: string;
  photoId: string;
  eventId: string;
  eventTitle?: string;
  studioName?: string;
  retouchLimit: number;
}

type Step = 'options' | 'processing' | 'result';

function getRetouchCount(eventId: string): number {
  return parseInt(localStorage.getItem(`retouch_${eventId}_count`) || '0', 10);
}
function incrementRetouchCount(eventId: string) {
  const c = getRetouchCount(eventId) + 1;
  localStorage.setItem(`retouch_${eventId}_count`, String(c));
}

export function PhotoRetouchSheet({
  open, onClose, photoUrl, photoId, eventId, eventTitle, studioName, retouchLimit,
}: PhotoRetouchSheetProps) {
  const [step, setStep] = useState<Step>('options');
  const [selected, setSelected] = useState<RetouchType | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [sliderPos, setSliderPos] = useState(50);
  const [dragging, setDragging] = useState(false);
  const [autoPlayed, setAutoPlayed] = useState(false);

  const remaining = retouchLimit - getRetouchCount(eventId);
  const limitReached = remaining <= 0;

  // Reset on open
  useEffect(() => {
    if (open) {
      setStep('options');
      setSelected(null);
      setResultUrl(null);
      setError('');
      setProgress(0);
      setSliderPos(50);
      setAutoPlayed(false);
    }
  }, [open]);

  // Progress animation during processing
  useEffect(() => {
    if (step !== 'processing') return;
    setProgress(0);
    const start = Date.now();
    const duration = 2500;
    const frame = () => {
      const elapsed = Date.now() - start;
      const p = Math.min(elapsed / duration, 1);
      setProgress(p * 100);
      if (p < 1) requestAnimationFrame(frame);
    };
    requestAnimationFrame(frame);
  }, [step]);

  // Auto-play slider reveal
  useEffect(() => {
    if (step === 'result' && !autoPlayed) {
      setAutoPlayed(true);
      let start: number;
      const animate = (ts: number) => {
        if (!start) start = ts;
        const elapsed = ts - start;
        const t = Math.min(elapsed / 1500, 1);
        // 30 → 70 → 50
        let pos: number;
        if (t < 0.4) pos = 30 + (40 * (t / 0.4));
        else if (t < 0.7) pos = 70 - (20 * ((t - 0.4) / 0.3));
        else pos = 50;
        setSliderPos(pos);
        if (t < 1) requestAnimationFrame(animate);
      };
      requestAnimationFrame(animate);
    }
  }, [step, autoPlayed]);

  const handleEnhance = async () => {
    if (!selected || limitReached) return;
    setStep('processing');
    setError('');
    try {
      const url = await retouchPhoto(photoUrl, selected);
      setResultUrl(url);
      incrementRetouchCount(eventId);

      // Log to database
      const sessionId = localStorage.getItem('guest_session_id') || 'anonymous';
      await supabase.from('retouch_logs').insert({
        photo_id: photoId,
        event_id: eventId,
        retouch_type: selected,
        session_id: sessionId,
        status: 'complete',
        api_response_url: url,
      } as any);

      setStep('result');
    } catch {
      setError('Enhancement failed. Please try again.');
      setStep('options');
    }
  };

  const handleDownload = () => {
    if (!resultUrl) return;
    const a = document.createElement('a');
    a.href = resultUrl;
    a.download = `${eventTitle || 'photo'}_retouched.jpg`;
    a.click();
  };

  // Slider drag handlers
  const updateSlider = useCallback((clientX: number) => {
    if (!sliderRef.current) return;
    const rect = sliderRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    setSliderPos((x / rect.width) * 100);
  }, []);

  const onPointerDown = (e: React.PointerEvent) => {
    setDragging(true);
    updateSlider(e.clientX);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => { if (dragging) updateSlider(e.clientX); };
  const onPointerUp = () => setDragging(false);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60]">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />

      {/* ── OPTIONS STEP ── */}
      {step === 'options' && (
        <div className="absolute bottom-0 left-0 right-0 bg-[#111] rounded-t-2xl max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-300">
          <div className="flex justify-center pt-3 pb-1">
            <div className="w-10 h-1 rounded-full bg-white/20" />
          </div>
          <button onClick={onClose} className="absolute top-4 right-4 text-white/40 hover:text-white">
            <X className="h-5 w-5" />
          </button>

          <div className="px-6 pb-8 pt-4">
            <h2 className="font-['Cormorant_Garamond'] text-2xl text-white font-light text-center">
              Retouch your photo
            </h2>
            <p className="text-center text-white/40 text-xs font-sans mt-1.5">
              Professional editing. Realistic results.
            </p>

            <div className="grid grid-cols-2 gap-3 mt-8">
              {/* Retouch Card */}
              <button
                onClick={() => setSelected('retouch')}
                disabled={limitReached}
                className={`text-left p-5 rounded-lg border transition-all ${
                  selected === 'retouch'
                    ? 'border-[#C9A96E] bg-[#C9A96E]/5'
                    : 'border-[#2A2A2A] bg-[#1A1A1A] hover:border-[#3A3A3A]'
                } ${limitReached ? 'opacity-40 cursor-not-allowed' : ''}`}
              >
                <span className="text-2xl">🪞</span>
                <p className="text-white text-sm font-medium mt-3">Retouch</p>
                <p className="text-white/35 text-[10px] mt-1.5 leading-relaxed">
                  Clean skin<br />Remove blemishes<br />Natural finish
                </p>
              </button>

              {/* Dodge & Burn Card */}
              <button
                onClick={() => setSelected('dodge_burn')}
                disabled={limitReached}
                className={`text-left p-5 rounded-lg border transition-all ${
                  selected === 'dodge_burn'
                    ? 'border-[#C9A96E] bg-[#C9A96E]/5'
                    : 'border-[#2A2A2A] bg-[#1A1A1A] hover:border-[#3A3A3A]'
                } ${limitReached ? 'opacity-40 cursor-not-allowed' : ''}`}
              >
                <span className="text-2xl">🌗</span>
                <p className="text-white text-sm font-medium mt-3">Dodge & Burn</p>
                <p className="text-white/35 text-[10px] mt-1.5 leading-relaxed">
                  Natural depth<br />Light & shadow<br />Pro finish
                </p>
              </button>
            </div>

            {limitReached ? (
              <div className="text-center mt-6 space-y-1">
                <p className="text-white/50 text-xs">You've used all your free retouches</p>
                <p className="text-white/30 text-[10px]">Contact {studioName || 'the photographer'} for more</p>
              </div>
            ) : (
              <p className="text-center text-[#C9A96E]/70 text-[11px] mt-6">
                ✨ {remaining} retouch{remaining !== 1 ? 'es' : ''} remaining
              </p>
            )}

            {error && <p className="text-red-400 text-xs text-center mt-3">{error}</p>}

            <button
              onClick={handleEnhance}
              disabled={!selected || limitReached}
              className={`w-full mt-6 py-4 rounded-lg text-[13px] font-medium tracking-wider transition-all ${
                selected && !limitReached
                  ? 'bg-[#C9A96E] text-[#1A1A1A] hover:bg-[#B8935A]'
                  : 'bg-white/10 text-white/30 cursor-not-allowed'
              }`}
            >
              Enhance Now →
            </button>
          </div>
        </div>
      )}

      {/* ── PROCESSING STEP ── */}
      {step === 'processing' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <div className="relative w-full max-w-md mx-auto px-4">
            <div className="relative rounded-lg overflow-hidden">
              <img src={photoUrl} alt="" className="w-full opacity-60" />
              {/* Scanning line */}
              <div
                className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#C9A96E] to-transparent"
                style={{
                  top: `${progress}%`,
                  boxShadow: '0 0 20px rgba(201,169,110,0.6)',
                  transition: 'top 0.1s linear',
                }}
              />
            </div>

            <div className="text-center mt-6 space-y-2">
              {studioName && (
                <p className="text-white/30 text-[10px] font-sans tracking-widest uppercase">{studioName}</p>
              )}
              <p className="font-['Cormorant_Garamond'] text-white text-xl">Enhancing your photo</p>
              <div className="flex justify-center gap-1">
                {[0, 1, 2].map(i => (
                  <span
                    key={i}
                    className="w-1.5 h-1.5 rounded-full bg-[#C9A96E]"
                    style={{ animation: `pulse 1.2s ease-in-out ${i * 0.3}s infinite` }}
                  />
                ))}
              </div>
            </div>

            {/* Progress bar */}
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/10">
              <div
                className="h-full bg-[#C9A96E] transition-all duration-100"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* ── RESULT STEP ── */}
      {step === 'result' && resultUrl && (
        <div className="absolute inset-0 flex flex-col bg-[#0D0D0D] animate-in fade-in duration-500">
          <button onClick={onClose} className="absolute top-4 right-4 z-10 text-white/40 hover:text-white">
            <X className="h-5 w-5" />
          </button>

          {/* Before/After Slider */}
          <div className="flex-1 flex items-center justify-center px-4 pt-12 pb-4">
            <div
              ref={sliderRef}
              className="relative w-full max-w-lg overflow-hidden rounded-lg cursor-ew-resize select-none"
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              style={{ touchAction: 'none' }}
            >
              {/* After (retouched) - full image behind */}
              <img src={resultUrl} alt="After" className="w-full block" draggable={false} />

              {/* Before (original) - clipped */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ width: `${sliderPos}%` }}
              >
                <img
                  src={photoUrl}
                  alt="Before"
                  className="w-full block"
                  draggable={false}
                  style={{ width: sliderRef.current ? `${sliderRef.current.offsetWidth}px` : '100%' }}
                />
              </div>

              {/* Divider line */}
              <div
                className="absolute top-0 bottom-0 w-[1.5px] bg-[#C9A96E]"
                style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
              />

              {/* Handle */}
              <div
                className="absolute top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-[#C9A96E] flex items-center justify-center shadow-lg"
                style={{ left: `${sliderPos}%`, transform: 'translate(-50%, -50%)' }}
              >
                <span className="text-white text-[10px] font-bold">◄ ►</span>
              </div>

              {/* Labels */}
              <span className="absolute top-3 left-3 text-white/50 text-[9px] tracking-widest uppercase font-sans">Before</span>
              <span className="absolute top-3 right-3 text-white/50 text-[9px] tracking-widest uppercase font-sans">After</span>
            </div>
          </div>

          {/* Bottom content */}
          <div className="px-6 pb-8 space-y-4">
            <p className="text-center font-['Cormorant_Garamond'] italic text-white/70 text-lg">
              Looking beautiful. 🤍
            </p>

            {/* Coming soon badge */}
            <p className="text-center text-[#C9A96E]/40 text-[10px] tracking-wide">
              ✨ AI Enhancement Coming Soon
            </p>

            <button
              onClick={handleDownload}
              className="w-full py-3.5 rounded-lg bg-[#C9A96E] text-[#1A1A1A] text-[13px] font-medium tracking-wider flex items-center justify-center gap-2 hover:bg-[#B8935A] transition-colors"
            >
              <Download className="h-4 w-4" /> Download
            </button>

            <button
              onClick={() => { setStep('options'); setSelected(null); setResultUrl(null); setAutoPlayed(false); }}
              className="w-full py-3 rounded-lg border border-[#2A2A2A] text-white/60 text-[13px] hover:border-[#3A3A3A] transition-colors"
            >
              Try other option →
            </button>

            <p className="text-center text-[#C9A96E]/50 text-[11px]">
              ✨ {retouchLimit - getRetouchCount(eventId)} retouch{retouchLimit - getRetouchCount(eventId) !== 1 ? 'es' : ''} remaining
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
