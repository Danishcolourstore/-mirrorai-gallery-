interface StatCardProps {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  progress?: number;
}

export function StatCard({ label, value, icon, progress }: StatCardProps) {
  const isStorage = typeof value === 'string' && value.includes('/');

  return (
    <div className="px-6 py-6 group">
      <div className="flex items-center justify-between mb-3">
        <p className="text-[11px] uppercase tracking-[0.1em] text-primary font-bold font-sans">{label}</p>
        <span className="text-primary/40 group-hover:text-primary transition-colors duration-300">{icon}</span>
      </div>
      <p className={`font-serif text-foreground leading-none ${isStorage ? 'text-[15px] font-extrabold tracking-wide' : 'text-[36px] font-extrabold'}`}>
        {value}
      </p>
      {progress !== undefined && (
        <div className="mt-4 h-2.5 w-full bg-secondary rounded-[5px] overflow-hidden">
          <div
            className="h-full bg-primary rounded-[5px] transition-all duration-700 ease-out"
            style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
          />
        </div>
      )}
    </div>
  );
}
