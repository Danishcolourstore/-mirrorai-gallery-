import { useEffect, useCallback, useState } from 'react';
import { Heart, Download, X, ChevronLeft, ChevronRight, Share2, Sparkles } from 'lucide-react';
import { PhotoComments } from '@/components/PhotoComments';
import { PhotoRetouchSheet } from '@/components/PhotoRetouchSheet';

interface LightboxPhoto {
  id: string;
  url: string;
  file_name: string | null;
}

interface PhotoLightboxProps {
  photos: LightboxPhoto[];
  currentIndex: number;
  open: boolean;
  onClose: () => void;
  onIndexChange: (index: number) => void;
  eventId?: string;
  isFavorite?: (id: string) => boolean;
  toggleFavorite?: (id: string) => void;
  canDownload?: boolean;
  onDownload?: (photo: LightboxPhoto) => void;
  onShare?: (photo: LightboxPhoto) => void;
  retouchEnabled?: boolean;
  retouchLimit?: number;
  eventTitle?: string;
  studioName?: string;
}

export function PhotoLightbox({
  photos, currentIndex, open, onClose, onIndexChange, eventId,
  isFavorite, toggleFavorite, canDownload, onDownload, onShare,
  retouchEnabled, retouchLimit = 5, eventTitle, studioName,
}: PhotoLightboxProps) {
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchDelta, setTouchDelta] = useState(0);
  const [swiping, setSwiping] = useState(false);
  const [retouchOpen, setRetouchOpen] = useState(false);
  const [showControls, setShowControls] = useState(true);

  const goNext = useCallback(() => {
    if (currentIndex < photos.length - 1) onIndexChange(currentIndex + 1);
  }, [currentIndex, photos.length, onIndexChange]);

  const goPrev = useCallback(() => {
    if (currentIndex > 0) onIndexChange(currentIndex - 1);
  }, [currentIndex, onIndexChange]);

  // Preload next 2 images
  useEffect(() => {
    if (!open) return;
    for (let i = 1; i <= 2; i++) {
      const next = photos[currentIndex + i];
      if (next?.url) {
        const img = new Image();
        img.src = next.url;
      }
    }
  }, [currentIndex, photos, open]);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') goNext();
      if (e.key === 'ArrowLeft') goPrev();
    };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handler);
      document.body.style.overflow = '';
    };
  }, [open, onClose, goNext, goPrev]);

  // Auto-hide controls after 3s
  useEffect(() => {
    if (!open) return;
    setShowControls(true);
    const timer = setTimeout(() => setShowControls(false), 3000);
    return () => clearTimeout(timer);
  }, [open, currentIndex]);

  if (!open || photos.length === 0) return null;

  const photo = photos[currentIndex];
  if (!photo) return null;
  const fav = isFavorite?.(photo.id) ?? false;

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX);
    setTouchDelta(0);
    setSwiping(true);
  };
  const handleTouchMove = (e: React.TouchEvent) => {
    if (touchStart === null) return;
    setTouchDelta(e.touches[0].clientX - touchStart);
  };
  const handleTouchEnd = () => {
    if (touchStart === null) return;
    if (Math.abs(touchDelta) > 60) {
      if (touchDelta < 0) goNext();
      else goPrev();
    }
    setTouchStart(null);
    setTouchDelta(0);
    setSwiping(false);
  };

  const handleMouseMove = () => setShowControls(true);

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col"
      onTouchStart={handleTouchStart} onTouchMove={handleTouchMove} onTouchEnd={handleTouchEnd}
      onMouseMove={handleMouseMove}>
      {/* Top bar — fade with controls */}
      <div className={`flex items-center justify-between px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-2 shrink-0 transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <span className="text-white/40 text-[11px] tracking-[0.1em] font-sans font-light">
          {currentIndex + 1} / {photos.length}
        </span>
        <button onClick={onClose}
          className="min-w-[44px] min-h-[44px] rounded-full bg-white/10 backdrop-blur-lg flex items-center justify-center text-white/70 hover:text-white hover:bg-white/15 transition-all duration-200">
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Image area */}
      <div className="flex-1 relative flex items-center justify-center min-h-0">
        {/* Nav arrows — show on hover */}
        {currentIndex > 0 && (
          <button onClick={goPrev}
            className={`absolute left-5 z-10 min-w-[40px] min-h-[40px] rounded-full bg-white/10 backdrop-blur-lg flex items-center justify-center text-white transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
            <ChevronLeft className="h-4 w-4" />
          </button>
        )}

        {currentIndex < photos.length - 1 && (
          <button onClick={goNext}
            className={`absolute right-5 z-10 min-w-[40px] min-h-[40px] rounded-full bg-white/10 backdrop-blur-lg flex items-center justify-center text-white transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
            <ChevronRight className="h-4 w-4" />
          </button>
        )}

        <img
          src={photo.url}
          alt=""
          className="max-h-[90vh] max-w-[90vw] object-contain select-none transition-transform duration-150"
          style={swiping && touchDelta !== 0 ? { transform: `translateX(${touchDelta * 0.4}px)` } : undefined}
          draggable={false}
        />
      </div>

      {/* Bottom toolbar — fade with controls */}
      <div className={`shrink-0 flex flex-col items-center px-6 py-4 pb-[max(1rem,env(safe-area-inset-bottom))] transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="flex items-center gap-5 mb-2">
          {toggleFavorite && (
            <button onClick={() => toggleFavorite(photo.id)}
              className="min-w-[52px] min-h-[52px] rounded-full bg-white/8 backdrop-blur-md flex items-center justify-center text-white/80 hover:bg-white/15 transition-all duration-200 active:scale-105">
              <Heart className={`h-6 w-6 ${fav ? 'text-gold' : ''}`} fill={fav ? 'currentColor' : 'none'} />
            </button>
          )}
          {retouchEnabled && eventId && (
            <button onClick={() => setRetouchOpen(true)}
              className="min-w-[52px] min-h-[52px] rounded-full bg-white/8 backdrop-blur-md flex items-center justify-center text-gold hover:bg-white/15 transition-all duration-200">
              <Sparkles className="h-5 w-5" />
            </button>
          )}
          {canDownload && onDownload && (
            <button onClick={() => onDownload(photo)}
              className="min-w-[52px] min-h-[52px] rounded-full bg-white/8 backdrop-blur-md flex items-center justify-center text-white/80 hover:bg-white/15 transition-all duration-200">
              <Download className="h-6 w-6" />
            </button>
          )}
          {onShare && (
            <button onClick={() => onShare(photo)}
              className="min-w-[52px] min-h-[52px] rounded-full bg-white/8 backdrop-blur-md flex items-center justify-center text-white/80 hover:bg-white/15 transition-all duration-200">
              <Share2 className="h-6 w-6" />
            </button>
          )}
        </div>
        {eventId && (
          <div className="w-full max-w-md">
            <PhotoComments photoId={photo.id} eventId={eventId} />
          </div>
        )}
      </div>

      {/* Retouch Sheet */}
      {retouchEnabled && eventId && (
        <PhotoRetouchSheet
          open={retouchOpen}
          onClose={() => setRetouchOpen(false)}
          photoUrl={photo.url}
          photoId={photo.id}
          eventId={eventId}
          eventTitle={eventTitle}
          studioName={studioName}
          retouchLimit={retouchLimit}
        />
      )}
    </div>
  );
}
