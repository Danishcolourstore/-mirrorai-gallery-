
import React from 'react';
import AppSidebar from './AppSidebar';

export default function DashboardLayout({children}:{children:React.ReactNode}){
  return (
    <div className="flex">
      <AppSidebar/>
      <main className="flex-1 p-6">{children}</main>
    </div>
  )
}
