import { useState } from 'react';
import { LayoutDashboard, CalendarDays, Upload, User, LogOut, Settings, X, Radio } from 'lucide-react';
import { NavLink } from '@/components/NavLink';

const items = [
  { title: 'Home', url: '/dashboard', icon: LayoutDashboard },
  { title: 'Events', url: '/dashboard/events', icon: CalendarDays },
  { title: 'Live', url: '/dashboard/mirrorlive', icon: Radio, isLive: true },
  { title: 'Upload', url: '/dashboard/upload', icon: Upload },
];

interface MobileNavProps {
  onSignOut?: () => void;
  studioName?: string;
  email?: string;
}

export function MobileNav({ onSignOut, studioName, email }: MobileNavProps) {
  const [showProfile, setShowProfile] = useState(false);

  return (
    <>
      <nav className="fixed bottom-0 left-0 right-0 z-30 flex items-center justify-around border-t-2 border-border/60 bg-[#1A0F00] py-2 lg:hidden safe-area-pb shadow-[0_-4px_30px_-10px_rgba(26,15,0,0.3)]">
        {items.map((item) => (
          <NavLink
            key={item.url}
            to={item.url}
            end={item.url === '/dashboard'}
            className={`flex flex-col items-center gap-1 px-4 py-1.5 transition-all duration-300 ${(item as any).isLive ? 'text-destructive' : 'text-[#C49A3C]/60'}`}
            activeClassName="text-[#C49A3C] !text-[#C49A3C]"
          >
            {(item as any).isLive ? (
              <span className="relative">
                <item.icon className="h-6 w-6" strokeWidth={2.2} />
                <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-destructive animate-pulse" />
              </span>
            ) : (
              <item.icon className="h-6 w-6" strokeWidth={2.2} />
            )}
            <span className="text-[11px] font-extrabold uppercase tracking-[0.1em] font-sans">{item.title}</span>
          </NavLink>
        ))}
        <button
          onClick={() => setShowProfile(true)}
          className="flex flex-col items-center gap-1 px-4 py-1.5 text-[#C49A3C]/60 transition-all duration-300"
        >
          <User className="h-6 w-6" strokeWidth={2.2} />
          <span className="text-[11px] font-extrabold uppercase tracking-[0.1em] font-sans">Profile</span>
        </button>
      </nav>

      {/* Profile sheet */}
      {showProfile && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-foreground/30 backdrop-blur-sm" onClick={() => setShowProfile(false)} />
          <div className="absolute bottom-0 left-0 right-0 bg-card border-t-2 border-border rounded-t-2xl p-7 space-y-5 animate-in slide-in-from-bottom duration-300">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[17px] font-extrabold text-foreground">{studioName || 'My Studio'}</p>
                <p className="text-[12px] text-muted-foreground/60 truncate mt-0.5 font-bold">{email}</p>
              </div>
              <button onClick={() => setShowProfile(false)} className="text-foreground/30 hover:text-foreground/60 transition-colors p-1">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="h-[2px] bg-border/60" />
            <NavLink
              to="/dashboard/settings"
              className="flex items-center gap-3 py-3 text-[15px] font-bold text-foreground hover:text-primary transition-colors"
              onClick={() => setShowProfile(false)}
            >
              <Settings className="h-4 w-4 text-primary/50" />
              Settings
            </NavLink>
            <button
              onClick={() => { setShowProfile(false); onSignOut?.(); }}
              className="flex items-center gap-3 py-3 text-[15px] font-bold text-destructive/80 hover:text-destructive w-full transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </button>
          </div>
        </div>
      )}
    </>
  );
}
