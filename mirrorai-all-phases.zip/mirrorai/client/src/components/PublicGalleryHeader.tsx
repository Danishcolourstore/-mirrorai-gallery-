import { format } from 'date-fns';
import { Link2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PublicGalleryHeaderProps {
  event: {
    name: string;
    event_date: string;
    cover_url: string | null;
    camera_connected?: boolean;
    livesync_enabled?: boolean;
  };
  photosCount: number;
}

export function PublicGalleryHeader({ event, photosCount }: PublicGalleryHeaderProps) {
  const { toast } = useToast();
  const isLive = (event as any).camera_connected || (event as any).livesync_enabled;

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: 'Link copied!' });
  };

  if (event.cover_url) {
    return (
      <div className="relative h-[60vh] sm:h-[65vh] overflow-hidden">
        <img src={event.cover_url} alt={event.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        <div className="absolute bottom-0 inset-x-0 px-6 sm:px-10 pb-10 sm:pb-14 flex items-end justify-between">
          <div>
            <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-medium text-white leading-[1.1] tracking-tight">{event.name}</h1>
            <div className="flex items-center gap-3 mt-3">
              {isLive && (
                <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[hsl(0,84%,55%)]/20 backdrop-blur-sm border border-[hsl(0,84%,55%)]/30">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[hsl(0,84%,55%)] opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-[hsl(0,84%,55%)]" />
                  </span>
                  <span className="text-white text-[11px] font-bold tracking-wider">MirrorLive</span>
                </span>
              )}
              <p className="text-[13px] sm:text-[14px] text-white/50 tracking-wide font-sans">
                {format(new Date(event.event_date), 'MMMM d, yyyy')} · {photosCount} photos
              </p>
            </div>
            {isLive && (
              <p className="text-white/40 text-[12px] mt-2 font-sans">
                📷 Photos are being delivered live from the event right now
              </p>
            )}
          </div>
          <button onClick={copyLink}
            className="shrink-0 min-w-[44px] min-h-[44px] rounded-full bg-white/15 backdrop-blur-md flex items-center justify-center text-white/80 hover:bg-white/25 transition-all duration-200 mb-1">
            <Link2 className="h-5 w-5" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-[35vh] sm:h-[40vh] flex items-end" style={{ backgroundColor: '#1C1612' }}>
      <div className="px-6 sm:px-10 pb-10 sm:pb-14 flex items-end justify-between w-full">
        <div>
          <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-medium text-white leading-[1.1] tracking-tight">{event.name}</h1>
          <div className="flex items-center gap-3 mt-3">
            {isLive && (
              <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[hsl(0,84%,55%)]/20 backdrop-blur-sm border border-[hsl(0,84%,55%)]/30">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[hsl(0,84%,55%)] opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[hsl(0,84%,55%)]" />
                </span>
                <span className="text-white text-[11px] font-bold tracking-wider">MirrorLive</span>
              </span>
            )}
            <p className="text-[13px] sm:text-[14px] text-white/40 tracking-wide font-sans">
              {format(new Date(event.event_date), 'MMMM d, yyyy')} · {photosCount} photos
            </p>
          </div>
        </div>
        <button onClick={copyLink}
          className="shrink-0 min-w-[44px] min-h-[44px] rounded-full bg-white/15 backdrop-blur-md flex items-center justify-center text-white/80 hover:bg-white/25 transition-all duration-200 mb-1">
          <Link2 className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
}
