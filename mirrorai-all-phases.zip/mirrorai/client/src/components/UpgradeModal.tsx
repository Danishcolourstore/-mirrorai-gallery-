import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Check, Crown } from 'lucide-react';

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  reason?: string;
  onUpgrade: () => void;
}

const proFeatures = [
  'Unlimited events',
  '500GB storage',
  'Standard + Studio gallery presets',
  'No MirrorAI watermark',
  'Full studio branding',
  'Analytics per event',
  'Client email collection',
  'Photo selection mode',
  'Priority support',
];

export function UpgradeModal({ open, onOpenChange, reason, onUpgrade }: UpgradeModalProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-serif text-xl">
            <Crown className="h-5 w-5 text-primary" />
            Upgrade to Pro
          </DialogTitle>
        </DialogHeader>

        {reason && (
          <div className="bg-primary/5 border border-primary/20 rounded-lg px-4 py-3 text-[13px] text-foreground">
            {reason}
          </div>
        )}

        <div className="space-y-3 my-2">
          {proFeatures.map((f) => (
            <div key={f} className="flex items-center gap-2.5 text-[13px]">
              <Check className="h-4 w-4 text-primary shrink-0" />
              <span>{f}</span>
            </div>
          ))}
        </div>

        <div className="text-center my-2">
          <p className="font-serif text-3xl font-semibold text-foreground">₹3,750</p>
          <p className="text-[12px] text-muted-foreground">/year</p>
          <p className="text-[12px] text-primary font-medium mt-1">Just ₹312/month</p>
        </div>

        <Button
          className="w-full h-11 text-[13px] font-medium tracking-wide"
          onClick={onUpgrade}
        >
          Go Pro Now
        </Button>

        <button
          onClick={() => onOpenChange(false)}
          className="w-full text-center text-[12px] text-muted-foreground hover:text-foreground transition-colors py-1"
        >
          Maybe later
        </button>
      </DialogContent>
    </Dialog>
  );
}
