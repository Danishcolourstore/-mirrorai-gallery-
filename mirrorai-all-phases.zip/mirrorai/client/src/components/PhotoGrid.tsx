
import React from 'react';

export type LayoutMode = 'classic'|'masonry'|'justified'|'editorial'|'cinematic'|'collage'|'timeline'|'story';

export interface Photo {
  id: string;
  url: string;
  alt?: string;
}

export default function PhotoGrid({photos, layout='classic'}:{photos:Photo[], layout?:LayoutMode}){
  const gridClass = {
    classic:'grid grid-cols-2 md:grid-cols-3 gap-2',
    masonry:'columns-2 md:columns-3 gap-2',
    justified:'flex flex-wrap gap-2',
    editorial:'grid grid-cols-2 md:grid-cols-4 gap-2',
    cinematic:'grid grid-cols-1 md:grid-cols-2 gap-2',
    collage:'grid grid-cols-3 gap-2',
    timeline:'flex flex-col gap-2',
    story:'flex flex-col gap-4'
  }[layout];

  return (
    <div className={gridClass}>
      {photos.map(p=>(
        <img key={p.id} src={p.url} alt={p.alt||'photo'} loading="lazy"
          className="w-full rounded-md hover:opacity-90 transition"/>
      ))}
    </div>
  )
}
