import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { MessageCircle, Send } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Comment {
  id: string;
  guest_name: string;
  comment: string;
  created_at: string;
}

interface Props {
  photoId: string;
  eventId: string;
}

export function PhotoComments({ photoId, eventId }: Props) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [name, setName] = useState('');
  const [text, setText] = useState('');
  const [posting, setPosting] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const fetchComments = useCallback(async () => {
    const { data } = await (supabase
      .from('photo_comments' as any)
      .select('*') as any)
      .eq('photo_id', photoId)
      .order('created_at', { ascending: false })
      .limit(20);
    if (data) setComments(data as Comment[]);
  }, [photoId]);

  useEffect(() => { fetchComments(); }, [fetchComments]);

  const handlePost = async () => {
    if (!text.trim() || text.length > 150) return;
    setPosting(true);
    await (supabase.from('photo_comments' as any).insert({
      photo_id: photoId,
      event_id: eventId,
      guest_name: name.trim() || 'Guest',
      comment: text.trim(),
    }) as any);
    setText('');
    setPosting(false);
    fetchComments();
  };

  return (
    <div className="w-full mt-4">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1.5 text-white/50 hover:text-white/70 transition-colors text-[12px]"
      >
        <MessageCircle className="h-4 w-4" />
        <span>{comments.length} comment{comments.length !== 1 ? 's' : ''}</span>
      </button>

      {expanded && (
        <div className="mt-3 space-y-3 animate-fade-in">
          {/* Post form */}
          <div className="flex gap-2">
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Name"
              className="w-20 shrink-0 bg-white/10 border-none rounded px-2 py-1.5 text-[12px] text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-white/20"
            />
            <input
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, 150))}
              placeholder="Leave a memory..."
              className="flex-1 bg-white/10 border-none rounded px-2 py-1.5 text-[12px] text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-white/20"
              onKeyDown={(e) => { if (e.key === 'Enter') handlePost(); }}
            />
            <button
              onClick={handlePost}
              disabled={!text.trim() || posting}
              className="shrink-0 min-w-[36px] min-h-[36px] rounded bg-white/10 flex items-center justify-center text-white/60 hover:text-white hover:bg-white/20 transition disabled:opacity-30"
            >
              <Send className="h-3.5 w-3.5" />
            </button>
          </div>
          <p className="text-[9px] text-white/30 text-right">{text.length}/150</p>

          {/* Comments list */}
          <div className="space-y-2 max-h-[200px] overflow-y-auto">
            {comments.map((c) => (
              <div key={c.id} className="text-[12px]">
                <span className="text-white/70 font-medium">{c.guest_name}</span>
                <span className="text-white/30 mx-1.5">·</span>
                <span className="text-white/25 text-[10px]">
                  {formatDistanceToNow(new Date(c.created_at), { addSuffix: true })}
                </span>
                <p className="text-white/60 mt-0.5">{c.comment}</p>
              </div>
            ))}
            {comments.length === 0 && (
              <p className="text-[11px] text-white/25 text-center py-2">No comments yet</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
