import { CheckCircle2, AlertCircle, X, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import type { UploadState } from '@/hooks/use-photo-upload';

interface UploadProgressPanelProps extends UploadState {
  onRetry: () => void;
  onDismiss: () => void;
}

export function UploadProgressPanel({
  isUploading,
  totalFiles,
  completedFiles,
  successCount,
  failedFiles,
  isDone,
  percent,
  isRetrying,
  errors,
  onRetry,
  onDismiss,
}: UploadProgressPanelProps) {
  if (!isUploading && !isDone) return null;

  const remaining = totalFiles - completedFiles;
  const hasFailed = failedFiles.length > 0;
  const hasErrors = errors && errors.length > 0;

  const StatusContent = ({ mobile }: { mobile?: boolean }) => {
    const textSize = mobile ? 'text-[11px]' : 'text-[12px]';
    const iconSize = mobile ? 'h-3.5 w-3.5' : 'h-4 w-4';

    return (
      <div className="flex items-center justify-between">
        {isUploading && isRetrying ? (
          <div className="flex items-center gap-2 text-foreground">
            <RefreshCw className={`${iconSize} animate-spin`} />
            <p className={`${textSize} font-medium`}>
              Retrying {completedFiles}/{totalFiles}
            </p>
          </div>
        ) : isUploading ? (
          <p className={`${textSize} text-foreground font-medium`}>
            Uploading {completedFiles} of {totalFiles} photos…
            {!mobile && (
              <span className="ml-2 text-muted-foreground/50 font-normal">
                {remaining} remaining
              </span>
            )}
          </p>
        ) : isDone && !hasFailed && !hasErrors ? (
          <div className="flex items-center gap-2 text-primary">
            <CheckCircle2 className={iconSize} />
            <p className={`${textSize} font-medium`}>
              Upload Complete — {successCount} Photos Added
            </p>
          </div>
        ) : isDone ? (
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className={iconSize} />
            <p className={`${textSize} font-medium`}>
              {hasFailed
                ? `${failedFiles.length} upload${failedFiles.length > 1 ? 's' : ''} failed`
                : `${successCount} uploaded`}
              {hasErrors && !hasFailed ? ` · ${errors.length} rejected` : ''}
            </p>
          </div>
        ) : null}

        <div className="flex items-center gap-1.5 shrink-0">
          {isDone && hasFailed && (
            <Button
              onClick={onRetry}
              variant="ghost"
              size="sm"
              className="text-primary hover:bg-primary/10 text-[10px] h-7 px-2.5 uppercase tracking-[0.06em]"
            >
              Retry {failedFiles.length}
            </Button>
          )}
          {isDone && (
            <button
              onClick={onDismiss}
              className="text-muted-foreground/40 hover:text-foreground transition-colors p-1"
            >
              <X className={mobile ? 'h-3 w-3' : 'h-3.5 w-3.5'} />
            </button>
          )}
        </div>
      </div>
    );
  };

  const ErrorList = () => {
    if (!hasErrors || !isDone) return null;
    return (
      <div className="space-y-1 mt-1">
        {errors.slice(0, 3).map((err, i) => (
          <p key={i} className="text-[10px] text-destructive/70 truncate">{err}</p>
        ))}
        {errors.length > 3 && (
          <p className="text-[10px] text-muted-foreground/50">+{errors.length - 3} more</p>
        )}
      </div>
    );
  };

  return (
    <>
      {/* Desktop */}
      <div className="hidden sm:block mb-5">
        <div className="border border-border bg-card px-5 py-4 space-y-3">
          <StatusContent />
          {isUploading && <Progress value={percent} className="h-1" />}
          <ErrorList />
        </div>
      </div>

      {/* Mobile */}
      <div className="fixed bottom-16 left-0 right-0 z-40 sm:hidden px-3">
        <div className="border border-border bg-card px-4 py-3 shadow-lg space-y-2.5 mx-auto max-w-md">
          <StatusContent mobile />
          {isUploading && <Progress value={percent} className="h-1" />}
          {isUploading && (
            <p className="text-[9px] text-muted-foreground/40">
              {remaining} remaining · {percent}%
            </p>
          )}
          <ErrorList />
        </div>
      </div>
    </>
  );
}
