import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { OtpInput } from '@/components/OtpInput';
import { Instagram, Phone, Globe, ChevronDown } from 'lucide-react';
import { format } from 'date-fns';

interface StudioProfile {
  studio_name: string;
  tagline: string | null;
  logo_url: string | null;
  instagram: string | null;
  whatsapp: string | null;
  website_url: string | null;
  accent_color: string;
  hero_sections_enabled: Record<string, boolean>;
  button_text: string;
  button_position: string;
  button_style: string;
  about_portrait_url: string | null;
  about_bio: string | null;
  about_name: string | null;
  whatsapp_button_text: string;
}

interface StudioEvent {
  id: string;
  name: string;
  slug: string;
  event_date: string;
  location: string | null;
  cover_url: string | null;
  gallery_pin: string | null;
  user_id: string;
}

interface Props {
  event: StudioEvent;
  photoCount: number;
}

// Sub-components
function StickyNav({ profile, accent, show }: { profile: StudioProfile; accent: string; show: boolean }) {
  if (!show) return null;
  const waLink = profile.whatsapp
    ? `https://wa.me/${profile.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent("Hi! I'd love to know more about your photography services.")}`
    : null;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: 'rgba(250,248,245,0.95)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid #E8E5E0',
        transform: show ? 'translateY(0)' : 'translateY(-100%)',
      }}>
      <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {profile.logo_url ? (
            <img src={profile.logo_url} alt={profile.studio_name} className="h-8 object-contain" />
          ) : (
            <span className="font-serif text-[16px] font-light text-[#1A1A1A]">{profile.studio_name}</span>
          )}
        </div>
        {waLink && (
          <a href={waLink} target="_blank" rel="noopener noreferrer"
            className="text-[11px] font-sans font-medium tracking-[0.1em] px-5 py-2 rounded-full transition-all"
            style={{ backgroundColor: accent, color: accent === '#1A1A1A' ? '#fff' : '#1A1A1A' }}>
            {profile.whatsapp_button_text || 'Book a Shoot'}
          </a>
        )}
      </div>
    </div>
  );
}

function HeroSection({ event, profile, accent, onEnter, buttonPosition }: {
  event: StudioEvent; profile: StudioProfile; accent: string; onEnter: () => void; buttonPosition: string;
}) {
  const studioName = profile.studio_name || 'Studio';
  return (
    <section className="relative w-full h-[100dvh] overflow-hidden flex items-end justify-center">
      {event.cover_url ? (
        <img src={event.cover_url} alt={event.name}
          className="absolute inset-0 w-full h-full object-cover animate-ken-burns" />
      ) : (
        <div className="absolute inset-0 bg-[#1A1A1A]" />
      )}
      {/* Dark gradient overlay */}
      <div className="absolute inset-0" style={{
        background: 'linear-gradient(to bottom, transparent 40%, rgba(0,0,0,0.6) 100%)'
      }} />
      <div className="relative z-10 text-center pb-20 px-6 animate-fade-in">
        {profile.logo_url ? (
          <img src={profile.logo_url} alt={studioName} className="h-14 object-contain mx-auto mb-4" />
        ) : (
          <h1 className="font-serif text-white uppercase" style={{
            fontSize: 'clamp(40px, 7vw, 80px)', fontWeight: 300, letterSpacing: '0.2em'
          }}>{studioName}</h1>
        )}
        {profile.tagline && (
          <p className="font-sans text-[11px] uppercase tracking-[0.3em] mt-3" style={{ color: 'rgba(255,255,255,0.6)' }}>
            {profile.tagline}
          </p>
        )}
        <div className="w-10 h-px mx-auto my-5" style={{ backgroundColor: accent }} />
        <p className="font-serif italic text-[22px]" style={{ color: 'rgba(255,255,255,0.85)' }}>
          {event.name}
        </p>
        <p className="font-sans text-[11px] mt-2" style={{ color: 'rgba(255,255,255,0.5)' }}>
          {format(new Date(event.event_date), 'MMMM d, yyyy')}
          {event.location && ` · ${event.location}`}
        </p>
        {buttonPosition === 'after_hero' && (
          <div className="mt-10">
            <GalleryButton profile={profile} accent={accent} onClick={onEnter} />
          </div>
        )}
      </div>
      {buttonPosition !== 'after_hero' && (
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 animate-fade-in" style={{ animationDelay: '1s' }}>
          <ChevronDown className="h-5 w-5 text-white/40 animate-bounce" />
        </div>
      )}
    </section>
  );
}

function GalleryButton({ profile, accent, onClick, floating }: {
  profile: StudioProfile; accent: string; onClick: () => void; floating?: boolean;
}) {
  const style = profile.button_style || 'gold';
  const text = profile.button_text || 'See your forever. 🤍';

  const baseClasses = `font-sans text-[12px] tracking-[0.15em] font-medium transition-all duration-300 ${floating ? 'rounded-full px-7 py-3.5' : 'w-full max-w-[280px] py-4 rounded-sm'}`;

  let btnStyle: React.CSSProperties = {};
  if (style === 'bold') {
    btnStyle = { backgroundColor: '#1A1A1A', color: '#fff' };
  } else if (style === 'gold') {
    btnStyle = { backgroundColor: '#C9A96E', color: '#1A1A1A' };
  } else {
    btnStyle = { border: '1.5px solid #C9A96E', color: '#C9A96E', background: 'transparent' };
  }

  return (
    <button onClick={onClick} className={baseClasses} style={btnStyle}
      onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.88'; }}
      onMouseLeave={(e) => { e.currentTarget.style.opacity = '1'; }}>
      {text}
    </button>
  );
}

function AboutSection({ profile, accent }: { profile: StudioProfile; accent: string }) {
  if (!profile.about_bio && !profile.about_name) return null;
  return (
    <section className="py-24 px-6" style={{ backgroundColor: '#FAFAF8' }}>
      <div className="max-w-5xl mx-auto flex flex-col md:flex-row gap-12 md:gap-16 items-center">
        {profile.about_portrait_url && (
          <div className="w-full md:w-[40%] shrink-0">
            <div className="aspect-[3/4] overflow-hidden shadow-lg">
              <img src={profile.about_portrait_url} alt={profile.about_name || 'Photographer'}
                className="w-full h-full object-cover" />
            </div>
          </div>
        )}
        <div className="flex-1">
          <p className="font-sans text-[9px] uppercase tracking-[0.3em] mb-4" style={{ color: accent }}>About</p>
          <h2 className="font-serif italic text-[clamp(28px,4vw,42px)] font-light text-[#1A1A1A] mb-6" style={{ letterSpacing: '-0.01em' }}>
            Hello, I'm {profile.about_name || profile.studio_name}
          </h2>
          <p className="font-sans text-[15px] leading-[1.8] text-[#555] font-light whitespace-pre-line">
            {profile.about_bio}
          </p>
          <div className="flex items-center gap-4 mt-8">
            {profile.instagram && (
              <a href={profile.instagram.startsWith('http') ? profile.instagram : `https://instagram.com/${profile.instagram.replace('@', '')}`}
                target="_blank" rel="noopener noreferrer" className="text-[#bbb] hover:text-[#C9A96E] transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            )}
            {profile.whatsapp && (
              <a href={`https://wa.me/${profile.whatsapp.replace(/\D/g, '')}`}
                target="_blank" rel="noopener noreferrer" className="text-[#bbb] hover:text-[#C9A96E] transition-colors">
                <Phone className="h-5 w-5" />
              </a>
            )}
            {profile.website_url && (
              <a href={profile.website_url.startsWith('http') ? profile.website_url : `https://${profile.website_url}`}
                target="_blank" rel="noopener noreferrer" className="text-[#bbb] hover:text-[#C9A96E] transition-colors">
                <Globe className="h-5 w-5" />
              </a>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function PortfolioSection({ photos }: { photos: { url: string; id: string }[] }) {
  if (!photos.length) return null;
  return (
    <section className="py-24 px-6" style={{ backgroundColor: '#F5F3EF' }}>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="font-sans text-[9px] uppercase tracking-[0.3em] text-[#C9A96E] mb-3">Selected Work</p>
          <h2 className="font-serif italic text-[clamp(32px,5vw,48px)] font-light text-[#1A1A1A]">Through the Lens</h2>
        </div>
        <div className="columns-2 md:columns-3 gap-[3px]">
          {photos.map((p, i) => (
            <div key={p.id} className="mb-[3px] overflow-hidden group animate-fade-in" style={{ animationDelay: `${i * 0.08}s` }}>
              <img src={p.url} alt="" loading="lazy"
                className="w-full block transition-transform duration-500 group-hover:scale-[1.03]" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ServicesSection({ services }: { services: { id: string; title: string; description: string | null }[] }) {
  if (!services.length) return null;
  return (
    <section className="py-24 px-6" style={{ backgroundColor: '#FAFAF8' }}>
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif italic text-[clamp(28px,4vw,42px)] font-light text-[#1A1A1A]">What We Offer</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {services.map((s, i) => (
            <div key={s.id} className="p-8 rounded" style={{ backgroundColor: '#F5F3EF', border: '1px solid #E8E5E0' }}>
              <span className="font-serif text-[32px] text-[#C9A96E] opacity-50">
                {String(i + 1).padStart(2, '0')}
              </span>
              <h3 className="font-serif text-[22px] mt-3 text-[#1A1A1A]">{s.title}</h3>
              {s.description && (
                <p className="font-sans text-[14px] text-[#888] leading-[1.7] mt-3">{s.description}</p>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection({ testimonials }: {
  testimonials: { id: string; quote: string; client_name: string; event_type: string | null }[];
}) {
  const [active, setActive] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || testimonials.length <= 1) return;
    const t = setInterval(() => setActive(a => (a + 1) % testimonials.length), 5000);
    return () => clearInterval(t);
  }, [paused, testimonials.length]);

  if (!testimonials.length) return null;
  const t = testimonials[active];

  return (
    <section className="py-24 px-6" style={{ backgroundColor: '#0D0D0D' }}
      onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="font-serif italic text-[clamp(28px,4vw,42px)] font-light text-white mb-16">Kind Words</h2>
        <div className="relative min-h-[200px]">
          <span className="font-serif text-[120px] leading-none text-[#C9A96E] opacity-20 select-none absolute -top-8 left-1/2 -translate-x-1/2">"</span>
          <p className="font-serif italic text-[22px] leading-[1.6] text-white/85 max-w-[700px] mx-auto relative z-10 pt-12">
            {t.quote}
          </p>
          <p className="font-sans text-[12px] uppercase tracking-[0.2em] text-[#C9A96E] mt-8">{t.client_name}</p>
          {t.event_type && (
            <p className="font-sans text-[11px] text-white/40 mt-1">{t.event_type}</p>
          )}
        </div>
        {testimonials.length > 1 && (
          <div className="flex justify-center gap-2 mt-10">
            {testimonials.map((_, i) => (
              <button key={i} onClick={() => setActive(i)}
                className="w-2 h-2 rounded-full transition-all duration-300"
                style={{
                  backgroundColor: i === active ? '#C9A96E' : 'transparent',
                  border: `1px solid ${i === active ? '#C9A96E' : 'rgba(255,255,255,0.3)'}`
                }} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function EndOfPageCTA({ event, profile, accent, onEnter }: {
  event: StudioEvent; profile: StudioProfile; accent: string; onEnter: () => void;
}) {
  return (
    <section className="py-32 px-6" style={{ backgroundColor: '#0D0D0D' }}>
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="font-serif italic text-white" style={{ fontSize: 'clamp(32px,6vw,52px)' }}>
          {event.name}
        </h2>
        <p className="font-serif italic text-[#C9A96E] mt-2" style={{ fontSize: 'clamp(28px,5vw,48px)' }}>
          is waiting for you.
        </p>
        <div className="mt-10 flex justify-center">
          <GalleryButton profile={profile} accent={accent} onClick={onEnter} />
        </div>
        <p className="font-sans text-[10px] mt-12" style={{ color: 'rgba(255,255,255,0.3)' }}>
          {profile.studio_name} · © {new Date().getFullYear()}
        </p>
      </div>
    </section>
  );
}

// Transition overlay
function TransitionOverlay({ active, studioName, buttonText }: {
  active: boolean; studioName: string; buttonText: string;
}) {
  if (!active) return null;
  return (
    <div className="fixed inset-0 z-[9999] bg-black flex flex-col items-center justify-center animate-fade-in">
      <h2 className="font-serif text-white text-[clamp(24px,5vw,40px)] font-light tracking-wide animate-fade-in">
        {studioName}
      </h2>
      <p className="font-serif italic text-[#C9A96E] text-[16px] mt-3 animate-fade-in" style={{ animationDelay: '0.3s' }}>
        {buttonText}
      </p>
    </div>
  );
}

// PIN overlay
function PinOverlay({ onComplete, error, shaking }: {
  onComplete: (pin: string) => void; error: boolean; shaking: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[9998] bg-black/80 flex items-center justify-center animate-fade-in"
      style={{ backdropFilter: 'blur(8px)' }}>
      <div className="text-center space-y-6">
        <p className="font-sans text-[9px] uppercase tracking-[0.2em] text-white/50">Gallery Password</p>
        <div className={shaking ? 'animate-shake' : ''}>
          <OtpInput length={4} onComplete={onComplete} />
        </div>
        {error && <p className="text-[10px] text-red-400">Incorrect PIN. Try again.</p>}
      </div>
    </div>
  );
}

export function StudioLandingPage({ event, photoCount }: Props) {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<StudioProfile | null>(null);
  const [pinError, setPinError] = useState(false);
  const [shaking, setShaking] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [transitioning, setTransitioning] = useState(false);
  const [showStickyNav, setShowStickyNav] = useState(false);
  const [portfolioPhotos, setPortfolioPhotos] = useState<{ url: string; id: string }[]>([]);
  const [services, setServices] = useState<{ id: string; title: string; description: string | null }[]>([]);
  const [testimonials, setTestimonials] = useState<{ id: string; quote: string; client_name: string; event_type: string | null }[]>([]);

  const unlocked = useRef(!event.gallery_pin || sessionStorage.getItem(`unlocked_${event.id}`) === 'true');

  useEffect(() => {
    // Fetch studio profile
    (supabase.from('studio_profiles' as any).select('*') as any)
      .eq('user_id', event.user_id)
      .maybeSingle()
      .then(({ data }: any) => {
        if (data) {
          setProfile({
            studio_name: data.studio_name,
            tagline: data.tagline,
            logo_url: data.logo_url,
            instagram: data.instagram,
            whatsapp: data.whatsapp,
            website_url: data.website_url,
            accent_color: data.accent_color || '#1A1A1A',
            hero_sections_enabled: data.hero_sections_enabled || {},
            button_text: data.button_text || 'See your forever. 🤍',
            button_position: data.button_position || 'floating',
            button_style: data.button_style || 'gold',
            about_portrait_url: data.about_portrait_url,
            about_bio: data.about_bio,
            about_name: data.about_name,
            whatsapp_button_text: data.whatsapp_button_text || 'Book a Shoot',
          });

          const sections = data.hero_sections_enabled || {};

          // Fetch portfolio photos if enabled
          if (sections.portfolio) {
            (supabase.from('photos').select('id, url') as any)
              .eq('user_id', event.user_id)
              .limit(12)
              .then(({ data: photos }: any) => {
                if (photos) setPortfolioPhotos(photos);
              });
          }

          // Fetch services if enabled
          if (sections.services) {
            (supabase.from('studio_services' as any).select('*') as any)
              .eq('user_id', event.user_id)
              .order('order_index')
              .then(({ data: svc }: any) => {
                if (svc) setServices(svc);
              });
          }

          // Fetch testimonials if enabled
          if (sections.testimonials) {
            (supabase.from('studio_testimonials' as any).select('*') as any)
              .eq('user_id', event.user_id)
              .order('order_index')
              .then(({ data: tst }: any) => {
                if (tst) setTestimonials(tst);
              });
          }
        } else {
          // Fallback
          (supabase.from('profiles').select('studio_name') as any)
            .eq('user_id', event.user_id)
            .single()
            .then(({ data: p }: any) => {
              if (p) setProfile({
                studio_name: p.studio_name, tagline: null, logo_url: null, instagram: null,
                whatsapp: null, website_url: null, accent_color: '#1A1A1A',
                hero_sections_enabled: {}, button_text: 'See your forever. 🤍',
                button_position: 'floating', button_style: 'gold',
                about_portrait_url: null, about_bio: null, about_name: null,
                whatsapp_button_text: 'Book a Shoot',
              });
            });
        }
      });
  }, [event]);

  // Scroll listener for sticky nav
  useEffect(() => {
    const onScroll = () => setShowStickyNav(window.scrollY > window.innerHeight * 0.8);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleEnterGallery = useCallback(() => {
    if (!unlocked.current && event.gallery_pin) {
      setShowPin(true);
      return;
    }
    doTransition();
  }, [event]);

  const doTransition = useCallback(() => {
    setShowPin(false);
    setTransitioning(true);
    setTimeout(() => navigate(`/event/${event.slug}/gallery`), 1200);
  }, [event.slug, navigate]);

  const handlePinComplete = useCallback((pin: string) => {
    if (pin === event.gallery_pin) {
      sessionStorage.setItem(`unlocked_${event.id}`, 'true');
      unlocked.current = true;
      setPinError(false);
      doTransition();
    } else {
      setPinError(true);
      setShaking(true);
      setTimeout(() => setShaking(false), 500);
    }
  }, [event, doTransition]);

  if (!profile) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-background">
        <p className="text-[11px] text-muted-foreground/50 uppercase tracking-widest">Loading…</p>
      </div>
    );
  }

  const accent = profile.accent_color || '#C9A96E';
  const sections = profile.hero_sections_enabled || {};
  const buttonPosition = profile.button_position || 'floating';

  return (
    <div className="min-h-[100dvh]">
      <TransitionOverlay active={transitioning} studioName={profile.studio_name} buttonText={profile.button_text} />
      {showPin && <PinOverlay onComplete={handlePinComplete} error={pinError} shaking={shaking} />}

      <StickyNav profile={profile} accent={accent} show={showStickyNav} />

      <HeroSection event={event} profile={profile} accent={accent}
        onEnter={handleEnterGallery} buttonPosition={buttonPosition} />

      {sections.about && <AboutSection profile={profile} accent={accent} />}
      {sections.portfolio && <PortfolioSection photos={portfolioPhotos} />}
      {sections.services && <ServicesSection services={services} />}
      {sections.testimonials && <TestimonialsSection testimonials={testimonials} />}

      {buttonPosition === 'end_of_page' && (
        <EndOfPageCTA event={event} profile={profile} accent={accent} onEnter={handleEnterGallery} />
      )}

      {/* Floating button */}
      {buttonPosition === 'floating' && !showStickyNav && (
        <div className="fixed bottom-8 right-8 z-[998] max-md:left-4 max-md:right-4 max-md:bottom-6 animate-fade-in"
          style={{ animationDelay: '1.5s' }}>
          <div className="md:float-right" style={{ animation: 'floatBounce 2s ease-in-out infinite' }}>
            <GalleryButton profile={profile} accent={accent} onClick={handleEnterGallery} floating />
          </div>
        </div>
      )}

      {/* Floating button in nav when scrolled */}
      {buttonPosition === 'floating' && showStickyNav && (
        <div className="fixed bottom-8 right-8 z-[998] max-md:left-4 max-md:right-4 max-md:bottom-6">
          <div className="md:float-right" style={{ animation: 'floatBounce 2s ease-in-out infinite' }}>
            <GalleryButton profile={profile} accent={accent} onClick={handleEnterGallery} floating />
          </div>
        </div>
      )}

      <style>{`
        @keyframes floatBounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-4px); }
        }
      `}</style>
    </div>
  );
}
