import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Instagram, Globe, Phone, Lock } from 'lucide-react';
import { OtpInput } from '@/components/OtpInput';
import { GalleryInstallPrompt } from '@/components/GalleryInstallPrompt';

interface StudioBranding {
  studio_name: string;
  brand_name?: string | null;
  brand_logo_url?: string | null;
  brand_color?: string | null;
  tagline?: string | null;
  instagram?: string | null;
  whatsapp?: string | null;
  website_url?: string | null;
}

interface StudioEvent {
  id: string;
  name: string;
  slug: string;
  event_date: string;
  location: string | null;
  cover_url: string | null;
  gallery_pin: string | null;
}

interface Props {
  event: StudioEvent;
  branding: StudioBranding;
  photoCount: number;
}

export function StudioCoverPage({ event, branding, photoCount }: Props) {
  const navigate = useNavigate();
  const [showPin, setShowPin] = useState(false);
  const [pinError, setPinError] = useState(false);
  const [shaking, setShaking] = useState(false);
  const [transitioning, setTransitioning] = useState(false);

  const accent = branding.brand_color || '#C4956A';
  const displayName = branding.brand_name || branding.studio_name;

  const handleEnter = () => {
    if (event.gallery_pin) {
      const unlocked = sessionStorage.getItem(`unlocked_${event.id}`);
      if (unlocked === 'true') {
        doTransition();
      } else {
        setShowPin(true);
      }
    } else {
      doTransition();
    }
  };

  const handlePinComplete = (pin: string) => {
    if (pin === event.gallery_pin) {
      sessionStorage.setItem(`unlocked_${event.id}`, 'true');
      setPinError(false);
      setShowPin(false);
      doTransition();
    } else {
      setPinError(true);
      setShaking(true);
      setTimeout(() => setShaking(false), 500);
    }
  };

  const doTransition = () => {
    setTransitioning(true);
    setTimeout(() => navigate(`/event/${event.slug}/gallery`), 800);
  };

  const socialLinks = [
    branding.instagram ? {
      icon: Instagram,
      href: `https://instagram.com/${branding.instagram.replace('@', '')}`,
    } : null,
    branding.website_url ? {
      icon: Globe,
      href: branding.website_url.startsWith('http') ? branding.website_url : `https://${branding.website_url}`,
    } : null,
    branding.whatsapp ? {
      icon: Phone,
      href: `https://wa.me/${branding.whatsapp.replace(/\D/g, '')}`,
    } : null,
  ].filter(Boolean) as { icon: any; href: string }[];

  const formattedDate = (() => {
    try {
      return new Date(event.event_date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    } catch { return event.event_date; }
  })();

  return (
    <div className="relative min-h-[100dvh] overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        {event.cover_url ? (
          <img
            src={event.cover_url}
            alt=""
            className="h-full w-full object-cover scale-105 animate-[kenBurns_25s_ease-in-out_infinite_alternate]"
          />
        ) : (
          <div className="h-full w-full" style={{ backgroundColor: '#0D0D0D' }} />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-black/20" />
      </div>

      {/* Top bar — logo + social */}
      <div className="relative z-10 flex items-center justify-between px-6 sm:px-10 pt-6 sm:pt-8">
        <div className="flex items-center gap-3">
          {branding.brand_logo_url ? (
            <img src={branding.brand_logo_url} alt={displayName} className="h-8 sm:h-10 w-auto object-contain brightness-0 invert" />
          ) : (
            <span className="font-serif text-[15px] sm:text-[17px] text-white/80 tracking-wide font-medium">{displayName}</span>
          )}
        </div>
        <div className="flex items-center gap-3">
          {socialLinks.map(({ icon: Icon, href }, i) => (
            <a
              key={i}
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white/60 hover:bg-white/20 hover:text-white transition-all duration-300"
            >
              <Icon className="h-4 w-4" />
            </a>
          ))}
        </div>
      </div>

      {/* Center content */}
      <div className="relative z-10 flex flex-col items-center justify-end min-h-[100dvh] px-6 sm:px-10 pb-16 sm:pb-20">
        <div className="text-center mb-8">
          <h1 className="font-serif text-4xl sm:text-6xl lg:text-7xl font-light text-white leading-[1.05] tracking-tight max-w-3xl">
            {event.name}
          </h1>
          <div className="flex items-center justify-center gap-3 mt-5">
            <span className="text-[11px] sm:text-[12px] uppercase tracking-[0.2em] text-white/40 font-sans font-medium">
              {formattedDate}
            </span>
            {event.location && (
              <>
                <span className="w-1 h-1 rounded-full bg-white/20" />
                <span className="text-[11px] sm:text-[12px] uppercase tracking-[0.2em] text-white/40 font-sans font-medium">
                  {event.location}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Enter button */}
        <button
          onClick={handleEnter}
          className="group relative px-10 sm:px-14 py-4 sm:py-5 text-[11px] sm:text-[12px] uppercase tracking-[0.25em] font-sans font-semibold text-white transition-all duration-500 hover:tracking-[0.35em] overflow-hidden rounded-none"
          style={{ backgroundColor: accent }}
        >
          <span className="relative z-10">Enter Gallery</span>
          <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500 ease-out" />
        </button>

        {photoCount > 0 && (
          <p className="mt-5 text-[10px] text-white/25 tracking-[0.15em] uppercase font-sans">
            {photoCount} Moments Captured
          </p>
        )}
      </div>

      {/* PIN Overlay */}
      {showPin && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xl animate-fade-in">
          <div className={`bg-white/10 backdrop-blur-2xl border border-white/10 p-8 sm:p-10 max-w-sm w-full mx-4 text-center space-y-6 rounded-sm ${shaking ? 'animate-[shake_0.5s_ease-in-out]' : ''}`}>
            <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mx-auto">
              <Lock className="h-5 w-5 text-white/60" />
            </div>
            <div>
              <h2 className="font-serif text-xl text-white font-medium">Private Gallery</h2>
              <p className="text-[11px] text-white/40 mt-2 tracking-wide">Enter the PIN to continue</p>
            </div>
            <OtpInput length={4} onComplete={handlePinComplete} />
            {pinError && (
              <p className="text-[10px] text-red-400 tracking-wide">Incorrect PIN. Try again.</p>
            )}
            <button
              onClick={() => setShowPin(false)}
              className="text-[10px] text-white/30 hover:text-white/50 transition-colors tracking-wide uppercase"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Transition overlay */}
      {transitioning && (
        <div className="fixed inset-0 z-50 flex items-center justify-center animate-fade-in" style={{ backgroundColor: accent }}>
          <div className="text-center">
            {branding.brand_logo_url ? (
              <img src={branding.brand_logo_url} alt="" className="h-10 object-contain mx-auto mb-4 brightness-0 invert" />
            ) : (
              <p className="font-serif text-xl text-white mb-4">{displayName}</p>
            )}
            <div className="w-8 h-[1px] bg-white/30 mx-auto animate-[pulse_1s_ease-in-out_infinite]" />
          </div>
        </div>
      )}

      {/* Powered by */}
      <div className="absolute bottom-4 left-0 right-0 text-center z-10">
        <p className="text-[8px] text-white/15 tracking-[0.2em] uppercase font-sans">Powered by MirrorAI</p>
      </div>

      <GalleryInstallPrompt studioName={displayName} eventName={event.name} />

      <style>{`
        @keyframes kenBurns {
          0% { transform: scale(1.05) translate(0, 0); }
          100% { transform: scale(1.12) translate(-1%, -1%); }
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-8px); }
          40% { transform: translateX(8px); }
          60% { transform: translateX(-4px); }
          80% { transform: translateX(4px); }
        }
      `}</style>
    </div>
  );
}
