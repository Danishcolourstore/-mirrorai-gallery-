
import React,{useEffect} from 'react';

export default function PhotoViewer({url,onClose}:{url:string,onClose:()=>void}){
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{ if(e.key==='Escape') onClose() };
    window.addEventListener('keydown',h);
    return()=>window.removeEventListener('keydown',h);
  },[onClose]);

  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50" onClick={onClose}>
      <img src={url} alt="viewer" className="max-h-[90%] max-w-[90%]"/>
    </div>
  )
}
