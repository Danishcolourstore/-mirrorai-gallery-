import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("rounded-md", className)}
      style={{
        background: 'linear-gradient(90deg, hsl(32 18% 89%) 0%, hsl(32 18% 93%) 50%, hsl(32 18% 89%) 100%)',
        backgroundSize: '200% 100%',
        animation: 'skeleton-shimmer 1.5s ease-in-out infinite',
      }}
      {...props}
    />
  );
}

export { Skeleton };
