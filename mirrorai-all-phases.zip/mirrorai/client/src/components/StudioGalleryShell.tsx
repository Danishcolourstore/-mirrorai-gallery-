import { ReactNode } from 'react';
import { Instagram, Globe, Phone, Mail, Heart } from 'lucide-react';

interface StudioBranding {
  studio_name: string;
  brand_name?: string | null;
  brand_logo_url?: string | null;
  brand_color?: string | null;
  tagline?: string | null;
  instagram?: string | null;
  whatsapp?: string | null;
  website_url?: string | null;
  social_instagram?: string | null;
  social_website?: string | null;
}

interface Props {
  branding: StudioBranding;
  eventName: string;
  children: ReactNode;
}

export function StudioGalleryNav({ branding }: { branding: StudioBranding }) {
  const accent = branding.brand_color || '#C4956A';
  const displayName = branding.brand_name || branding.studio_name;
  const ig = branding.instagram || branding.social_instagram;
  const web = branding.website_url || branding.social_website;

  return (
    <nav
      className="sticky top-0 z-40 flex items-center justify-between px-5 sm:px-8 py-3 backdrop-blur-xl border-b transition-all duration-300"
      style={{ backgroundColor: `${accent}F0`, borderColor: `${accent}30` }}
    >
      <div className="flex items-center gap-3">
        {branding.brand_logo_url ? (
          <img src={branding.brand_logo_url} alt="" className="h-6 sm:h-7 w-auto object-contain brightness-0 invert" />
        ) : (
          <span className="font-serif text-[13px] sm:text-[14px] text-white font-medium tracking-wide">{displayName}</span>
        )}
      </div>

      <div className="hidden sm:block">
        <span className="font-serif text-[13px] text-white/80 tracking-wide">{displayName}</span>
      </div>

      <div className="flex items-center gap-2">
        {ig && (
          <a
            href={`https://instagram.com/${ig.replace('@', '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-white/20 hover:text-white transition-all"
          >
            <Instagram className="h-3.5 w-3.5" />
          </a>
        )}
        {web && (
          <a
            href={web.startsWith('http') ? web : `https://${web}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-white/20 hover:text-white transition-all"
          >
            <Globe className="h-3.5 w-3.5" />
          </a>
        )}
        {branding.whatsapp && (
          <a
            href={`https://wa.me/${branding.whatsapp.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/60 hover:bg-white/20 hover:text-white transition-all"
          >
            <Phone className="h-3.5 w-3.5" />
          </a>
        )}
      </div>
    </nav>
  );
}

export function StudioGalleryFooter({ branding, studioSlug }: { branding: StudioBranding; studioSlug?: string }) {
  const accent = branding.brand_color || '#C4956A';
  const displayName = branding.brand_name || branding.studio_name;
  const ig = branding.instagram || branding.social_instagram;
  const web = branding.website_url || branding.social_website;
  const bookUrl = branding.whatsapp
    ? `https://wa.me/${branding.whatsapp.replace(/\D/g, '')}?text=Hi! I'd love to book a session.`
    : web
      ? (web.startsWith('http') ? web : `https://${web}`)
      : null;

  return (
    <footer className="py-16 sm:py-20" style={{ backgroundColor: '#0D0D0D' }}>
      <div className="max-w-lg mx-auto px-6 text-center space-y-6">
        {/* Logo */}
        {branding.brand_logo_url ? (
          <img src={branding.brand_logo_url} alt="" className="h-10 sm:h-12 w-auto object-contain mx-auto brightness-0 invert opacity-70" />
        ) : (
          <h3 className="font-serif text-2xl sm:text-3xl text-white/80 font-light tracking-tight">{displayName}</h3>
        )}

        {/* Tagline */}
        {branding.tagline && (
          <p className="text-[11px] text-white/30 tracking-[0.15em] uppercase font-sans">{branding.tagline}</p>
        )}

        {/* Divider */}
        <div className="w-12 h-[1px] mx-auto" style={{ backgroundColor: `${accent}60` }} />

        {/* Social icons */}
        <div className="flex items-center justify-center gap-4">
          {ig && (
            <a
              href={`https://instagram.com/${ig.replace('@', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:border-white/30 transition-all duration-300"
            >
              <Instagram className="h-4 w-4" />
            </a>
          )}
          {web && (
            <a
              href={web.startsWith('http') ? web : `https://${web}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:border-white/30 transition-all duration-300"
            >
              <Globe className="h-4 w-4" />
            </a>
          )}
          {branding.whatsapp && (
            <a
              href={`https://wa.me/${branding.whatsapp.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:border-white/30 transition-all duration-300"
            >
              <Phone className="h-4 w-4" />
            </a>
          )}
        </div>

        {/* Book button */}
        {bookUrl && (
          <a
            href={bookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-3 text-[10px] uppercase tracking-[0.2em] font-sans font-semibold text-white transition-all duration-300 hover:opacity-80 rounded-none"
            style={{ backgroundColor: accent }}
          >
            Book Your Session
          </a>
        )}

        {/* Studio page link */}
        {studioSlug && (
          <a
            href={`/studio/${studioSlug}`}
            className="block text-[10px] text-white/20 hover:text-white/40 transition-colors tracking-[0.1em] uppercase font-sans mt-4"
          >
            All galleries by {displayName}
          </a>
        )}

        {/* Powered by */}
        <p className="text-[8px] text-white/10 tracking-[0.2em] uppercase font-sans pt-6">
          Powered by MirrorAI
        </p>
      </div>
    </footer>
  );
}
