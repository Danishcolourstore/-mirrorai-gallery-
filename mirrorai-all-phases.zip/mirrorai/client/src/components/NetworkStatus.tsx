import { useEffect, useState, useCallback } from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';

export function NetworkStatus() {
  const [online, setOnline] = useState(navigator.onLine);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const handleOnline = () => { setOnline(true); setDismissed(false); };
    const handleOffline = () => { setOnline(false); setDismissed(false); };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleRetry = useCallback(() => {
    // Trigger a lightweight fetch to re-check connectivity
    fetch(window.location.origin, { method: 'HEAD', mode: 'no-cors' })
      .then(() => setOnline(true))
      .catch(() => {});
  }, []);

  if (online || dismissed) return null;

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[9999] flex items-center justify-center gap-3 px-4 py-2.5"
      style={{ backgroundColor: '#1A1A1A' }}
    >
      <span
        className="h-2 w-2 rounded-full shrink-0"
        style={{
          backgroundColor: '#C9A96E',
          animation: 'pulse 1.5s ease-in-out infinite',
        }}
      />
      <WifiOff className="h-3.5 w-3.5 text-white/70 shrink-0" />
      <span className="text-white text-[12px] font-sans font-medium">
        No internet connection
      </span>
      <button
        onClick={handleRetry}
        className="ml-auto flex items-center gap-1.5 text-[11px] font-sans font-medium px-3 py-1 rounded-full transition-colors shrink-0"
        style={{ backgroundColor: 'rgba(201,169,110,0.2)', color: '#C9A96E' }}
      >
        <RefreshCw className="h-3 w-3" />
        Retry
      </button>
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
      `}</style>
    </div>
  );
}
