import { useState, useEffect } from 'react';
import { QrCode, Download, Users, Camera, Image } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { QRCodeSVG } from 'qrcode.react';

interface VenueQRPanelProps {
  eventId: string;
  eventSlug: string;
  eventName: string;
}

export function VenueQRPanel({ eventId, eventSlug, eventName }: VenueQRPanelProps) {
  const [scanCount, setScanCount] = useState(0);
  const [photosFound, setPhotosFound] = useState(0);
  const [showQR, setShowQR] = useState(false);

  const findMeUrl = `${window.location.origin}/find-me/${eventSlug}`;

  useEffect(() => {
    (async () => {
      const { data } = await (supabase.from('venue_qr_scans' as any).select('id, matched_photo_ids') as any)
        .eq('event_id', eventId);
      if (data) {
        setScanCount(data.length);
        const total = (data as any[]).reduce((acc: number, s: any) => acc + (s.matched_photo_ids?.length ?? 0), 0);
        setPhotosFound(total);
      }
    })();
  }, [eventId]);

  const downloadQR = () => {
    const svg = document.getElementById('venue-qr-svg');
    if (!svg) return;

    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 1400;
    const ctx = canvas.getContext('2d')!;

    // Background
    ctx.fillStyle = '#FAFAF8';
    ctx.fillRect(0, 0, 1024, 1400);

    // Top gold bar
    ctx.fillStyle = '#C4956A';
    ctx.fillRect(0, 0, 1024, 6);

    // Title
    ctx.fillStyle = '#2D231A';
    ctx.font = 'italic 48px "Cormorant Garamond", Georgia, serif';
    ctx.textAlign = 'center';
    ctx.fillText('Find Your Moments', 512, 100);

    // Event name
    ctx.font = '28px "Inter", sans-serif';
    ctx.fillStyle = '#8B7355';
    ctx.fillText(eventName, 512, 150);

    // QR Code as image
    const svgData = new XMLSerializer().serializeToString(svg);
    const img = new window.Image();
    img.onload = () => {
      ctx.drawImage(img, 212, 200, 600, 600);

      // Instructions
      ctx.fillStyle = '#2D231A';
      ctx.font = '24px "Inter", sans-serif';
      ctx.fillText('Scan this QR code', 512, 880);
      ctx.font = '20px "Inter", sans-serif';
      ctx.fillStyle = '#8B7355';
      ctx.fillText('Take a selfie and instantly find all your photos', 512, 920);

      // Branding
      ctx.fillStyle = '#C4956A';
      ctx.fillRect(462, 970, 100, 2);
      ctx.font = 'italic 22px "Cormorant Garamond", Georgia, serif';
      ctx.fillText('MirrorAI', 512, 1010);

      // URL
      ctx.font = '14px monospace';
      ctx.fillStyle = '#B0A090';
      ctx.fillText(findMeUrl, 512, 1060);

      // Bottom bar
      ctx.fillStyle = '#C4956A';
      ctx.fillRect(0, 1394, 1024, 6);

      canvas.toBlob(blob => {
        if (!blob) return;
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `find-me-qr-${eventSlug}.png`;
        a.click();
        URL.revokeObjectURL(a.href);
      });
    };
    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  return (
    <div className="border border-border bg-card p-5 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <QrCode className="h-4 w-4 text-primary" />
          <p className="text-[12px] font-semibold text-foreground uppercase tracking-[0.1em]">Find Your Moment — QR</p>
          <span className="text-[8px] bg-primary/10 text-primary font-bold px-1.5 py-0.5 uppercase tracking-wider">World First</span>
        </div>
        <Button size="sm" variant="outline" onClick={() => setShowQR(!showQR)} className="h-7 text-[10px] uppercase tracking-wider">
          {showQR ? 'Hide QR' : 'Show QR'}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="text-center bg-secondary/30 py-3">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Camera className="h-3 w-3 text-muted-foreground/40" />
          </div>
          <p className="text-[16px] font-semibold text-foreground">{scanCount}</p>
          <p className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/50">Scans</p>
        </div>
        <div className="text-center bg-secondary/30 py-3">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Image className="h-3 w-3 text-muted-foreground/40" />
          </div>
          <p className="text-[16px] font-semibold text-foreground">{photosFound}</p>
          <p className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/50">Photos Found</p>
        </div>
        <div className="text-center bg-secondary/30 py-3">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Users className="h-3 w-3 text-muted-foreground/40" />
          </div>
          <p className="text-[16px] font-semibold text-foreground">{scanCount}</p>
          <p className="text-[9px] uppercase tracking-[0.1em] text-muted-foreground/50">Guests Served</p>
        </div>
      </div>

      {showQR && (
        <div className="animate-fade-in space-y-4">
          <div className="flex flex-col items-center gap-4 py-4">
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <QRCodeSVG
                id="venue-qr-svg"
                value={findMeUrl}
                size={200}
                level="H"
                fgColor="#2D231A"
                bgColor="#FFFFFF"
              />
            </div>
            <div className="text-center">
              <p className="text-[11px] text-muted-foreground/60 font-mono">{findMeUrl}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button size="sm" onClick={downloadQR} className="flex-1 h-8 text-[10px] uppercase tracking-wider">
              <Download className="h-3 w-3 mr-1.5" /> Download Print Card
            </Button>
            <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(findMeUrl); }} className="h-8 text-[10px] uppercase tracking-wider">
              Copy Link
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
