import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Check, Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Photo {
  id: string;
  url: string;
  file_name: string | null;
}

interface SneakPeekModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  eventId: string;
  eventSlug: string;
  photos: Photo[];
  onCreated: () => void;
}

export function SneakPeekModal({ open, onOpenChange, eventId, eventSlug, photos, onCreated }: SneakPeekModalProps) {
  const { toast } = useToast();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [message, setMessage] = useState("Here's a little preview of your beautiful day. 🤍\nFull gallery coming soon.");
  const [downloadsEnabled, setDownloadsEnabled] = useState(false);
  const [saving, setSaving] = useState(false);

  const toggle = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else if (next.size < 15) next.add(id);
      return next;
    });
  };

  const handleCreate = async () => {
    if (selectedIds.size < 3) {
      toast({ title: 'Select at least 3 photos', variant: 'destructive' });
      return;
    }
    setSaving(true);

    const { error } = await (supabase.from('sneak_peeks' as any).insert({
      event_id: eventId,
      photo_ids: Array.from(selectedIds),
      message,
      downloads_enabled: downloadsEnabled,
      is_active: true,
    }) as any);

    if (!error) {
      await supabase.from('events').update({ sneak_peek_active: true } as any).eq('id', eventId);
      toast({ title: 'Sneak Peek created!' });
      onCreated();
      onOpenChange(false);
    } else {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
    setSaving(false);
  };

  const sneakPeekUrl = `${window.location.origin}/event/${eventSlug}/sneakpeek`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[540px] bg-card border-border p-6 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-serif text-xl font-light flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-gold" />Send Sneak Peek
          </DialogTitle>
          <p className="text-[12px] text-muted-foreground/60 font-sans mt-1">Share your best shots before the full gallery is ready</p>
        </DialogHeader>

        <div className="space-y-4 mt-3">
          {/* Photo selector */}
          <div>
            <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70 font-medium mb-2 block">
              Select photos ({selectedIds.size} / 15)
            </Label>
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-1.5 max-h-[240px] overflow-y-auto">
              {photos.map(photo => {
                const selected = selectedIds.has(photo.id);
                return (
                  <button key={photo.id} onClick={() => toggle(photo.id)}
                    className={`relative aspect-square overflow-hidden border-2 transition-all ${
                      selected ? 'border-gold' : 'border-transparent hover:border-border'
                    }`}>
                    <img src={photo.url} alt="" className="h-full w-full object-cover" loading="lazy" />
                    {selected && (
                      <div className="absolute inset-0 bg-gold/20 flex items-center justify-center">
                        <Check className="h-5 w-5 text-gold" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Message */}
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70 font-medium">Message to client</Label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full h-20 bg-background border border-border rounded-sm px-3 py-2 text-[13px] resize-none focus:border-gold focus:outline-none"
            />
          </div>

          {/* Downloads */}
          <div className="flex items-center justify-between">
            <Label className="text-[12px] text-foreground/80 font-normal">Allow downloads</Label>
            <Switch checked={downloadsEnabled} onCheckedChange={setDownloadsEnabled} />
          </div>

          {/* Sneak peek URL preview */}
          {selectedIds.size >= 3 && (
            <div className="bg-background border border-border p-3 space-y-1">
              <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/60">Sneak Peek Link</p>
              <p className="text-[12px] text-foreground font-mono break-all">{sneakPeekUrl}</p>
            </div>
          )}

          <Button onClick={handleCreate} disabled={saving || selectedIds.size < 3}
            className="w-full bg-gold hover:opacity-[0.88] text-foreground h-11 text-[12px] tracking-[0.1em] font-medium rounded-sm">
            {saving ? 'Creating...' : `Create Sneak Peek → (${selectedIds.size} photos)`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
