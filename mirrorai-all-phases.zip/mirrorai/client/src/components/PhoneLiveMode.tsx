import { useState, useRef, useCallback } from 'react';
import { Camera, Radio, X, Loader2, ImagePlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;

interface PhoneLiveModeProps {
  eventId: string;
  userId: string;
  accessToken: string;
  onPhotoUploaded?: () => void;
}

export function PhoneLiveMode({ eventId, userId, accessToken, onPhotoUploaded }: PhoneLiveModeProps) {
  const { toast } = useToast();
  const [isLive, setIsLive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadedCount, setUploadedCount] = useState(0);
  const [currentProgress, setCurrentProgress] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const uploadFile = useCallback(async (file: File) => {
    setUploading(true);
    setCurrentProgress(30);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('event_id', eventId);
      formData.append('user_id', userId);
      formData.append('camera_model', 'Phone Live Mode');

      setCurrentProgress(60);

      const res = await fetch(`${SUPABASE_URL}/functions/v1/camera-ftp-ingest`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${accessToken}` },
        body: formData,
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Upload failed' }));
        throw new Error(err.error || 'Upload failed');
      }

      setCurrentProgress(100);
      setUploadedCount(prev => prev + 1);
      onPhotoUploaded?.();
    } catch (err: any) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
    } finally {
      setUploading(false);
      setCurrentProgress(0);
    }
  }, [eventId, userId, accessToken, toast, onPhotoUploaded]);

  const handleCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(f => uploadFile(f));
    e.target.value = '';
  };

  if (!isLive) {
    return (
      <Button
        onClick={() => setIsLive(true)}
        className="w-full bg-primary hover:bg-primary/85 text-primary-foreground h-10 text-[11px] uppercase tracking-[0.08em] font-medium"
      >
        <Radio className="mr-1.5 h-3.5 w-3.5" /> Go Live — Phone Mode
      </Button>
    );
  }

  return (
    <div className="border border-primary/30 bg-primary/5 p-4 space-y-3 animate-fade-in">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-destructive" />
          </span>
          <span className="text-[11px] uppercase tracking-[0.08em] font-medium text-foreground">
            LIVE — {uploadedCount} photos uploaded
          </span>
        </div>
        <button onClick={() => setIsLive(false)} className="text-muted-foreground hover:text-foreground p-1">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {uploading && <Progress value={currentProgress} className="h-1" />}

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        multiple
        onChange={handleCapture}
        className="hidden"
      />

      <div className="grid grid-cols-2 gap-2">
        <Button
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          variant="outline"
          className="h-16 flex-col gap-1 border-border text-foreground"
        >
          {uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Camera className="h-5 w-5" />}
          <span className="text-[10px] uppercase tracking-[0.06em]">Capture</span>
        </Button>
        <Button
          onClick={() => {
            const inp = document.createElement('input');
            inp.type = 'file';
            inp.accept = 'image/*';
            inp.multiple = true;
            inp.onchange = (e) => {
              const files = (e.target as HTMLInputElement).files;
              if (files) Array.from(files).forEach(f => uploadFile(f));
            };
            inp.click();
          }}
          disabled={uploading}
          variant="outline"
          className="h-16 flex-col gap-1 border-border text-foreground"
        >
          {uploading ? <Loader2 className="h-5 w-5 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
          <span className="text-[10px] uppercase tracking-[0.06em]">Gallery</span>
        </Button>
      </div>
    </div>
  );
}
