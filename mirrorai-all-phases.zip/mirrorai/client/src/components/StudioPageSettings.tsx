import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Eye, Layout, Type, Sparkles } from 'lucide-react';

const BUTTON_TEXT_SUGGESTIONS = [
  'See your forever. 🤍',
  'Open your gallery →',
  'See your photos →',
  'Your memories await →',
  'Enter gallery →',
];

const POSITION_OPTIONS = [
  { value: 'floating', label: 'Always visible', desc: 'Floating button, bottom right corner, always on screen' },
  { value: 'after_hero', label: 'After hero', desc: 'Button at bottom of hero section' },
  { value: 'end_of_page', label: 'End of page', desc: 'Button at very bottom after all sections' },
];

const STYLE_OPTIONS = [
  { value: 'bold', label: 'Bold', desc: 'Full width dark button, white text', bg: '#1A1A1A', fg: '#fff' },
  { value: 'gold', label: 'Gold', desc: 'Full width gold button, dark text', bg: '#C9A96E', fg: '#1A1A1A' },
  { value: 'minimal', label: 'Minimal', desc: 'Outlined button, gold border + text', bg: 'transparent', fg: '#C9A96E', border: '#C9A96E' },
];

interface StudioPageSettingsProps {
  userId: string;
}

export function StudioPageSettings({ userId }: StudioPageSettingsProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [sections, setSections] = useState({
    about: false, portfolio: false, services: false, testimonials: false, instagram: false,
  });
  const [buttonText, setButtonText] = useState('See your forever. 🤍');
  const [buttonPosition, setButtonPosition] = useState('floating');
  const [buttonStyle, setButtonStyle] = useState('gold');
  const [aboutName, setAboutName] = useState('');
  const [aboutBio, setAboutBio] = useState('');
  const [aboutPortraitUrl, setAboutPortraitUrl] = useState('');
  const [portraitFile, setPortraitFile] = useState<File | null>(null);
  const [whatsappButtonText, setWhatsappButtonText] = useState('Book a Shoot');

  useEffect(() => {
    if (!userId) return;
    (supabase.from('studio_profiles' as any).select('*') as any)
      .eq('user_id', userId)
      .maybeSingle()
      .then(({ data }: any) => {
        if (data) {
          setSections(data.hero_sections_enabled || { about: false, portfolio: false, services: false, testimonials: false, instagram: false });
          setButtonText(data.button_text || 'See your forever. 🤍');
          setButtonPosition(data.button_position || 'floating');
          setButtonStyle(data.button_style || 'gold');
          setAboutName(data.about_name || '');
          setAboutBio(data.about_bio || '');
          setAboutPortraitUrl(data.about_portrait_url || '');
          setWhatsappButtonText(data.whatsapp_button_text || 'Book a Shoot');
        }
      });
  }, [userId]);

  const save = async () => {
    setLoading(true);
    let finalPortraitUrl = aboutPortraitUrl;

    if (portraitFile) {
      const ext = portraitFile.name.split('.').pop();
      const path = `${userId}/about-portrait-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from('event-covers').upload(path, portraitFile);
      if (!upErr) {
        const { data: { publicUrl } } = supabase.storage.from('event-covers').getPublicUrl(path);
        finalPortraitUrl = publicUrl;
      }
    }

    const payload: any = {
      hero_sections_enabled: sections,
      button_text: buttonText,
      button_position: buttonPosition,
      button_style: buttonStyle,
      about_name: aboutName || null,
      about_bio: aboutBio || null,
      about_portrait_url: finalPortraitUrl || null,
      whatsapp_button_text: whatsappButtonText,
      updated_at: new Date().toISOString(),
    };

    const { error } = await (supabase.from('studio_profiles' as any).update(payload) as any).eq('user_id', userId);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else toast({ title: 'Studio page settings saved' });
    setLoading(false);
  };

  const toggleSection = (key: string) => {
    setSections(s => ({ ...s, [key]: !s[key as keyof typeof s] }));
  };

  return (
    <div className="space-y-6">
      <div className="space-y-1">
        <h3 className="font-serif text-lg font-medium text-foreground flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-[#C9A96E]" /> Studio Page Settings
        </h3>
        <p className="text-[10px] text-muted-foreground/60 font-sans">Choose what clients see before entering your gallery</p>
      </div>

      {/* Section toggles */}
      <div className="space-y-3">
        <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70">Sections</Label>
        <div className="space-y-2">
          <div className="flex items-center justify-between py-2 px-3 rounded bg-muted/30">
            <span className="text-[12px] font-sans">✦ Hero</span>
            <span className="text-[10px] text-muted-foreground/50">Always on</span>
          </div>
          {[
            { key: 'about', label: 'About & Bio' },
            { key: 'portfolio', label: 'Portfolio preview' },
            { key: 'services', label: 'Services' },
            { key: 'testimonials', label: 'Testimonials' },
            { key: 'instagram', label: 'Instagram feed' },
          ].map(s => (
            <div key={s.key} className="flex items-center justify-between py-2 px-3 rounded bg-muted/30">
              <span className="text-[12px] font-sans">{s.label}</span>
              <Switch checked={sections[s.key as keyof typeof sections]} onCheckedChange={() => toggleSection(s.key)} />
            </div>
          ))}
        </div>
      </div>

      {/* About section fields */}
      {sections.about && (
        <div className="space-y-3 p-4 rounded-lg border border-border bg-card">
          <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70">About Section</Label>
          <Input value={aboutName} onChange={e => setAboutName(e.target.value)}
            placeholder="Your name" className="h-9 text-[13px]" />
          <Textarea value={aboutBio} onChange={e => setAboutBio(e.target.value)}
            placeholder="Tell your story..." className="text-[13px] min-h-[100px]" />
          {aboutPortraitUrl && <img src={aboutPortraitUrl} alt="Portrait" className="h-20 rounded object-cover" />}
          <Input type="file" accept="image/*" onChange={e => setPortraitFile(e.target.files?.[0] || null)}
            className="h-9 text-[13px]" />
        </div>
      )}

      {/* Button text */}
      <div className="space-y-2">
        <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70 flex items-center gap-1">
          <Type className="h-3 w-3" /> Button Text
        </Label>
        <Input value={buttonText} onChange={e => setButtonText(e.target.value)} className="h-9 text-[13px]" />
        <div className="flex flex-wrap gap-1.5">
          {BUTTON_TEXT_SUGGESTIONS.map(s => (
            <button key={s} onClick={() => setButtonText(s)}
              className="text-[10px] px-2.5 py-1 rounded-full border border-border hover:bg-muted/50 transition-colors font-sans">
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Button position */}
      <div className="space-y-2">
        <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70 flex items-center gap-1">
          <Layout className="h-3 w-3" /> Button Position
        </Label>
        <div className="grid grid-cols-3 gap-2">
          {POSITION_OPTIONS.map(p => (
            <button key={p.value} onClick={() => setButtonPosition(p.value)}
              className={`p-3 rounded-lg border text-left transition-all ${buttonPosition === p.value ? 'border-[#C9A96E] bg-[#C9A96E]/5' : 'border-border hover:border-muted-foreground/30'}`}>
              <span className="text-[11px] font-medium font-sans block">{p.label}</span>
              <span className="text-[9px] text-muted-foreground/50 font-sans mt-1 block leading-tight">{p.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Button style */}
      <div className="space-y-2">
        <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70 flex items-center gap-1">
          <Eye className="h-3 w-3" /> Button Style
        </Label>
        <div className="grid grid-cols-3 gap-2">
          {STYLE_OPTIONS.map(s => (
            <button key={s.value} onClick={() => setButtonStyle(s.value)}
              className={`p-3 rounded-lg border text-center transition-all ${buttonStyle === s.value ? 'border-[#C9A96E] bg-[#C9A96E]/5' : 'border-border hover:border-muted-foreground/30'}`}>
              <div className="h-8 rounded-sm flex items-center justify-center text-[10px] font-medium mb-1.5"
                style={{ backgroundColor: s.bg, color: s.fg, border: s.border ? `1.5px solid ${s.border}` : 'none' }}>
                {s.label}
              </div>
              <span className="text-[9px] text-muted-foreground/50 font-sans">{s.desc}</span>
            </button>
          ))}
        </div>
      </div>

      {/* WhatsApp button text */}
      <div className="space-y-2">
        <Label className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/70">WhatsApp Button Text</Label>
        <Input value={whatsappButtonText} onChange={e => setWhatsappButtonText(e.target.value)}
          placeholder="Book a Shoot" className="h-9 text-[13px]" />
      </div>

      <Button onClick={save} disabled={loading}
        className="w-full bg-[#C9A96E] hover:bg-[#C9A96E]/85 text-[#1A1A1A] h-10 text-[11px] tracking-[0.12em] uppercase font-medium">
        {loading ? 'Saving…' : 'Save Studio Page Settings'}
      </Button>
    </div>
  );
}
