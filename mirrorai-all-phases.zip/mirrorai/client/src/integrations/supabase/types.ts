export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      admin_activity_log: {
        Row: {
          action: string
          created_at: string
          device_info: string | null
          id: string
          user_email: string
        }
        Insert: {
          action: string
          created_at?: string
          device_info?: string | null
          id?: string
          user_email: string
        }
        Update: {
          action?: string
          created_at?: string
          device_info?: string | null
          id?: string
          user_email?: string
        }
        Relationships: []
      }
      admin_credentials: {
        Row: {
          credential_id: string
          id: string
          last_used_at: string | null
          public_key: string | null
          registered_at: string
          user_id: string
        }
        Insert: {
          credential_id: string
          id?: string
          last_used_at?: string | null
          public_key?: string | null
          registered_at?: string
          user_id: string
        }
        Update: {
          credential_id?: string
          id?: string
          last_used_at?: string | null
          public_key?: string | null
          registered_at?: string
          user_id?: string
        }
        Relationships: []
      }
      admin_emails: {
        Row: {
          id: string
          message: string
          recipient_count: number
          sent_at: string
          sent_by: string | null
          sent_to: string
          subject: string
        }
        Insert: {
          id?: string
          message: string
          recipient_count?: number
          sent_at?: string
          sent_by?: string | null
          sent_to?: string
          subject: string
        }
        Update: {
          id?: string
          message?: string
          recipient_count?: number
          sent_at?: string
          sent_by?: string | null
          sent_to?: string
          subject?: string
        }
        Relationships: []
      }
      album_selections: {
        Row: {
          client_name: string
          client_phone: string
          event_id: string
          id: string
          is_reviewed: boolean
          reviewed_at: string | null
          selected_photo_ids: string[]
          selection_order: Json
          submitted_at: string
        }
        Insert: {
          client_name?: string
          client_phone?: string
          event_id: string
          id?: string
          is_reviewed?: boolean
          reviewed_at?: string | null
          selected_photo_ids?: string[]
          selection_order?: Json
          submitted_at?: string
        }
        Update: {
          client_name?: string
          client_phone?: string
          event_id?: string
          id?: string
          is_reviewed?: boolean
          reviewed_at?: string | null
          selected_photo_ids?: string[]
          selection_order?: Json
          submitted_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "album_selections_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      blog_posts: {
        Row: {
          content: string | null
          cover_url: string | null
          created_at: string | null
          event_id: string | null
          id: string
          published: boolean | null
          seo_description: string | null
          seo_title: string | null
          slug: string
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content?: string | null
          cover_url?: string | null
          created_at?: string | null
          event_id?: string | null
          id?: string
          published?: boolean | null
          seo_description?: string | null
          seo_title?: string | null
          slug: string
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string | null
          cover_url?: string | null
          created_at?: string | null
          event_id?: string | null
          id?: string
          published?: boolean | null
          seo_description?: string | null
          seo_title?: string | null
          slug?: string
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "blog_posts_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      chapter_photos: {
        Row: {
          chapter_id: string
          id: string
          order_index: number
          photo_id: string
        }
        Insert: {
          chapter_id: string
          id?: string
          order_index?: number
          photo_id: string
        }
        Update: {
          chapter_id?: string
          id?: string
          order_index?: number
          photo_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chapter_photos_chapter_id_fkey"
            columns: ["chapter_id"]
            isOneToOne: false
            referencedRelation: "gallery_chapters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chapter_photos_photo_id_fkey"
            columns: ["photo_id"]
            isOneToOne: false
            referencedRelation: "photos"
            referencedColumns: ["id"]
          },
        ]
      }
      event_views: {
        Row: {
          created_at: string
          device_type: string
          event_id: string
          id: string
          session_id: string
        }
        Insert: {
          created_at?: string
          device_type?: string
          event_id: string
          id?: string
          session_id: string
        }
        Update: {
          created_at?: string
          device_type?: string
          event_id?: string
          id?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "event_views_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          album_deadline: string | null
          album_max_photos: number
          album_message: string | null
          album_min_photos: number
          album_require_contact: boolean
          album_selection_enabled: boolean
          allow_favorites_download: boolean
          allow_full_download: boolean
          camera_connected: boolean
          camera_model: string | null
          chapters_enabled: boolean
          cover_url: string | null
          created_at: string
          delivery_status: string
          download_password: string | null
          download_requires_password: boolean
          download_resolution: string
          downloads_enabled: boolean
          dual_story_enabled: boolean | null
          event_date: string
          event_type: string
          expires_at: string | null
          face_recognition_enabled: boolean
          ftp_password: string | null
          gallery_layout: string
          gallery_mode: string | null
          gallery_pin: string | null
          gallery_style: string
          id: string
          is_published: boolean
          last_photo_at: string | null
          live_photo_count: number
          livesync_enabled: boolean
          location: string | null
          name: string
          owner_email: string | null
          owner_name: string | null
          owner_permissions: Json | null
          person1_face_token: string | null
          person1_name: string | null
          person2_face_token: string | null
          person2_name: string | null
          photo_count: number
          retouch_enabled: boolean
          retouch_limit: number
          selection_mode_enabled: boolean
          selection_token: string | null
          slug: string
          sneak_peek_active: boolean
          status_updated_at: string | null
          updated_at: string
          user_id: string
          views: number
          watermark_enabled: boolean
        }
        Insert: {
          album_deadline?: string | null
          album_max_photos?: number
          album_message?: string | null
          album_min_photos?: number
          album_require_contact?: boolean
          album_selection_enabled?: boolean
          allow_favorites_download?: boolean
          allow_full_download?: boolean
          camera_connected?: boolean
          camera_model?: string | null
          chapters_enabled?: boolean
          cover_url?: string | null
          created_at?: string
          delivery_status?: string
          download_password?: string | null
          download_requires_password?: boolean
          download_resolution?: string
          downloads_enabled?: boolean
          dual_story_enabled?: boolean | null
          event_date?: string
          event_type?: string
          expires_at?: string | null
          face_recognition_enabled?: boolean
          ftp_password?: string | null
          gallery_layout?: string
          gallery_mode?: string | null
          gallery_pin?: string | null
          gallery_style?: string
          id?: string
          is_published?: boolean
          last_photo_at?: string | null
          live_photo_count?: number
          livesync_enabled?: boolean
          location?: string | null
          name: string
          owner_email?: string | null
          owner_name?: string | null
          owner_permissions?: Json | null
          person1_face_token?: string | null
          person1_name?: string | null
          person2_face_token?: string | null
          person2_name?: string | null
          photo_count?: number
          retouch_enabled?: boolean
          retouch_limit?: number
          selection_mode_enabled?: boolean
          selection_token?: string | null
          slug: string
          sneak_peek_active?: boolean
          status_updated_at?: string | null
          updated_at?: string
          user_id: string
          views?: number
          watermark_enabled?: boolean
        }
        Update: {
          album_deadline?: string | null
          album_max_photos?: number
          album_message?: string | null
          album_min_photos?: number
          album_require_contact?: boolean
          album_selection_enabled?: boolean
          allow_favorites_download?: boolean
          allow_full_download?: boolean
          camera_connected?: boolean
          camera_model?: string | null
          chapters_enabled?: boolean
          cover_url?: string | null
          created_at?: string
          delivery_status?: string
          download_password?: string | null
          download_requires_password?: boolean
          download_resolution?: string
          downloads_enabled?: boolean
          dual_story_enabled?: boolean | null
          event_date?: string
          event_type?: string
          expires_at?: string | null
          face_recognition_enabled?: boolean
          ftp_password?: string | null
          gallery_layout?: string
          gallery_mode?: string | null
          gallery_pin?: string | null
          gallery_style?: string
          id?: string
          is_published?: boolean
          last_photo_at?: string | null
          live_photo_count?: number
          livesync_enabled?: boolean
          location?: string | null
          name?: string
          owner_email?: string | null
          owner_name?: string | null
          owner_permissions?: Json | null
          person1_face_token?: string | null
          person1_name?: string | null
          person2_face_token?: string | null
          person2_name?: string | null
          photo_count?: number
          retouch_enabled?: boolean
          retouch_limit?: number
          selection_mode_enabled?: boolean
          selection_token?: string | null
          slug?: string
          sneak_peek_active?: boolean
          status_updated_at?: string | null
          updated_at?: string
          user_id?: string
          views?: number
          watermark_enabled?: boolean
        }
        Relationships: []
      }
      favorites: {
        Row: {
          created_at: string
          event_id: string
          guest_session_id: string
          id: string
          photo_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          guest_session_id: string
          id?: string
          photo_id: string
        }
        Update: {
          created_at?: string
          event_id?: string
          guest_session_id?: string
          id?: string
          photo_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "favorites_guest_session_id_fkey"
            columns: ["guest_session_id"]
            isOneToOne: false
            referencedRelation: "guest_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "favorites_photo_id_fkey"
            columns: ["photo_id"]
            isOneToOne: false
            referencedRelation: "photos"
            referencedColumns: ["id"]
          },
        ]
      }
      gallery_chapters: {
        Row: {
          cover_photo_id: string | null
          created_at: string
          description: string | null
          event_id: string
          id: string
          name: string
          order_index: number
        }
        Insert: {
          cover_photo_id?: string | null
          created_at?: string
          description?: string | null
          event_id: string
          id?: string
          name: string
          order_index?: number
        }
        Update: {
          cover_photo_id?: string | null
          created_at?: string
          description?: string | null
          event_id?: string
          id?: string
          name?: string
          order_index?: number
        }
        Relationships: [
          {
            foreignKeyName: "gallery_chapters_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      guest_registrations: {
        Row: {
          created_at: string
          email: string
          event_id: string
          face_token: string
          guest_name: string
          id: string
          matched_photo_ids: string[] | null
          status: string
        }
        Insert: {
          created_at?: string
          email: string
          event_id: string
          face_token: string
          guest_name: string
          id?: string
          matched_photo_ids?: string[] | null
          status?: string
        }
        Update: {
          created_at?: string
          email?: string
          event_id?: string
          face_token?: string
          guest_name?: string
          id?: string
          matched_photo_ids?: string[] | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "guest_registrations_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      guest_selection_photos: {
        Row: {
          created_at: string
          id: string
          photo_id: string
          selection_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          photo_id: string
          selection_id: string
        }
        Update: {
          created_at?: string
          id?: string
          photo_id?: string
          selection_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "guest_selection_photos_photo_id_fkey"
            columns: ["photo_id"]
            isOneToOne: false
            referencedRelation: "photos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "guest_selection_photos_selection_id_fkey"
            columns: ["selection_id"]
            isOneToOne: false
            referencedRelation: "guest_selections"
            referencedColumns: ["id"]
          },
        ]
      }
      guest_selections: {
        Row: {
          created_at: string
          event_id: string
          guest_email: string
          guest_name: string
          id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          guest_email: string
          guest_name: string
          id?: string
        }
        Update: {
          created_at?: string
          event_id?: string
          guest_email?: string
          guest_name?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "guest_selections_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      guest_sessions: {
        Row: {
          created_at: string
          event_id: string
          id: string
          last_seen_at: string
          session_token: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          last_seen_at?: string
          session_token: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          last_seen_at?: string
          session_token?: string
        }
        Relationships: [
          {
            foreignKeyName: "guest_sessions_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      inquiries: {
        Row: {
          created_at: string
          email: string
          event_date: string | null
          event_type: string | null
          id: string
          is_read: boolean
          message: string | null
          name: string
          phone: string | null
          studio_id: string
        }
        Insert: {
          created_at?: string
          email: string
          event_date?: string | null
          event_type?: string | null
          id?: string
          is_read?: boolean
          message?: string | null
          name: string
          phone?: string | null
          studio_id: string
        }
        Update: {
          created_at?: string
          email?: string
          event_date?: string | null
          event_type?: string | null
          id?: string
          is_read?: boolean
          message?: string | null
          name?: string
          phone?: string | null
          studio_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "inquiries_studio_id_fkey"
            columns: ["studio_id"]
            isOneToOne: false
            referencedRelation: "studio_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      photo_comments: {
        Row: {
          comment: string
          created_at: string
          event_id: string
          guest_name: string
          id: string
          is_read: boolean
          photo_id: string
        }
        Insert: {
          comment: string
          created_at?: string
          event_id: string
          guest_name?: string
          id?: string
          is_read?: boolean
          photo_id: string
        }
        Update: {
          comment?: string
          created_at?: string
          event_id?: string
          guest_name?: string
          id?: string
          is_read?: boolean
          photo_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "photo_comments_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "photo_comments_photo_id_fkey"
            columns: ["photo_id"]
            isOneToOne: false
            referencedRelation: "photos"
            referencedColumns: ["id"]
          },
        ]
      }
      photo_interactions: {
        Row: {
          created_at: string
          event_id: string
          id: string
          interaction_type: string
          photo_id: string
          session_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          id?: string
          interaction_type: string
          photo_id: string
          session_id: string
        }
        Update: {
          created_at?: string
          event_id?: string
          id?: string
          interaction_type?: string
          photo_id?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "photo_interactions_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "photo_interactions_photo_id_fkey"
            columns: ["photo_id"]
            isOneToOne: false
            referencedRelation: "photos"
            referencedColumns: ["id"]
          },
        ]
      }
      photos: {
        Row: {
          created_at: string
          event_id: string
          file_name: string | null
          file_size: number | null
          id: string
          is_favorite: boolean
          section: string | null
          sort_order: number | null
          url: string
          user_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          file_name?: string | null
          file_size?: number | null
          id?: string
          is_favorite?: boolean
          section?: string | null
          sort_order?: number | null
          url: string
          user_id: string
        }
        Update: {
          created_at?: string
          event_id?: string
          file_name?: string | null
          file_size?: number | null
          id?: string
          is_favorite?: boolean
          section?: string | null
          sort_order?: number | null
          url?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "photos_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      platform_settings: {
        Row: {
          id: string
          key: string
          updated_at: string
          value: string
        }
        Insert: {
          id?: string
          key: string
          updated_at?: string
          value: string
        }
        Update: {
          id?: string
          key?: string
          updated_at?: string
          value?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          brand_color: string | null
          brand_font: string | null
          brand_logo_url: string | null
          brand_name: string | null
          created_at: string
          email: string | null
          gallery_cover_style: string | null
          id: string
          mobile: string | null
          plan: string
          plan_expires_at: string | null
          plan_started_at: string | null
          razorpay_payment_id: string | null
          referral_code: string | null
          referred_by: string | null
          social_instagram: string | null
          social_website: string | null
          storage_limit_mb: number | null
          studio_name: string
          suspended: boolean
          updated_at: string
          user_id: string
          watermark_position: string | null
          watermark_text: string | null
        }
        Insert: {
          avatar_url?: string | null
          brand_color?: string | null
          brand_font?: string | null
          brand_logo_url?: string | null
          brand_name?: string | null
          created_at?: string
          email?: string | null
          gallery_cover_style?: string | null
          id?: string
          mobile?: string | null
          plan?: string
          plan_expires_at?: string | null
          plan_started_at?: string | null
          razorpay_payment_id?: string | null
          referral_code?: string | null
          referred_by?: string | null
          social_instagram?: string | null
          social_website?: string | null
          storage_limit_mb?: number | null
          studio_name?: string
          suspended?: boolean
          updated_at?: string
          user_id: string
          watermark_position?: string | null
          watermark_text?: string | null
        }
        Update: {
          avatar_url?: string | null
          brand_color?: string | null
          brand_font?: string | null
          brand_logo_url?: string | null
          brand_name?: string | null
          created_at?: string
          email?: string | null
          gallery_cover_style?: string | null
          id?: string
          mobile?: string | null
          plan?: string
          plan_expires_at?: string | null
          plan_started_at?: string | null
          razorpay_payment_id?: string | null
          referral_code?: string | null
          referred_by?: string | null
          social_instagram?: string | null
          social_website?: string | null
          storage_limit_mb?: number | null
          studio_name?: string
          suspended?: boolean
          updated_at?: string
          user_id?: string
          watermark_position?: string | null
          watermark_text?: string | null
        }
        Relationships: []
      }
      referrals: {
        Row: {
          created_at: string
          id: string
          referred_id: string | null
          referrer_id: string
          reward_given: boolean
        }
        Insert: {
          created_at?: string
          id?: string
          referred_id?: string | null
          referrer_id: string
          reward_given?: boolean
        }
        Update: {
          created_at?: string
          id?: string
          referred_id?: string | null
          referrer_id?: string
          reward_given?: boolean
        }
        Relationships: []
      }
      retouch_logs: {
        Row: {
          api_response_url: string | null
          created_at: string
          event_id: string
          id: string
          photo_id: string
          retouch_type: string
          session_id: string | null
          status: string
        }
        Insert: {
          api_response_url?: string | null
          created_at?: string
          event_id: string
          id?: string
          photo_id: string
          retouch_type: string
          session_id?: string | null
          status?: string
        }
        Update: {
          api_response_url?: string | null
          created_at?: string
          event_id?: string
          id?: string
          photo_id?: string
          retouch_type?: string
          session_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "retouch_logs_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "retouch_logs_photo_id_fkey"
            columns: ["photo_id"]
            isOneToOne: false
            referencedRelation: "photos"
            referencedColumns: ["id"]
          },
        ]
      }
      shoots: {
        Row: {
          client_name: string
          color_palette: string[] | null
          color_tag: string
          created_at: string
          end_time: string | null
          event_id: string | null
          id: string
          location: string | null
          map_link: string | null
          mood_board_links: string[] | null
          outfit_props: string | null
          reminder_timing: string | null
          shoot_date: string
          shoot_type: string
          shoot_vibe: string | null
          shot_list: string | null
          start_time: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          client_name?: string
          color_palette?: string[] | null
          color_tag?: string
          created_at?: string
          end_time?: string | null
          event_id?: string | null
          id?: string
          location?: string | null
          map_link?: string | null
          mood_board_links?: string[] | null
          outfit_props?: string | null
          reminder_timing?: string | null
          shoot_date?: string
          shoot_type?: string
          shoot_vibe?: string | null
          shot_list?: string | null
          start_time?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          client_name?: string
          color_palette?: string[] | null
          color_tag?: string
          created_at?: string
          end_time?: string | null
          event_id?: string | null
          id?: string
          location?: string | null
          map_link?: string | null
          mood_board_links?: string[] | null
          outfit_props?: string | null
          reminder_timing?: string | null
          shoot_date?: string
          shoot_type?: string
          shoot_vibe?: string | null
          shot_list?: string | null
          start_time?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "shoots_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      sneak_peeks: {
        Row: {
          created_at: string
          downloads_enabled: boolean
          event_id: string
          id: string
          is_active: boolean
          message: string | null
          photo_ids: string[]
        }
        Insert: {
          created_at?: string
          downloads_enabled?: boolean
          event_id: string
          id?: string
          is_active?: boolean
          message?: string | null
          photo_ids?: string[]
        }
        Update: {
          created_at?: string
          downloads_enabled?: boolean
          event_id?: string
          id?: string
          is_active?: boolean
          message?: string | null
          photo_ids?: string[]
        }
        Relationships: [
          {
            foreignKeyName: "sneak_peeks_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
      studio_profiles: {
        Row: {
          about_bio: string | null
          about_name: string | null
          about_portrait_url: string | null
          accent_color: string
          button_position: string
          button_style: string
          button_text: string
          created_at: string
          hero_sections_enabled: Json
          id: string
          instagram: string | null
          logo_url: string | null
          studio_name: string
          tagline: string | null
          updated_at: string
          user_id: string
          website_url: string | null
          whatsapp: string | null
          whatsapp_button_text: string
        }
        Insert: {
          about_bio?: string | null
          about_name?: string | null
          about_portrait_url?: string | null
          accent_color?: string
          button_position?: string
          button_style?: string
          button_text?: string
          created_at?: string
          hero_sections_enabled?: Json
          id?: string
          instagram?: string | null
          logo_url?: string | null
          studio_name?: string
          tagline?: string | null
          updated_at?: string
          user_id: string
          website_url?: string | null
          whatsapp?: string | null
          whatsapp_button_text?: string
        }
        Update: {
          about_bio?: string | null
          about_name?: string | null
          about_portrait_url?: string | null
          accent_color?: string
          button_position?: string
          button_style?: string
          button_text?: string
          created_at?: string
          hero_sections_enabled?: Json
          id?: string
          instagram?: string | null
          logo_url?: string | null
          studio_name?: string
          tagline?: string | null
          updated_at?: string
          user_id?: string
          website_url?: string | null
          whatsapp?: string | null
          whatsapp_button_text?: string
        }
        Relationships: []
      }
      studio_services: {
        Row: {
          created_at: string
          description: string | null
          id: string
          order_index: number | null
          price: string | null
          studio_id: string
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          order_index?: number | null
          price?: string | null
          studio_id: string
          title: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          order_index?: number | null
          price?: string | null
          studio_id?: string
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "studio_services_studio_id_fkey"
            columns: ["studio_id"]
            isOneToOne: false
            referencedRelation: "studio_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      studio_testimonials: {
        Row: {
          client_name: string
          created_at: string
          event_type: string | null
          id: string
          order_index: number | null
          quote: string
          studio_id: string
          user_id: string
        }
        Insert: {
          client_name: string
          created_at?: string
          event_type?: string | null
          id?: string
          order_index?: number | null
          quote: string
          studio_id: string
          user_id: string
        }
        Update: {
          client_name?: string
          created_at?: string
          event_type?: string | null
          id?: string
          order_index?: number | null
          quote?: string
          studio_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "studio_testimonials_studio_id_fkey"
            columns: ["studio_id"]
            isOneToOne: false
            referencedRelation: "studio_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      venue_qr_scans: {
        Row: {
          event_id: string
          face_token: string | null
          guest_name: string | null
          guest_phone: string | null
          id: string
          matched_photo_ids: string[] | null
          scanned_at: string | null
          selfie_url: string | null
        }
        Insert: {
          event_id: string
          face_token?: string | null
          guest_name?: string | null
          guest_phone?: string | null
          id?: string
          matched_photo_ids?: string[] | null
          scanned_at?: string | null
          selfie_url?: string | null
        }
        Update: {
          event_id?: string
          face_token?: string | null
          guest_name?: string | null
          guest_phone?: string | null
          id?: string
          matched_photo_ids?: string[] | null
          scanned_at?: string | null
          selfie_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "venue_qr_scans_event_id_fkey"
            columns: ["event_id"]
            isOneToOne: false
            referencedRelation: "events"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      increment_live_photo_count: {
        Args: { event_id_param: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "photographer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "photographer"],
    },
  },
} as const
