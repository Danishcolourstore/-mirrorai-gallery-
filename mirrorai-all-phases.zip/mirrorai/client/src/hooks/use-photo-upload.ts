import { useState, useCallback, useRef } from 'react';
import { uploadPhotoToR2, testUploadServerConnection } from '@/lib/r2-upload';

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

export interface FileUploadProgress {
  fileName: string;
  loaded: number;
  total: number;
  percent: number;
  status: 'uploading' | 'done' | 'failed';
  error?: string;
}

export interface UploadState {
  isUploading: boolean;
  totalFiles: number;
  completedFiles: number;
  successCount: number;
  failedFiles: File[];
  isDone: boolean;
  percent: number;
  isRetrying: boolean;
  fileProgress: Map<string, FileUploadProgress>;
  errors: string[];
}

const INITIAL: UploadState = {
  isUploading: false,
  totalFiles: 0,
  completedFiles: 0,
  successCount: 0,
  failedFiles: [],
  isDone: false,
  percent: 0,
  isRetrying: false,
  fileProgress: new Map(),
  errors: [],
};

export function usePhotoUpload(eventId: string | undefined, userId: string | undefined) {
  const [state, setState] = useState<UploadState>(INITIAL);
  const abortRef = useRef(false);

  const uploadFiles = useCallback(
    async (files: File[], isRetry = false) => {
      if (!eventId || !userId || files.length === 0) return;
      abortRef.current = false;

      // ── Pre-filter: reject files over 50MB immediately ──
      const validFiles: File[] = [];
      const tooLarge: string[] = [];
      for (const f of files) {
        if (f.size > MAX_FILE_SIZE) {
          tooLarge.push(`"${f.name}" is too large (${(f.size / (1024 * 1024)).toFixed(1)}MB). Maximum 50MB per photo.`);
        } else {
          validFiles.push(f);
        }
      }

      if (validFiles.length === 0) {
        setState({
          isUploading: false,
          totalFiles: 0,
          completedFiles: 0,
          successCount: 0,
          failedFiles: [],
          isDone: true,
          percent: 100,
          isRetrying: false,
          fileProgress: new Map(),
          errors: [...tooLarge],
        });
        return;
      }

      try {
        await testUploadServerConnection();
      } catch (error) {
        const message = error instanceof Error ? error.message : 'Cannot connect to upload server. Check your internet connection.';
        setState({
          isUploading: false,
          totalFiles: validFiles.length,
          completedFiles: 0,
          successCount: 0,
          failedFiles: [...validFiles],
          isDone: true,
          percent: 0,
          isRetrying: false,
          fileProgress: new Map(),
          errors: [...tooLarge, message],
        });
        return;
      }

      const initialProgress = new Map<string, FileUploadProgress>();
      validFiles.forEach(f => {
        initialProgress.set(f.name, { fileName: f.name, loaded: 0, total: f.size, percent: 0, status: 'uploading' });
      });

      setState({
        isUploading: true,
        totalFiles: validFiles.length,
        completedFiles: 0,
        successCount: 0,
        failedFiles: [],
        isDone: false,
        percent: 0,
        isRetrying: isRetry,
        fileProgress: initialProgress,
        errors: [...tooLarge],
      });

      let success = 0;
      const failed: File[] = [];

      const BATCH_SIZE = 5;
      for (let i = 0; i < validFiles.length; i += BATCH_SIZE) {
        if (abortRef.current) break;
        const batch = validFiles.slice(i, i + BATCH_SIZE);

        const results = await Promise.allSettled(
          batch.map(async (file) => {
            await uploadPhotoToR2(
              file,
              file.name,
              eventId!,
              userId!,
              (loaded, total) => {
                setState(prev => {
                  const fp = new Map(prev.fileProgress);
                  fp.set(file.name, { fileName: file.name, loaded, total, percent: Math.round((loaded / total) * 100), status: 'uploading' });
                  return { ...prev, fileProgress: fp };
                });
              },
            );
            setState(prev => {
              const fp = new Map(prev.fileProgress);
              fp.set(file.name, { fileName: file.name, loaded: file.size, total: file.size, percent: 100, status: 'done' });
              return { ...prev, fileProgress: fp };
            });
          }),
        );

        results.forEach((r, idx) => {
          if (r.status === 'fulfilled') {
            success++;
          } else {
            failed.push(batch[idx]);
            const errMsg = r.reason?.message || 'Unknown error';
            setState(prev => {
              const fp = new Map(prev.fileProgress);
              fp.set(batch[idx].name, { fileName: batch[idx].name, loaded: 0, total: batch[idx].size, percent: 0, status: 'failed', error: errMsg });
              return { ...prev, fileProgress: fp, errors: [...prev.errors, `"${batch[idx].name}": ${errMsg}`] };
            });
          }
        });

        const completed = Math.min(i + BATCH_SIZE, validFiles.length);
        setState((prev) => ({
          ...prev,
          completedFiles: completed,
          successCount: success,
          failedFiles: [...failed],
          percent: Math.round((completed / validFiles.length) * 100),
        }));
      }

      setState((prev) => ({
        ...prev,
        isUploading: false,
        isDone: true,
        percent: 100,
        isRetrying: false,
      }));
    },
    [eventId, userId],
  );

  const retry = useCallback(() => {
    const filesToRetry = [...state.failedFiles];
    if (filesToRetry.length > 0) {
      uploadFiles(filesToRetry, true);
    }
  }, [state.failedFiles, uploadFiles]);

  const dismiss = useCallback(() => {
    setState(INITIAL);
  }, []);

  return { ...state, uploadFiles, retry, dismiss };
}
