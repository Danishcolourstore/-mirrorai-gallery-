import { useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';

function getSessionId(): string {
  const key = 'mirrorai_session_id';
  let id = localStorage.getItem(key);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(key, id);
  }
  return id;
}

function getDeviceType(): string {
  if (typeof window === 'undefined') return 'desktop';
  const ua = navigator.userAgent;
  if (/Mobi|Android|iPhone|iPad|iPod/i.test(ua) || window.innerWidth < 768) return 'mobile';
  return 'desktop';
}

/** Track a gallery page view (call once on mount) */
export function useTrackGalleryView(eventId: string | undefined) {
  const tracked = useRef(false);

  useEffect(() => {
    if (!eventId || tracked.current) return;
    tracked.current = true;

    (supabase.from('event_views' as any).insert({
      event_id: eventId,
      session_id: getSessionId(),
      device_type: getDeviceType(),
    } as any) as any).then(() => {});
  }, [eventId]);
}

/** Track a photo interaction */
export async function trackPhotoInteraction(
  photoId: string,
  eventId: string,
  type: 'view' | 'download' | 'favorite'
) {
  await (supabase.from('photo_interactions' as any).insert({
    photo_id: photoId,
    event_id: eventId,
    interaction_type: type,
    session_id: getSessionId(),
  } as any) as any);
}
