import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/integrations/supabase/client';

interface PlanInfo {
  plan: 'free' | 'pro';
  isPro: boolean;
  planExpiresAt: string | null;
  loading: boolean;
  eventCount: number;
  storageUsedMb: number;
  storageLimitMb: number;
  isEventLimitReached: boolean;
  isStorageNearLimit: boolean;
  isStorageFull: boolean;
  refetch: () => void;
}

export function usePlan(): PlanInfo {
  const { user } = useAuth();
  const [plan, setPlan] = useState<'free' | 'pro'>('free');
  const [planExpiresAt, setPlanExpiresAt] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [eventCount, setEventCount] = useState(0);
  const [storageUsedMb, setStorageUsedMb] = useState(0);
  const [storageLimitMb, setStorageLimitMb] = useState(5120);
  const [fetchKey, setFetchKey] = useState(0);

  const refetch = () => setFetchKey((k) => k + 1);

  useEffect(() => {
    if (!user) { setLoading(false); return; }

    const load = async () => {
      try {
        const { data: profile } = await (supabase
          .from('profiles')
          .select('plan, plan_expires_at, storage_limit_mb') as any)
          .eq('user_id', user.id)
          .maybeSingle();

        const currentPlan = profile?.plan || 'free';
        const expiresAt = profile?.plan_expires_at;

        // Check if pro expired
        if (currentPlan === 'pro' && expiresAt && new Date(expiresAt) < new Date()) {
          setPlan('free');
        } else {
          setPlan(currentPlan as 'free' | 'pro');
        }
        setPlanExpiresAt(expiresAt || null);
        setStorageLimitMb(currentPlan === 'pro' ? 512000 : (profile?.storage_limit_mb || 5120));

        // Count events
        const { count } = await supabase
          .from('events')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id);
        setEventCount(count || 0);

        // Estimate storage (2MB per photo)
        const { count: photoCount } = await supabase
          .from('photos')
          .select('id', { count: 'exact', head: true })
          .eq('user_id', user.id);
        setStorageUsedMb((photoCount || 0) * 2);
      } catch {
        // fallback
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user, fetchKey]);

  const isPro = plan === 'pro';
  const freeEventLimit = 3;
  const freeStorageMb = 5120;
  const limit = isPro ? 512000 : freeStorageMb;

  return {
    plan,
    isPro,
    planExpiresAt,
    loading,
    eventCount,
    storageUsedMb,
    storageLimitMb: limit,
    isEventLimitReached: !isPro && eventCount >= freeEventLimit,
    isStorageNearLimit: storageUsedMb >= limit * 0.8,
    isStorageFull: storageUsedMb >= limit,
    refetch,
  };
}
