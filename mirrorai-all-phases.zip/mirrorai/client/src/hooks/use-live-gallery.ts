import { useEffect, useState, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface LivePhoto {
  id: string;
  url: string;
  file_name: string | null;
  created_at: string;
  isNew?: boolean;
}

export function useLiveGallery(eventId: string | undefined, enabled: boolean = true) {
  const { toast } = useToast();
  const [livePhotos, setLivePhotos] = useState<LivePhoto[]>([]);
  const [isLiveEvent, setIsLiveEvent] = useState(false);
  const [lastPhotoTime, setLastPhotoTime] = useState<string | null>(null);
  const seenIds = useRef(new Set<string>());

  // Check if event is live
  const checkLiveStatus = useCallback(async () => {
    if (!eventId) return;
    const { data } = await supabase
      .from('events')
      .select('camera_connected, last_photo_at')
      .eq('id', eventId)
      .single();
    if (data) {
      setIsLiveEvent((data as any).camera_connected ?? false);
      setLastPhotoTime((data as any).last_photo_at);
    }
  }, [eventId]);

  useEffect(() => {
    if (!enabled) return;
    checkLiveStatus();
    const interval = setInterval(checkLiveStatus, 15000);
    return () => clearInterval(interval);
  }, [checkLiveStatus, enabled]);

  // Subscribe to realtime photo inserts
  useEffect(() => {
    if (!eventId || !enabled) return;

    const channel = supabase
      .channel(`live-photos-${eventId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'photos',
          filter: `event_id=eq.${eventId}`,
        },
        (payload) => {
          const newPhoto = payload.new as any;
          if (seenIds.current.has(newPhoto.id)) return;
          seenIds.current.add(newPhoto.id);

          setLivePhotos(prev => [{
            id: newPhoto.id,
            url: newPhoto.url,
            file_name: newPhoto.file_name,
            created_at: newPhoto.created_at,
            isNew: true,
          }, ...prev]);

          setLastPhotoTime(newPhoto.created_at);
          setIsLiveEvent(true);

          toast({
            title: '📷 New photo just added!',
            duration: 3000,
          });

          // Clear isNew after 8 seconds
          setTimeout(() => {
            setLivePhotos(prev =>
              prev.map(p => p.id === newPhoto.id ? { ...p, isNew: false } : p)
            );
          }, 8000);
        }
      )
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [eventId, enabled, toast]);

  return { livePhotos, isLiveEvent, lastPhotoTime };
}
