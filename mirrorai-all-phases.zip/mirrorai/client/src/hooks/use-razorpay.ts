import { useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

declare global {
  interface Window {
    Razorpay: any;
  }
}

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) { resolve(true); return; }
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export function useRazorpay() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const openCheckout = useCallback(async () => {
    const loaded = await loadRazorpayScript();
    if (!loaded) {
      toast({ title: 'Error', description: 'Failed to load payment gateway. Please try again.', variant: 'destructive' });
      return;
    }

    const key = import.meta.env.VITE_RAZORPAY_KEY;
    if (!key) {
      toast({ title: 'Error', description: 'Payment not configured yet. Contact support.', variant: 'destructive' });
      return;
    }

    const options = {
      key,
      amount: 375000, // ₹3750 in paise
      currency: 'INR',
      name: 'MirrorAI',
      description: 'Pro Plan — 1 Year',
      prefill: {
        email: user?.email || '',
        name: user?.user_metadata?.full_name || user?.user_metadata?.studio_name || '',
      },
      theme: { color: '#C9A96E' },
      handler: async (response: { razorpay_payment_id: string }) => {
        try {
          const now = new Date();
          const expiresAt = new Date(now);
          expiresAt.setFullYear(expiresAt.getFullYear() + 1);

          const { error } = await (supabase
            .from('profiles')
            .update({
              plan: 'pro',
              plan_started_at: now.toISOString(),
              plan_expires_at: expiresAt.toISOString(),
              razorpay_payment_id: response.razorpay_payment_id,
            }) as any)
            .eq('user_id', user?.id);

          if (error) throw error;

          toast({ title: 'Welcome to Pro! 🎉', description: 'All Pro features are now unlocked.' });
          navigate('/dashboard');
        } catch {
          toast({ title: 'Error', description: 'Payment received but plan update failed. Contact support.', variant: 'destructive' });
        }
      },
      modal: {
        ondismiss: () => {
          // User closed checkout — do nothing
        },
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.on('payment.failed', () => {
      toast({ title: 'Payment failed', description: 'Please try again.', variant: 'destructive' });
    });
    rzp.open();
  }, [user, toast, navigate]);

  return { openCheckout };
}
