import { useState, useEffect, useCallback, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import {
  Instagram, Phone, Globe, Mail, Send, ChevronDown,
  Star, Camera, X, ChevronLeft, ChevronRight, ZoomIn
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface StudioProfile {
  id: string;
  user_id: string;
  studio_name: string;
  tagline: string | null;
  logo_url: string | null;
  instagram: string | null;
  whatsapp: string | null;
  website_url: string | null;
  accent_color: string;
}

interface Service   { id: string; title: string; description: string | null; price: string | null; }
interface Testimonial { id: string; client_name: string; quote: string; event_type: string | null; }
interface PortfolioPhoto { id: string; url: string; }

// ── Scroll-reveal hook ───────────────────────────────────────
const useReveal = () => {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } }, { threshold: 0.12 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
};

const Reveal = ({ children, delay = 0, className = '' }: { children: React.ReactNode; delay?: number; className?: string }) => {
  const { ref, visible } = useReveal();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(24px)',
        transition: `opacity 0.7s ease ${delay}ms, transform 0.7s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
};

// ── Divider ──────────────────────────────────────────────────
const Divider = ({ accent }: { accent: string }) => (
  <div className="flex items-center justify-center gap-3 my-1">
    <div className="w-10 h-px" style={{ backgroundColor: `${accent}40` }} />
    <div className="w-1 h-1 rounded-full" style={{ backgroundColor: accent }} />
    <div className="w-10 h-px" style={{ backgroundColor: `${accent}40` }} />
  </div>
);

// ────────────────────────────────────────────────────────────
const StudioPortfolio = () => {
  const { username } = useParams<{ username: string }>();
  const { toast } = useToast();
  const [profile, setProfile]             = useState<StudioProfile | null>(null);
  const [services, setServices]           = useState<Service[]>([]);
  const [testimonials, setTestimonials]   = useState<Testimonial[]>([]);
  const [portfolioPhotos, setPortfolioPhotos] = useState<PortfolioPhoto[]>([]);
  const [loading, setLoading]             = useState(true);
  const [notFound, setNotFound]           = useState(false);
  const [formData, setFormData]           = useState({ name: '', email: '', phone: '', event_type: '', event_date: '', message: '' });
  const [submitting, setSubmitting]       = useState(false);
  const [submitted, setSubmitted]         = useState(false);
  const [lightbox, setLightbox]           = useState<number | null>(null);
  const [heroLoaded, setHeroLoaded]       = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  // ── Fetch ────────────────────────────────────────────────
  const fetchProfile = useCallback(async () => {
    if (!username) return;
    const { data: profiles } = await (supabase.from('studio_profiles' as any).select('*') as any);
    const match = (profiles as StudioProfile[] | null)?.find(p =>
      p.studio_name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') === username.toLowerCase()
    );
    if (!match) { setNotFound(true); setLoading(false); return; }
    setProfile(match);
    document.title = `${match.studio_name} — Photography`;

    const [servRes, testRes, eventsRes] = await Promise.all([
      (supabase.from('studio_services' as any).select('*') as any).eq('studio_id', match.id).order('order_index', { ascending: true }),
      (supabase.from('studio_testimonials' as any).select('*') as any).eq('studio_id', match.id).order('order_index', { ascending: true }),
      (supabase.from('events').select('id') as any).eq('user_id', match.user_id).eq('is_published', true),
    ]);
    if (servRes.data)  setServices(servRes.data);
    if (testRes.data)  setTestimonials(testRes.data);

    if (eventsRes.data?.length > 0) {
      const ids = eventsRes.data.map((e: any) => e.id);
      const { data: photos } = await (supabase.from('photos').select('id, url') as any)
        .in('event_id', ids).order('created_at', { ascending: false }).limit(18);
      if (photos) setPortfolioPhotos(photos);
    }
    setLoading(false);
  }, [username]);

  useEffect(() => { fetchProfile(); }, [fetchProfile]);

  // ── Testimonial auto-advance ──────────────────────────────
  useEffect(() => {
    if (testimonials.length < 2) return;
    const t = setInterval(() => setActiveTestimonial(i => (i + 1) % testimonials.length), 5000);
    return () => clearInterval(t);
  }, [testimonials.length]);

  // ── Lightbox keyboard ─────────────────────────────────────
  useEffect(() => {
    if (lightbox === null) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightbox(null);
      if (e.key === 'ArrowRight') setLightbox(i => i !== null ? Math.min(i + 1, portfolioPhotos.length - 1) : null);
      if (e.key === 'ArrowLeft')  setLightbox(i => i !== null ? Math.max(i - 1, 0) : null);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [lightbox, portfolioPhotos.length]);

  // ── Submit ────────────────────────────────────────────────
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !formData.name || !formData.email) return;
    setSubmitting(true);
    await (supabase.from('inquiries' as any).insert({
      studio_id:  profile.id,
      name:       formData.name,
      email:      formData.email,
      phone:      formData.phone || null,
      event_type: formData.event_type || null,
      event_date: formData.event_date || null,
      message:    formData.message || null,
    }) as any);
    setSubmitted(true);
    setSubmitting(false);
  };

  // ── Loading ───────────────────────────────────────────────
  if (loading) return (
    <div className="min-h-[100dvh] flex items-center justify-center" style={{ backgroundColor: '#0D0D0D' }}>
      <div className="text-center space-y-3">
        <Camera className="h-6 w-6 mx-auto text-white/20 animate-pulse" />
        <p className="text-[10px] text-white/20 uppercase tracking-[0.3em]">Loading</p>
      </div>
    </div>
  );

  if (notFound || !profile) return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center" style={{ backgroundColor: '#0D0D0D' }}>
      <h1 className="font-serif text-3xl text-white mb-2">Studio Not Found</h1>
      <p className="text-[12px] text-white/30">This studio page doesn't exist.</p>
    </div>
  );

  const accent = profile.accent_color || '#C9A96E';

  return (
    <div className="min-h-[100dvh]" style={{ backgroundColor: '#FAFAF8' }}>

      {/* ── HERO ──────────────────────────────────────────── */}
      <section className="relative h-[100dvh] flex items-center justify-center overflow-hidden" style={{ backgroundColor: '#0D0D0D' }}>
        {portfolioPhotos[0] && (
          <img
            src={portfolioPhotos[0].url}
            alt=""
            onLoad={() => setHeroLoaded(true)}
            className="absolute inset-0 w-full h-full object-cover transition-all duration-[2s]"
            style={{
              opacity: heroLoaded ? 0.45 : 0,
              transform: heroLoaded ? 'scale(1.04)' : 'scale(1)',
            }}
          />
        )}
        {/* Gradient overlays */}
        <div className="absolute inset-0" style={{
          background: 'linear-gradient(to bottom, rgba(0,0,0,0.5) 0%, rgba(0,0,0,0.1) 40%, rgba(0,0,0,0.6) 100%)'
        }} />

        {/* Content */}
        <div className="relative z-10 text-center px-6 space-y-6"
          style={{ opacity: heroLoaded || !portfolioPhotos[0] ? 1 : 0, transition: 'opacity 1s ease 0.3s' }}>
          {profile.logo_url ? (
            <img src={profile.logo_url} alt={profile.studio_name} className="h-14 object-contain mx-auto" />
          ) : (
            <h1 className="font-serif text-5xl sm:text-7xl font-light text-white tracking-[-0.02em] leading-none">
              {profile.studio_name}
            </h1>
          )}
          <Divider accent={accent} />
          {profile.tagline && (
            <p className="text-[11px] sm:text-[12px] uppercase tracking-[0.3em] font-sans"
              style={{ color: `${accent}CC` }}>
              {profile.tagline}
            </p>
          )}

          {/* Social pills */}
          <div className="flex items-center justify-center gap-4 pt-2">
            {profile.instagram && (
              <a href={`https://instagram.com/${profile.instagram.replace('@', '')}`}
                target="_blank" rel="noopener noreferrer"
                className="p-2 rounded-full border transition-all duration-300 hover:scale-110"
                style={{ borderColor: 'rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.5)' }}>
                <Instagram className="h-4 w-4" />
              </a>
            )}
            {profile.whatsapp && (
              <a href={`https://wa.me/${profile.whatsapp.replace(/\D/g, '')}`}
                target="_blank" rel="noopener noreferrer"
                className="p-2 rounded-full border transition-all duration-300 hover:scale-110"
                style={{ borderColor: 'rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.5)' }}>
                <Phone className="h-4 w-4" />
              </a>
            )}
            {profile.website_url && (
              <a href={profile.website_url.startsWith('http') ? profile.website_url : `https://${profile.website_url}`}
                target="_blank" rel="noopener noreferrer"
                className="p-2 rounded-full border transition-all duration-300 hover:scale-110"
                style={{ borderColor: 'rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.5)' }}>
                <Globe className="h-4 w-4" />
              </a>
            )}
          </div>

          {/* CTA */}
          <div className="pt-2">
            <button
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-3 text-[11px] uppercase tracking-[0.2em] font-semibold font-sans transition-all duration-300 hover:opacity-90 hover:scale-105"
              style={{ backgroundColor: accent, color: '#fff' }}
            >
              Book a Session
            </button>
          </div>
        </div>

        {/* Scroll cue */}
        <button
          onClick={() => document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' })}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce"
          style={{ color: 'rgba(255,255,255,0.25)' }}
        >
          <ChevronDown className="h-6 w-6" />
        </button>
      </section>

      {/* ── PORTFOLIO ─────────────────────────────────────── */}
      {portfolioPhotos.length > 0 && (
        <section id="portfolio" className="py-24 px-6">
          <div className="max-w-6xl mx-auto">
            <Reveal className="text-center mb-4">
              <p className="text-[10px] uppercase tracking-[0.3em] font-sans mb-2" style={{ color: accent }}>Our Work</p>
              <h2 className="font-serif text-3xl sm:text-4xl text-foreground font-light">Portfolio</h2>
            </Reveal>
            <Reveal delay={100} className="flex justify-center mb-12">
              <Divider accent={accent} />
            </Reveal>

            {/* Masonry grid */}
            <div className="columns-2 sm:columns-3 gap-2 space-y-0">
              {portfolioPhotos.map((p, i) => (
                <Reveal key={p.id} delay={i * 40} className="mb-2 break-inside-avoid">
                  <div
                    className="relative overflow-hidden cursor-pointer group"
                    onClick={() => setLightbox(i)}
                  >
                    <img
                      src={p.url}
                      alt=""
                      className="w-full block transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      style={{ backgroundColor: 'rgba(0,0,0,0.35)' }}>
                      <ZoomIn className="h-5 w-5 text-white" />
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── SERVICES ──────────────────────────────────────── */}
      {services.length > 0 && (
        <section className="py-24 px-6" style={{ backgroundColor: '#0D0D0D' }}>
          <div className="max-w-5xl mx-auto">
            <Reveal className="text-center mb-4">
              <p className="text-[10px] uppercase tracking-[0.3em] font-sans mb-2" style={{ color: accent }}>What We Offer</p>
              <h2 className="font-serif text-3xl sm:text-4xl text-white font-light">Services</h2>
            </Reveal>
            <Reveal delay={100} className="flex justify-center mb-14">
              <Divider accent={accent} />
            </Reveal>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px" style={{ backgroundColor: `${accent}20` }}>
              {services.map((s, i) => (
                <Reveal key={s.id} delay={i * 80}>
                  <div className="p-8 h-full" style={{ backgroundColor: '#111' }}>
                    <div className="w-6 h-px mb-5" style={{ backgroundColor: accent }} />
                    <h3 className="font-serif text-[18px] font-light text-white mb-3">{s.title}</h3>
                    {s.description && <p className="text-[12px] text-white/40 leading-relaxed">{s.description}</p>}
                    {s.price && (
                      <p className="text-[13px] font-semibold mt-4 font-sans" style={{ color: accent }}>{s.price}</p>
                    )}
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── TESTIMONIALS ──────────────────────────────────── */}
      {testimonials.length > 0 && (
        <section className="py-24 px-6 overflow-hidden" style={{ backgroundColor: '#FAFAF8' }}>
          <div className="max-w-2xl mx-auto">
            <Reveal className="text-center mb-4">
              <p className="text-[10px] uppercase tracking-[0.3em] font-sans mb-2" style={{ color: accent }}>Kind Words</p>
              <h2 className="font-serif text-3xl sm:text-4xl text-foreground font-light">What Clients Say</h2>
            </Reveal>
            <Reveal delay={100} className="flex justify-center mb-14">
              <Divider accent={accent} />
            </Reveal>

            {/* Carousel */}
            <div className="relative">
              <div className="overflow-hidden">
                <div
                  className="flex transition-transform duration-700 ease-in-out"
                  style={{ transform: `translateX(-${activeTestimonial * 100}%)` }}
                >
                  {testimonials.map(t => (
                    <div key={t.id} className="w-full flex-shrink-0 text-center px-4">
                      <div className="flex justify-center gap-1 mb-5">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="h-3.5 w-3.5" style={{ color: accent }} fill={accent} />
                        ))}
                      </div>
                      <blockquote className="font-serif text-[20px] sm:text-[22px] text-foreground/80 italic leading-relaxed">
                        "{t.quote}"
                      </blockquote>
                      <div className="w-6 h-px mx-auto my-5" style={{ backgroundColor: accent }} />
                      <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground/50 font-sans">
                        {t.client_name}{t.event_type && ` · ${t.event_type}`}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dots */}
              {testimonials.length > 1 && (
                <div className="flex justify-center gap-1.5 mt-8">
                  {testimonials.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveTestimonial(i)}
                      className="w-1.5 h-1.5 rounded-full transition-all duration-300"
                      style={{
                        backgroundColor: i === activeTestimonial ? accent : `${accent}30`,
                        transform: i === activeTestimonial ? 'scale(1.4)' : 'scale(1)',
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Arrows */}
              {testimonials.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveTestimonial(i => Math.max(i - 1, 0))}
                    className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-6 p-1.5 rounded-full border transition-all hover:scale-110"
                    style={{ borderColor: `${accent}30`, color: accent }}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setActiveTestimonial(i => Math.min(i + 1, testimonials.length - 1))}
                    className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-6 p-1.5 rounded-full border transition-all hover:scale-110"
                    style={{ borderColor: `${accent}30`, color: accent }}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </>
              )}
            </div>
          </div>
        </section>
      )}

      {/* ── CONTACT ───────────────────────────────────────── */}
      <section id="contact" className="py-24 px-6" style={{ backgroundColor: '#0D0D0D' }}>
        <div className="max-w-lg mx-auto">
          <Reveal className="text-center mb-4">
            <p className="text-[10px] uppercase tracking-[0.3em] font-sans mb-2" style={{ color: accent }}>Let's Talk</p>
            <h2 className="font-serif text-3xl sm:text-4xl text-white font-light">Book a Session</h2>
          </Reveal>
          <Reveal delay={100} className="flex justify-center mb-12">
            <Divider accent={accent} />
          </Reveal>

          {submitted ? (
            <Reveal className="text-center py-16 space-y-5">
              <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto border"
                style={{ borderColor: `${accent}40`, backgroundColor: `${accent}15` }}>
                <Mail className="h-7 w-7" style={{ color: accent }} />
              </div>
              <h3 className="font-serif text-2xl text-white font-light">Thank you!</h3>
              <p className="text-[12px] text-white/40">We'll be in touch soon to discuss your special moments.</p>
            </Reveal>
          ) : (
            <Reveal>
              <form onSubmit={handleSubmit} className="space-y-3">
                {[
                  { placeholder: 'Your Name *', key: 'name', type: 'text', required: true },
                  { placeholder: 'Email Address *', key: 'email', type: 'email', required: true },
                  { placeholder: 'Phone Number', key: 'phone', type: 'tel', required: false },
                ].map(f => (
                  <input
                    key={f.key}
                    type={f.type}
                    placeholder={f.placeholder}
                    required={f.required}
                    value={(formData as any)[f.key]}
                    onChange={e => setFormData(p => ({ ...p, [f.key]: e.target.value }))}
                    className="w-full h-11 px-4 text-[13px] font-sans outline-none transition-colors"
                    style={{
                      backgroundColor: '#1A1A1A',
                      border: '1px solid rgba(255,255,255,0.08)',
                      color: '#fff',
                    }}
                    onFocus={e => e.currentTarget.style.borderColor = `${accent}60`}
                    onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                  />
                ))}

                <Select value={formData.event_type} onValueChange={v => setFormData(p => ({ ...p, event_type: v }))}>
                  <SelectTrigger className="h-11 text-[13px] border-[rgba(255,255,255,0.08)]"
                    style={{ backgroundColor: '#1A1A1A', color: formData.event_type ? '#fff' : 'rgba(255,255,255,0.3)' }}>
                    <SelectValue placeholder="Event Type" />
                  </SelectTrigger>
                  <SelectContent>
                    {['Wedding','Pre-Wedding','Engagement','Reception','Birthday','Corporate','Other'].map(v => (
                      <SelectItem key={v} value={v}>{v}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <input
                  type="date"
                  value={formData.event_date}
                  onChange={e => setFormData(p => ({ ...p, event_date: e.target.value }))}
                  className="w-full h-11 px-4 text-[13px] font-sans outline-none"
                  style={{
                    backgroundColor: '#1A1A1A',
                    border: '1px solid rgba(255,255,255,0.08)',
                    color: formData.event_date ? '#fff' : 'rgba(255,255,255,0.3)',
                  }}
                />

                <textarea
                  placeholder="Tell us about your event..."
                  value={formData.message}
                  onChange={e => setFormData(p => ({ ...p, message: e.target.value }))}
                  rows={4}
                  className="w-full px-4 py-3 text-[13px] font-sans outline-none resize-none transition-colors"
                  style={{
                    backgroundColor: '#1A1A1A',
                    border: '1px solid rgba(255,255,255,0.08)',
                    color: '#fff',
                  }}
                  onFocus={e => e.currentTarget.style.borderColor = `${accent}60`}
                  onBlur={e => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'}
                />

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full h-12 text-[11px] uppercase tracking-[0.2em] font-bold font-sans transition-all duration-300 hover:opacity-90 flex items-center justify-center gap-2"
                  style={{ backgroundColor: accent, color: '#fff', opacity: submitting ? 0.7 : 1 }}
                >
                  {submitting ? (
                    <span className="flex items-center gap-2">
                      <span className="w-3 h-3 border border-white/30 border-t-white rounded-full animate-spin" />
                      Sending...
                    </span>
                  ) : (
                    <><Send className="h-3.5 w-3.5" /> Send Inquiry</>
                  )}
                </button>
              </form>
            </Reveal>
          )}
        </div>
      </section>

      {/* ── FOOTER ────────────────────────────────────────── */}
      <footer className="py-16 text-center" style={{ backgroundColor: '#080808' }}>
        {profile.logo_url
          ? <img src={profile.logo_url} alt={profile.studio_name} className="h-8 object-contain mx-auto mb-6 opacity-60" />
          : <p className="font-serif text-xl text-white/50 mb-6">{profile.studio_name}</p>
        }
        <div className="flex items-center justify-center gap-5 mb-8">
          {profile.instagram && (
            <a href={`https://instagram.com/${profile.instagram.replace('@', '')}`}
              target="_blank" rel="noopener noreferrer"
              className="text-white/25 hover:text-white/60 transition-colors duration-300">
              <Instagram className="h-4 w-4" />
            </a>
          )}
          {profile.whatsapp && (
            <a href={`https://wa.me/${profile.whatsapp.replace(/\D/g, '')}`}
              target="_blank" rel="noopener noreferrer"
              className="text-white/25 hover:text-white/60 transition-colors duration-300">
              <Phone className="h-4 w-4" />
            </a>
          )}
          {profile.website_url && (
            <a href={profile.website_url.startsWith('http') ? profile.website_url : `https://${profile.website_url}`}
              target="_blank" rel="noopener noreferrer"
              className="text-white/25 hover:text-white/60 transition-colors duration-300">
              <Globe className="h-4 w-4" />
            </a>
          )}
        </div>
        <button
          onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
          className="text-[9px] uppercase tracking-[0.3em] font-sans px-5 py-2 border transition-all hover:opacity-80"
          style={{ borderColor: `${accent}30`, color: accent }}
        >
          Book Now
        </button>
        <p className="mt-8 text-[9px] text-white/15 tracking-[0.1em]">
          © {new Date().getFullYear()} {profile.studio_name}. All rights reserved.
        </p>
      </footer>

      {/* ── LIGHTBOX ──────────────────────────────────────── */}
      {lightbox !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ backgroundColor: 'rgba(0,0,0,0.95)' }}
          onClick={() => setLightbox(null)}
        >
          {/* Close */}
          <button
            className="absolute top-5 right-5 p-2 rounded-full text-white/50 hover:text-white transition-colors"
            onClick={() => setLightbox(null)}
          >
            <X className="h-5 w-5" />
          </button>

          {/* Prev */}
          {lightbox > 0 && (
            <button
              className="absolute left-4 p-2 rounded-full text-white/40 hover:text-white transition-colors"
              onClick={e => { e.stopPropagation(); setLightbox(i => i !== null ? i - 1 : null); }}
            >
              <ChevronLeft className="h-7 w-7" />
            </button>
          )}

          <img
            src={portfolioPhotos[lightbox].url}
            alt=""
            className="max-w-[90vw] max-h-[88vh] object-contain"
            onClick={e => e.stopPropagation()}
            style={{ boxShadow: '0 30px 80px rgba(0,0,0,0.8)' }}
          />

          {/* Next */}
          {lightbox < portfolioPhotos.length - 1 && (
            <button
              className="absolute right-4 p-2 rounded-full text-white/40 hover:text-white transition-colors"
              onClick={e => { e.stopPropagation(); setLightbox(i => i !== null ? i + 1 : null); }}
            >
              <ChevronRight className="h-7 w-7" />
            </button>
          )}

          {/* Counter */}
          <p className="absolute bottom-5 left-1/2 -translate-x-1/2 text-[11px] text-white/30 font-sans tracking-wider">
            {lightbox + 1} / {portfolioPhotos.length}
          </p>
        </div>
      )}
    </div>
  );
};


