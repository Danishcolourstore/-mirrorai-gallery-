import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const BlogEditor = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchPosts();
  }, [session]);

  const fetchPosts = async () => {
    try {
      const { data } = await supabase
        .from("blog_posts")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false });
      if (data) setPosts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setTitle("");
    setContent("");
    setCoverImage("");
    setEditing(null);
    setError("");
  };

  const handleEdit = (post: any) => {
    setEditing(post);
    setTitle(post.title);
    setContent(post.content);
    setCoverImage(post.cover_image || "");
    setShowForm(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const slug = title
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "");

      if (editing) {
        const { error } = await supabase
          .from("blog_posts")
          .update({
            title,
            content,
            cover_image: coverImage,
            slug: `${slug}-${editing.id}`,
          })
          .eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("blog_posts").insert({
          title,
          content,
          cover_image: coverImage,
          slug: `${slug}-${Date.now()}`,
          user_id: session.user.id,
          published: false,
        });
        if (error) throw error;
      }

      resetForm();
      setShowForm(false);
      fetchPosts();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this post?")) return;
    await supabase.from("blog_posts").delete().eq("id", id);
    fetchPosts();
  };

  const togglePublish = async (post: any) => {
    await supabase
      .from("blog_posts")
      .update({ published: !post.published })
      .eq("id", post.id);
    fetchPosts();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between">
        <button
          onClick={() => navigate("/dashboard")}
          className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
        >
          ← Dashboard
        </button>
        <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
          Blog
        </h1>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
        >
          + New Post
        </button>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">

        {/* Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 px-4">
            <div className="bg-[#111] border border-[#2a2a2a] rounded-2xl p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <h2 className="text-xl font-serif text-white mb-6">
                {editing ? "Edit Post" : "New Blog Post"}
              </h2>
              <form onSubmit={handleSave} className="space-y-5">
                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Title
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                    placeholder="Post title..."
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>
                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Cover Image URL
                  </label>
                  <input
                    type="text"
                    value={coverImage}
                    onChange={(e) => setCoverImage(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>
                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Content
                  </label>
                  <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    required
                    rows={10}
                    placeholder="Write your post here..."
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all resize-none"
                  />
                </div>
                {error && (
                  <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
                    {error}
                  </div>
                )}
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => { setShowForm(false); resetForm(); }}
                    className="flex-1 border border-[#2a2a2a] text-[#888] py-3 rounded-xl tracking-widest uppercase text-sm transition-all hover:border-[#444]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="flex-1 bg-[#c9a96e] hover:bg-[#b8924f] text-black font-semibold py-3 rounded-xl tracking-widest uppercase text-sm transition-all disabled:opacity-50"
                  >
                    {saving ? "Saving..." : "Save Post"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Posts List */}
        {posts.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-[#2a2a2a] rounded-2xl">
            <p className="text-[#444] text-sm tracking-widest uppercase mb-4">
              No blog posts yet
            </p>
            <button
              onClick={() => { resetForm(); setShowForm(true); }}
              className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-3 rounded-xl tracking-widest uppercase transition-all"
            >
              Write First Post
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {posts.map((post) => (
              <div
                key={post.id}
                className="bg-[#111] border border-[#1a1a1a] rounded-2xl overflow-hidden hover:border-[#c9a96e] transition-all"
              >
                {post.cover_image && (
                  <img
                    src={post.cover_image}
                    alt={post.title}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="text-white font-serif text-xl mb-2">
                        {post.title}
                      </h3>
                      <p className="text-[#888] text-xs tracking-widest mb-3">
                        {new Date(post.created_at).toLocaleDateString()}
                      </p>
                      <p className="text-[#666] text-sm line-clamp-2">
                        {post.content}
                      </p>
                    </div>
                    <span
                      className={`text-xs px-3 py-1 rounded-full tracking-widest uppercase shrink-0 ${
                        post.published
                          ? "bg-green-900/30 text-green-400 border border-green-500/30"
                          : "bg-[#1a1a1a] text-[#555] border border-[#2a2a2a]"
                      }`}
                    >
                      {post.published ? "Published" : "Draft"}
                    </span>
                  </div>
                  <div className="flex gap-3 mt-5">
                    <button
                      onClick={() => togglePublish(post)}
                      className="flex-1 border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-xs py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      {post.published ? "Unpublish" : "Publish"}
                    </button>
                    <button
                      onClick={() => handleEdit(post)}
                      className="flex-1 border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-xs py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(post.id)}
                      className="flex-1 border border-[#2a2a2a] hover:border-red-500/50 text-[#888] hover:text-red-400 text-xs py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default BlogEditor;
