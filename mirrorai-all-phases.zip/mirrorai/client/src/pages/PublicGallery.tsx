import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const PublicGallery = () => {
  const { slug } = useParams();
  const [event, setEvent] = useState<any>(null);
  const [photos, setPhotos] = useState<any[]>([]);
  const [branding, setBranding] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPhoto, setSelectedPhoto] = useState<any>(null);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    fetchGallery();
  }, [slug]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!selectedPhoto) return;
      if (e.key === "ArrowLeft" && selectedIndex > 0) {
        setSelectedIndex(selectedIndex - 1);
        setSelectedPhoto(photos[selectedIndex - 1]);
      }
      if (e.key === "ArrowRight" && selectedIndex < photos.length - 1) {
        setSelectedIndex(selectedIndex + 1);
        setSelectedPhoto(photos[selectedIndex + 1]);
      }
      if (e.key === "Escape") setSelectedPhoto(null);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selectedPhoto, selectedIndex, photos]);

  const fetchGallery = async () => {
    try {
      const { data: eventData } = await supabase
        .from("events")
        .select("*")
        .or(`slug.eq.${slug},id.eq.${slug}`)
        .single();

      if (!eventData) {
        setNotFound(true);
        return;
      }
      setEvent(eventData);

      const { data: photosData } = await supabase
        .from("photos")
        .select("*")
        .eq("event_id", eventData.id)
        .order("created_at", { ascending: false });
      if (photosData) setPhotos(photosData);

      const { data: brandingData } = await supabase
        .from("branding")
        .select("*")
        .eq("user_id", eventData.user_id)
        .single();
      if (brandingData) setBranding(brandingData);
    } catch (err) {
      console.error(err);setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const primaryColor = branding?.primary_color || "#c9a96e";
  const bgColor = branding?.bg_color || "#0a0a0a";

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading Gallery...
        </div>
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center text-center px-6">
        <div>
          <p className="text-6xl mb-4">📷</p>
          <h1 className="text-2xl font-serif text-white mb-2">
            Gallery Not Found
          </h1>
          <p className="text-[#888] text-sm tracking-widest">
            This gallery may have been removed or the link is incorrect.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: bgColor }}>

      {/* Header */}
      <header
        className="border-b px-6 py-6 text-center"
        style={{ borderColor: primaryColor + "22" }}
      >
        {branding?.logo_url && (
          <img
            src={branding.logo_url}
            alt={branding.brand_name}
            className="h-12 mx-auto mb-3 object-contain"
          />
        )}
        <h1
          className="text-3xl font-serif tracking-widest uppercase mb-1"
          style={{ color: primaryColor, fontFamily: branding?.font_style || "serif" }}
        >
          {event.name}
        </h1>
        <p className="text-sm tracking-widest" style={{ color: primaryColor + "88" }}>
          {event.date ? new Date(event.date).toLocaleDateString() : ""}{" "}
          {event.location ? `· ${event.location}` : ""} · {photos.length} photos
        </p>
        {branding?.tagline && (
          <p className="text-xs tracking-widest mt-2" style={{ color: primaryColor + "66" }}>
            {branding.tagline}
          </p>
        )}
      </header>

      {/* Photos Grid */}
      <main className="max-w-6xl mx-auto px-6 py-10">
        {photos.length === 0 ? (
          <div className="text-center py-24">
            <p className="text-[#444] text-sm tracking-widest uppercase">
              No photos in this gallery yet
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {photos.map((photo, index) => (
              <div
                key={photo.id}
                onClick={() => { setSelectedPhoto(photo); setSelectedIndex(index); }}
                className="aspect-square rounded-xl overflow-hidden cursor-pointer group relative"
                style={{ backgroundColor: primaryColor + "11" }}
              >
                <img
                  src={photo.url}
                  alt={photo.filename}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {branding?.watermark_text && (
                  <span
                    className="absolute bottom-2 right-2 text-white text-xs tracking-widest pointer-events-none"
                    style={{ opacity: (branding.watermark_opacity || 30) / 100 }}
                  >
                    {branding.watermark_text}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Lightbox */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 bg-black/95 flex items-center justify-center z-50 px-4"
          onClick={() => setSelectedPhoto(null)}
        >
          <div
            className="relative max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-[#888] text-xs tracking-widest uppercase text-center mb-4">
              {selectedIndex + 1} / {photos.length}
            </p>
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.filename}
              className="w-full max-h-[75vh] object-contain rounded-xl"
            />
            {branding?.watermark_text && (
              <span
                className="absolute bottom-16 right-6 text-white text-xs tracking-widest pointer-events-none"
                style={{ opacity: (branding.watermark_opacity || 30) / 100 }}
              >
                {branding.watermark_text}
              </span>
            )}
            <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex justify-between px-2 pointer-events-none">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (selectedIndex > 0) {
                    setSelectedIndex(selectedIndex - 1);
                    setSelectedPhoto(photos[selectedIndex - 1]);
                  }
                }}
                disabled={selectedIndex === 0}
                className="pointer-events-auto bg-black/60 hover:bg-black/80 text-white w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-20 transition-all"
              >
                ‹
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (selectedIndex < photos.length - 1) {
                    setSelectedIndex(selectedIndex + 1);
                    setSelectedPhoto(photos[selectedIndex + 1]);
                  }
                }}
                disabled={selectedIndex === photos.length - 1}
                className="pointer-events-auto bg-black/60 hover:bg-black/80 text-white w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-20 transition-all"
              >›
              </button>
            </div>
            <div className="flex justify-center gap-3 mt-4">
              <a
                href={selectedPhoto.url}
                download
                target="_blank"
                rel="noreferrer"
                className="text-sm font-semibold px-5 py-2 rounded-xl tracking-widest uppercase transition-all text-black"
                style={{ backgroundColor: primaryColor }}onClick={(e) => e.stopPropagation()}
              >
                Download
              </a>
              <button
                onClick={() => setSelectedPhoto(null)}
                className="border border-[#2a2a2a] text-[#888] text-sm px-5 py-2 rounded-xl tracking-widest uppercase transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer
        className="border-t px-6 py-6 text-center mt-10"
        style={{ borderColor: primaryColor + "22" }}
      >
        {branding?.social_instagram && (
          <p className="text-xs tracking-widest mb-1" style={{ color: primaryColor + "88" }}>
            {branding.social_instagram}
          </p>
        )}
        {branding?.social_website && (
          <a
            href={branding.social_website}
            target="_blank"
            rel="noreferrer"
            className="text-xs tracking-widest hover:underline"
            style={{ color: primaryColor + "88" }}
          >
            {branding.social_website}
          </a>
        )}
        <p className="text-[#333] text-xs tracking-widest uppercase mt-3">
          Powered by MirrorAI
        </p>
      </footer>
    </div>
  );
};

export default PublicGallery;
