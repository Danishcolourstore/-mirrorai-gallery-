import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Lock, Camera, MapPin, Calendar, Image } from 'lucide-react';
import { format } from 'date-fns';

interface Event {
  id: string;
  name: string;
  slug: string;
  event_date: string;
  location: string | null;
  cover_url: string | null;
  gallery_pin: string | null;
  gallery_style: string;
  gallery_mode: string;
  downloads_enabled: boolean;
  user_id: string;
}

interface StudioBranding {
  studio_name: string;
  brand_name?: string;
  brand_logo_url?: string;
  brand_color?: string;
  tagline?: string;
  instagram?: string;
  whatsapp?: string;
  website_url?: string;
  button_text?: string;
}

interface Props {
  event: Event;
  photoCount: number;
  branding?: StudioBranding;
}

// ── Skeleton ─────────────────────────────────────────────────
const Skeleton = ({ className = '' }: { className?: string }) => (
  <div className={`animate-pulse bg-muted/40 rounded ${className}`} />
);

export const StudioLandingPage = ({ event, photoCount, branding }: Props) => {
  const navigate = useNavigate();

  const [imgLoaded, setImgLoaded]   = useState(false);
  const [pinInput, setPinInput]     = useState('');
  const [pinError, setPinError]     = useState(false);
  const [shake, setShake]           = useState(false);
  const [pinUnlocked, setPinUnlocked] = useState(
    () => sessionStorage.getItem(`unlocked_${event.id}`) === 'true'
  );
  const [showPin, setShowPin] = useState(
    !!(event.gallery_pin && !pinUnlocked)
  );

  const accentColor = branding?.brand_color || '#C4956A';
  const studioName  = branding?.studio_name || 'Studio';
  const buttonText  = branding?.button_text || 'See your forever.';

  const handlePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === event.gallery_pin) {
      sessionStorage.setItem(`unlocked_${event.id}`, 'true');
      setPinUnlocked(true);
      setShowPin(false);
      setPinError(false);
    } else {
      setPinError(true);
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };

  const enterGallery = () => navigate(`/event/${event.slug}/gallery`);

  // ── PIN Gate ────────────────────────────────────────────
  if (showPin) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-background px-4 relative overflow-hidden">

        {/* Blurred bg */}
        {event.cover_url && (
          <div
            className="absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage: `url(${event.cover_url})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              filter: 'blur(28px)',
            }}
          />
        )}

        <div className="relative z-10 w-full max-w-xs text-center space-y-8">

          {/* Logo */}
          {branding?.brand_logo_url ? (
            <img
              src={branding.brand_logo_url}
              alt={studioName}
              className="h-10 mx-auto object-contain"
            />
          ) : (
            <p
              className="font-display italic text-2xl font-medium"
              style={{ color: accentColor }}
            >
              {studioName}
            </p>
          )}

          <div className="space-y-2">
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center mx-auto border"
              style={{ borderColor: `${accentColor}30`, background: `${accentColor}10` }}
            >
              <Lock className="h-5 w-5" style={{ color: accentColor }} />
            </div>
            <h1 className="font-serif text-2xl font-light text-foreground">
              {event.name}
            </h1>
            <p className="text-[11px] text-muted-foreground/50 font-sans">
              Enter the password to view this gallery
            </p>
          </div>

          <form onSubmit={handlePin} className="space-y-3">
            <div style={{ animation: shake ? 'shake 0.4s ease' : 'none' }}>
              <Input
                value={pinInput}
                onChange={e => { setPinInput(e.target.value); setPinError(false); }}
                placeholder="Password"
                type="password"
                autoFocus
                className={`
                  bg-background h-11 text-center text-[15px] tracking-[0.25em] font-mono
                  transition-colors duration-200
                  ${pinError ? 'border-destructive/60 focus-visible:ring-destructive/30' : ''}
                `}
                style={!pinError ? { borderColor: `${accentColor}50` } : {}}
              />
              {pinError && (
                <p className="text-[10px] text-destructive/80 mt-1.5 font-sans">
                  Incorrect password — try again
                </p>
              )}
            </div>
            <Button
              type="submit"
              className="w-full h-11 text-[11px] tracking-[0.15em] uppercase font-semibold rounded-none"
              style={{ background: accentColor, color: '#fff' }}
            >
              View Gallery
            </Button>
          </form>

          <p className="text-[9px] text-muted-foreground/20 tracking-[0.2em] uppercase font-sans">
            Powered by MirrorAI
          </p>
        </div>

        <style>{`
          @keyframes shake {
            0%,100% { transform: translateX(0); }
            20%      { transform: translateX(-6px); }
            40%      { transform: translateX(6px); }
            60%      { transform: translateX(-4px); }
            80%      { transform: translateX(4px); }
          }
        `}</style>
      </div>
    );
  }

  // ── Main Landing ────────────────────────────────────────
  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">

      {/* Hero cover */}
      <div className="relative w-full flex-1 max-h-[60vh] overflow-hidden bg-muted/20">
        {event.cover_url ? (
          <>
            {!imgLoaded && <Skeleton className="absolute inset-0 rounded-none" />}
            <img
              src={event.cover_url}
              alt={event.name}
              onLoad={() => setImgLoaded(true)}
              className="w-full h-full object-cover transition-all duration-[2.5s]"
              style={{
                opacity: imgLoaded ? 1 : 0,
                transform: imgLoaded ? 'scale(1.04)' : 'scale(1)',
              }}
            />
            {/* Gradient */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-background" />
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center min-h-[45vh]">
            <Image className="h-16 w-16 text-muted-foreground/10" />
          </div>
        )}

        {/* Studio logo overlay (top-left) */}
        <div className="absolute top-5 left-5 z-10">
          {branding?.brand_logo_url ? (
            <img
              src={branding.brand_logo_url}
              alt={studioName}
              className="h-8 object-contain drop-shadow-md"
            />
          ) : (
            <p
              className="font-display italic text-lg font-medium drop-shadow-md"
              style={{ color: accentColor }}
            >
              {studioName}
            </p>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-col items-center px-6 pb-14 -mt-6 relative z-10">

        {/* Event name */}
        <h1
          className="font-serif text-3xl sm:text-5xl font-light text-foreground text-center leading-tight"
          style={{ letterSpacing: '-0.02em' }}
        >
          {event.name}
        </h1>

        {/* Meta row */}
        <div className="flex items-center gap-4 mt-4 flex-wrap justify-center">
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground/50 font-sans">
            <Calendar className="h-3 w-3" />
            {format(new Date(event.event_date), 'MMMM d, yyyy')}
          </span>
          {event.location && (
            <>
              <span className="text-muted-foreground/20 text-[10px]">·</span>
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground/50 font-sans">
                <MapPin className="h-3 w-3" />
                {event.location}
              </span>
            </>
          )}
          {photoCount > 0 && (
            <>
              <span className="text-muted-foreground/20 text-[10px]">·</span>
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground/50 font-sans">
                <Camera className="h-3 w-3" />
                {photoCount} photos
              </span>
            </>
          )}
        </div>

        {/* Tagline */}
        {branding?.tagline && (
          <p className="mt-4 text-[12px] text-muted-foreground/40 font-sans italic text-center max-w-xs">
            "{branding.tagline}"
          </p>
        )}

        {/* CTA */}
        <Button
          onClick={enterGallery}
          className="mt-10 h-12 px-10 text-[12px] tracking-[0.18em] font-semibold uppercase rounded-none transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
          style={{ background: accentColor, color: '#fff' }}
        >
          {buttonText}
        </Button>

        {/* Social links */}
        {(branding?.instagram || branding?.whatsapp || branding?.website_url) && (
          <div className="flex items-center gap-5 mt-8">
            {branding.instagram && (
              <a
                href={`https://instagram.com/${branding.instagram.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] text-muted-foreground/30 hover:text-muted-foreground/60 tracking-[0.15em] uppercase font-sans transition-colors"
              >
                Instagram
              </a>
            )}
            {branding.whatsapp && (
              <a
                href={`https://wa.me/${branding.whatsapp.replace(/\D/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] text-muted-foreground/30 hover:text-muted-foreground/60 tracking-[0.15em] uppercase font-sans transition-colors"
              >
                WhatsApp
              </a>
            )}
            {branding.website_url && (
              <a
                href={branding.website_url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[10px] text-muted-foreground/30 hover:text-muted-foreground/60 tracking-[0.15em] uppercase font-sans transition-colors"
              >
                Website
              </a>
            )}
          </div>
        )}

        {/* Footer */}
        <div className="mt-10 text-center space-y-1">
          <p className="text-[9px] text-muted-foreground/25 tracking-[0.2em] uppercase font-sans">
            Photographed by {studioName}
          </p>
          <p className="text-[9px] text-muted-foreground/[0.18] tracking-[0.2em] uppercase font-sans">
            Powered by MirrorAI
          </p>
        </div>
      </div>
    </div>
  );
};

export default StudioLandingPage;
