import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Lock, Image, Camera, MapPin, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { useGuestSession } from '@/hooks/use-guest-session';
import { StudioLandingPage } from '@/components/StudioLandingPage';
import { StudioCoverPage } from '@/components/StudioCoverPage';
import { GalleryInstallPrompt } from '@/components/GalleryInstallPrompt';

interface Event {
  id: string;
  name: string;
  slug: string;
  event_date: string;
  location: string | null;
  cover_url: string | null;
  gallery_pin: string | null;
  is_published: boolean;
  gallery_layout: string;
  gallery_style: string;
  gallery_mode: string;
  downloads_enabled: boolean;
  user_id: string;
}

// ── Skeleton shimmer ─────────────────────────────────────────
const Skeleton = ({ className = '' }: { className?: string }) => (
  <div className={`animate-pulse bg-muted/40 rounded ${className}`} />
);

// ── Loading ──────────────────────────────────────────────────
const LoadingScreen = () => (
  <div className="min-h-[100dvh] flex items-center justify-center bg-background">
    <div className="text-center space-y-4">
      <Camera className="h-7 w-7 mx-auto text-primary/20 animate-pulse" />
      <p className="text-[10px] text-muted-foreground/30 uppercase tracking-[0.3em]">Loading gallery…</p>
    </div>
  </div>
);

// ── Standard Cover ───────────────────────────────────────────
const StandardCover = ({
  event, photoCount, studioName, onEnter,
}: {
  event: Event; photoCount: number; studioName: string; onEnter: () => void;
}) => {
  const [imgLoaded, setImgLoaded] = useState(false);

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">

      {/* Cover image — full bleed top half */}
      <div className="relative w-full flex-1 max-h-[55vh] overflow-hidden bg-muted/20">
        {event.cover_url ? (
          <>
            {!imgLoaded && <Skeleton className="absolute inset-0 rounded-none" />}
            <img
              src={event.cover_url}
              alt={event.name}
              onLoad={() => setImgLoaded(true)}
              className="w-full h-full object-cover transition-all duration-[2s]"
              style={{
                opacity: imgLoaded ? 1 : 0,
                transform: imgLoaded ? 'scale(1.03)' : 'scale(1)',
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center min-h-[40vh]">
            <Image className="h-14 w-14 text-muted-foreground/10" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col items-center px-6 pb-12 -mt-8 relative z-10">
        <h1
          className="font-serif text-3xl sm:text-5xl font-light text-foreground text-center leading-tight"
          style={{ letterSpacing: '-0.02em' }}
        >
          {event.name}
        </h1>

        {/* Meta row */}
        <div className="flex items-center gap-4 mt-4 flex-wrap justify-center">
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground/50 font-sans">
            <Calendar className="h-3 w-3" />
            {format(new Date(event.event_date), 'MMMM d, yyyy')}
          </span>
          {event.location && (
            <>
              <span className="text-muted-foreground/20 text-[10px]">·</span>
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground/50 font-sans">
                <MapPin className="h-3 w-3" />
                {event.location}
              </span>
            </>
          )}
          {photoCount > 0 && (
            <>
              <span className="text-muted-foreground/20 text-[10px]">·</span>
              <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground/50 font-sans">
                <Camera className="h-3 w-3" />
                {photoCount} photos
              </span>
            </>
          )}
        </div>

        {/* CTA */}
        <Button
          onClick={onEnter}
          className="mt-10 h-13 px-10 text-[12px] tracking-[0.18em] font-semibold uppercase rounded-none transition-all duration-200 hover:opacity-90 active:scale-[0.98]"
        >
          See your forever.
        </Button>

        {studioName && (
          <p className="mt-8 text-[9px] text-muted-foreground/25 tracking-[0.2em] uppercase font-sans">
            Photographed by {studioName}
          </p>
        )}
        <p className="mt-1 text-[9px] text-muted-foreground/[0.2] tracking-[0.2em] uppercase font-sans">
          Powered by MirrorAI
        </p>
      </div>
    </div>
  );
};

// ── PIN Gate ─────────────────────────────────────────────────
const PinGateScreen = ({
  event, onUnlock,
}: { event: Event; onUnlock: () => void }) => {
  const [pin, setPin]     = useState('');
  const [error, setError] = useState(false);
  const [shake, setShake] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === event.gallery_pin) {
      sessionStorage.setItem(`unlocked_${event.id}`, 'true');
      onUnlock();
    } else {
      setError(true);
      setShake(true);
      setTimeout(() => setShake(false), 500);
    }
  };

  return (
    <div className="min-h-[100dvh] flex items-center justify-center bg-background px-4">

      {/* Blurred cover bg */}
      {event.cover_url && (
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage: `url(${event.cover_url})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'blur(24px)',
          }}
        />
      )}

      <div className="relative w-full max-w-xs text-center space-y-8 z-10">
        <div className="space-y-4">
          <div className="w-14 h-14 rounded-full bg-primary/8 border border-primary/15 flex items-center justify-center mx-auto">
            <Lock className="h-5 w-5 text-primary/60" />
          </div>
          <div>
            <h1 className="font-serif text-2xl font-light text-foreground">{event.name}</h1>
            <p className="text-[11px] text-muted-foreground/50 mt-1.5 font-sans">
              Enter the password to view this gallery
            </p>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-3">
          <div style={{ animation: shake ? 'shake 0.4s ease' : 'none' }}>
            <Input
              value={pin}
              onChange={e => { setPin(e.target.value); setError(false); }}
              placeholder="Password"
              type="password"
              autoFocus
              className={`
                bg-background h-11 text-center text-[15px] tracking-[0.25em] font-mono
                transition-colors duration-200
                ${error ? 'border-destructive/60 focus-visible:ring-destructive/30' : ''}
              `}
            />
            {error && (
              <p className="text-[10px] text-destructive/80 mt-1.5 font-sans">
                Incorrect password — try again
              </p>
            )}
          </div>
          <Button
            type="submit"
            className="w-full h-11 text-[11px] tracking-[0.15em] uppercase font-semibold rounded-none"
          >
            View Gallery
          </Button>
        </form>

        <p className="text-[9px] text-muted-foreground/20 tracking-[0.2em] uppercase font-sans">
          Powered by MirrorAI
        </p>
      </div>

      <style>{`
        @keyframes shake {
          0%,100% { transform: translateX(0); }
          20%      { transform: translateX(-6px); }
          40%      { transform: translateX(6px); }
          60%      { transform: translateX(-4px); }
          80%      { transform: translateX(4px); }
        }
      `}</style>
    </div>
  );
};

// ────────────────────────────────────────────────────────────
const GalleryCover = () => {
  const { slug }  = useParams<{ slug: string }>();
  const navigate  = useNavigate();

  const [event, setEvent]                   = useState<Event | null>(null);
  const [loading, setLoading]               = useState(true);
  const [notFound, setNotFound]             = useState(false);
  const [pinRequired, setPinRequired]       = useState(false);
  const [photoCount, setPhotoCount]         = useState(0);
  const [studioName, setStudioName]         = useState('');
  const [studioBranding, setStudioBranding] = useState<any>(null);

  useGuestSession(event?.id);

  const fetchEvent = useCallback(async () => {
    if (!slug) return;

    const { data } = await (supabase
      .from('events')
      .select('*') as any)
      .eq('slug', slug)
      .eq('is_published', true)
      .maybeSingle();

    if (!data) { setNotFound(true); setLoading(false); return; }

    const ev = data as unknown as Event;
    setEvent(ev);

    const [countRes, spRes, profRes] = await Promise.all([
      supabase.from('photos').select('*', { count: 'exact', head: true }).eq('event_id', ev.id),
      (supabase.from('studio_profiles')
        .select('studio_name, logo_url, tagline, accent_color, instagram, whatsapp, website_url') as any)
        .eq('user_id', ev.user_id).maybeSingle(),
      (supabase.from('profiles')
        .select('brand_name, brand_logo_url, brand_color, social_instagram, social_website') as any)
        .eq('user_id', ev.user_id).maybeSingle(),
    ]);

    setPhotoCount(countRes.count ?? 0);

    const sp   = spRes.data;
    const prof = profRes.data;
    if (sp?.studio_name) setStudioName(sp.studio_name);

    setStudioBranding({
      studio_name:    sp?.studio_name    || prof?.brand_name  || 'Studio',
      brand_name:     prof?.brand_name   || sp?.studio_name,
      brand_logo_url: prof?.brand_logo_url || sp?.logo_url,
      brand_color:    prof?.brand_color  || sp?.accent_color  || '#C4956A',
      tagline:        sp?.tagline,
      instagram:      sp?.instagram      || prof?.social_instagram,
      whatsapp:       sp?.whatsapp,
      website_url:    sp?.website_url    || prof?.social_website,
    });

    if (ev.gallery_style !== 'studio' && ev.gallery_pin) {
      if (sessionStorage.getItem(`unlocked_${ev.id}`) !== 'true') {
        setPinRequired(true);
      }
    }

    setLoading(false);
  }, [slug]);

  useEffect(() => { fetchEvent(); }, [fetchEvent]);

  const enterGallery = () => { if (event) navigate(`/event/${event.slug}/gallery`); };

  // ── Guards ───────────────────────────────────────────────
  if (loading) return <LoadingScreen />;

  if (notFound) return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center bg-background px-4 text-center gap-3">
      <Camera className="h-8 w-8 text-muted-foreground/15" />
      <h1 className="font-serif text-3xl font-light text-foreground">Gallery Not Found</h1>
      <p className="text-[12px] text-muted-foreground/40 font-sans">
        This link is invalid or the gallery has been removed.
      </p>
    </div>
  );

  if (!event) return null;

  // ── Studio mode (branded) ────────────────────────────────
  if ((event as any).gallery_mode === 'studio' && studioBranding) {
    return <StudioCoverPage event={event} branding={studioBranding} photoCount={photoCount} />;
  }

  // ── Studio style ─────────────────────────────────────────
  if (event.gallery_style === 'studio') {
    return <StudioLandingPage event={event} photoCount={photoCount} />;
  }

  // ── PIN gate ─────────────────────────────────────────────
  if (pinRequired) {
    return <PinGateScreen event={event} onUnlock={() => setPinRequired(false)} />;
  }

  // ── Standard cover ───────────────────────────────────────
  return (
    <>
      <StandardCover
        event={event}
        photoCount={photoCount}
        studioName={studioName}
        onEnter={enterGallery}
      />
      <GalleryInstallPrompt studioName={studioName} eventName={event.name} />
    </>
  );
};

export default GalleryCover;
