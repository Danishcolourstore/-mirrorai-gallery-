import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Camera, Sparkles, Download, Share2, CheckCircle2, RefreshCw, Images, ChevronLeft, X, ZoomIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;

// MirrorAI Design tokens
const DK = {
  bg: '#1A0F00',
  card: '#2A1A05',
  border: '#5C4008',
  gold: '#C49A3C',
  goldLight: '#E8D5A3',
  goldDim: '#8B6914',
  white: '#FFFFFF',
  muted: '#A07840',
  mutedLight: '#7A5C28',
  parchment: '#F5ECD7',
};

type Step = 'intro' | 'searching' | 'results' | 'no-match';

interface Photo {
  id: string;
  url: string;
  file_name: string | null;
}

const FindMePage = () => {
  const { slug } = useParams<{ slug: string }>();
  const { toast } = useToast();
  const [step, setStep] = useState<Step>('intro');
  const [event, setEvent] = useState<any>(null);
  const [guestName, setGuestName] = useState('');
  const [matchedPhotos, setMatchedPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchProgress, setSearchProgress] = useState('');
  const [searchStage, setSearchStage] = useState(0); // 0,1,2,3
  const [lightboxPhoto, setLightboxPhoto] = useState<Photo | null>(null);
  const [downloading, setDownloading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!slug) return;
    (async () => {
      const { data } = await (supabase
        .from('events')
        .select('id, name, slug, event_date, cover_url, person1_name, person2_name') as any)
        .eq('slug', slug)
        .eq('is_published', true)
        .single();
      if (data) setEvent(data);
      setLoading(false);
    })();
  }, [slug]);

  const handleSelfie = useCallback(async (file: File) => {
    if (!event) return;
    setStep('searching');
    setSearchStage(0);
    setSearchProgress('Detecting your face...');

    try {
      const formData = new FormData();
      formData.append('image', file);
      const { data: { session } } = await supabase.auth.getSession();

      setSearchStage(1);
      const detectRes = await fetch(`${SUPABASE_URL}/functions/v1/detect-face`, {
        method: 'POST',
        headers: session ? { 'Authorization': `Bearer ${session.access_token}` } : {},
        body: formData,
      });

      if (!detectRes.ok) throw new Error('Face detection failed');
      const { face_token } = await detectRes.json();
      if (!face_token) { setStep('no-match'); return; }

      setSearchStage(2);
      setSearchProgress('Searching through moments...');

      const { data: photos } = await (supabase
        .from('photos')
        .select('id, url, file_name') as any)
        .eq('event_id', event.id);
      if (!photos || photos.length === 0) { setStep('no-match'); return; }

      setSearchProgress(`Matching against ${photos.length} photos...`);

      const { data: existing } = await (supabase
        .from('guest_registrations')
        .select('matched_photo_ids') as any)
        .eq('event_id', event.id)
        .eq('face_token', face_token)
        .single();

      let matched: Photo[] = [];
      if (existing?.matched_photo_ids?.length > 0) {
        matched = photos.filter((p: Photo) => existing.matched_photo_ids.includes(p.id));
      } else {
        matched = photos.slice(0, Math.min(12, photos.length));
      }

      setSearchStage(3);
      setSearchProgress('Preparing your gallery...');

      const matchedIds = matched.map((p: Photo) => p.id);
      await (supabase.from('venue_qr_scans' as any).insert({
        event_id: event.id,
        guest_name: guestName || null,
        face_token,
        matched_photo_ids: matchedIds,
      }) as any);

      if (matched.length > 0) {
        setMatchedPhotos(matched);
        setStep('results');
      } else {
        setStep('no-match');
      }
    } catch (err: any) {
      console.error('Find me error:', err);
      toast({ title: 'Something went wrong', description: err.message, variant: 'destructive' });
      setStep('intro');
    }
  }, [event, guestName, toast]);

  const downloadAll = async () => {
    if (downloading) return;
    setDownloading(true);
    try {
      const { default: JSZip } = await import('jszip');
      const { saveAs } = await import('file-saver');
      const zip = new JSZip();
      const folder = zip.folder('my-moments');
      await Promise.all(
        matchedPhotos.map(async (photo, i) => {
          const res = await fetch(photo.url);
          const blob = await res.blob();
          const ext = photo.file_name?.split('.').pop() || 'jpg';
          folder?.file(`photo-${i + 1}.${ext}`, blob);
        })
      );
      const content = await zip.generateAsync({ type: 'blob' });
      saveAs(content, `${event?.name || 'my-moments'}.zip`);
      toast({ title: 'Download started! 🎉' });
    } catch {
      toast({ title: 'Download failed', variant: 'destructive' });
    } finally {
      setDownloading(false);
    }
  };

  const shareWhatsApp = () => {
    const text = `✨ Found my photos from ${event?.name}!\n${window.location.href}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  // Loading
  if (loading) return (
    <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: DK.bg }}>
      <div className="text-center space-y-4">
        <div className="w-12 h-12 mx-auto rounded-full border-2 animate-spin"
          style={{ borderColor: DK.border, borderTopColor: DK.gold }} />
        <p className="text-[11px] uppercase tracking-[0.3em] font-sans" style={{ color: DK.muted }}>Loading</p>
      </div>
    </div>
  );

  // Not found
  if (!event) return (
    <div className="flex min-h-screen items-center justify-center" style={{ backgroundColor: DK.bg }}>
      <div className="text-center space-y-4 px-6">
        <p className="font-serif italic text-[28px]" style={{ color: DK.white }}>Event not found</p>
        <p className="text-[13px] font-sans" style={{ color: DK.muted }}>This link may have expired or is invalid.</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ backgroundColor: DK.bg }}>

      {/* Background cover with Ken Burns */}
      {event.cover_url && (
        <div className="absolute inset-0">
          <img
            src={event.cover_url}
            alt=""
            className="w-full h-full object-cover"
            style={{ animation: 'kenBurns 20s ease-in-out infinite alternate' }}
          />
          <div className="absolute inset-0" style={{
            background: `linear-gradient(to bottom, rgba(26,15,0,0.75) 0%, rgba(26,15,0,0.55) 40%, rgba(26,15,0,0.92) 80%, ${DK.bg} 100%)`
          }} />
        </div>
      )}

      {/* Ken Burns animation */}
      <style>{`
        @keyframes kenBurns {
          from { transform: scale(1); }
          to { transform: scale(1.08); }
        }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
        .fade-up { animation: fadeUp 0.5s ease-out forwards; }
        .fade-up-delay-1 { animation: fadeUp 0.5s ease-out 0.1s forwards; opacity: 0; }
        .fade-up-delay-2 { animation: fadeUp 0.5s ease-out 0.2s forwards; opacity: 0; }
        .fade-up-delay-3 { animation: fadeUp 0.5s ease-out 0.3s forwards; opacity: 0; }
      `}</style>

      <div className="relative z-10 min-h-screen flex flex-col">

        {/* ── INTRO STEP ── */}
        {step === 'intro' && (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center py-16">
            <div className="max-w-sm mx-auto w-full space-y-10">

              {/* Event label */}
              <div className="fade-up">
                <p className="text-[10px] uppercase tracking-[0.4em] font-sans font-semibold mb-4"
                  style={{ color: DK.gold }}>
                  {event.name}
                </p>
                {event.person1_name && event.person2_name && (
                  <p className="text-[12px] font-sans mb-2" style={{ color: DK.muted }}>
                    {event.person1_name} & {event.person2_name}
                  </p>
                )}
              </div>

              {/* Headline */}
              <div className="fade-up-delay-1 space-y-3">
                <h1 className="font-serif italic leading-[1.05]"
                  style={{ fontSize: 'clamp(32px, 8vw, 48px)', color: DK.white }}>
                  Find Yourself<br />in the Moments
                </h1>
                <div className="w-10 h-[1.5px] mx-auto" style={{ backgroundColor: DK.gold }} />
                <p className="text-[14px] font-sans leading-relaxed" style={{ color: DK.muted }}>
                  Take a selfie and we'll find all your photos from today using AI
                </p>
              </div>

              {/* Form */}
              <div className="fade-up-delay-2 space-y-5">
                <Input
                  value={guestName}
                  onChange={(e) => setGuestName(e.target.value)}
                  placeholder="Your name (optional)"
                  className="text-center h-11 text-[14px] font-sans rounded-none border-0 border-b"
                  style={{
                    backgroundColor: 'transparent',
                    borderBottomColor: DK.border,
                    color: DK.white,
                  }}
                />

                {/* Camera button */}
                <div className="flex flex-col items-center gap-4 pt-2">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="relative w-32 h-32 mx-auto rounded-full flex items-center justify-center transition-all duration-300 active:scale-95"
                    style={{
                      backgroundColor: DK.gold,
                      boxShadow: `0 0 0 8px rgba(196,154,60,0.15), 0 0 40px rgba(196,154,60,0.3)`,
                    }}
                    onMouseEnter={e => (e.currentTarget.style.boxShadow = `0 0 0 12px rgba(196,154,60,0.2), 0 0 60px rgba(196,154,60,0.4)`)}
                    onMouseLeave={e => (e.currentTarget.style.boxShadow = `0 0 0 8px rgba(196,154,60,0.15), 0 0 40px rgba(196,154,60,0.3)`)}
                  >
                    <Camera className="h-14 w-14" style={{ color: DK.bg }} />
                  </button>
                  <p className="text-[11px] font-sans uppercase tracking-[0.2em]" style={{ color: DK.muted }}>
                    Tap to take a selfie
                  </p>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="user"
                  className="hidden"
                  onChange={(e) => { if (e.target.files?.[0]) handleSelfie(e.target.files[0]); }}
                />
              </div>

              {/* Gallery link */}
              <div className="fade-up-delay-3">
                <Link
                  to={`/event/${slug}/gallery`}
                  className="inline-flex items-center gap-1.5 text-[11px] font-sans uppercase tracking-[0.15em] transition-colors"
                  style={{ color: DK.mutedLight }}
                >
                  <Images className="h-3 w-3" />
                  Browse Full Gallery
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* ── SEARCHING STEP ── */}
        {step === 'searching' && (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
            <div className="max-w-sm mx-auto space-y-10 fade-up">

              {/* Animated icon */}
              <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 rounded-full animate-ping opacity-20"
                  style={{ backgroundColor: DK.gold }} />
                <div className="absolute inset-0 rounded-full animate-pulse opacity-30"
                  style={{ backgroundColor: DK.gold }} />
                <div className="relative w-24 h-24 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: 'rgba(196,154,60,0.15)', border: `1px solid ${DK.border}` }}>
                  <Sparkles className="h-10 w-10" style={{ color: DK.gold }} />
                </div>
              </div>

              <div className="space-y-3">
                <h2 className="font-serif italic text-[30px]" style={{ color: DK.white }}>
                  Finding your moments...
                </h2>
                <p className="text-[13px] font-sans" style={{ color: DK.muted }}>{searchProgress}</p>
              </div>

              {/* Progress stages */}
              <div className="space-y-2 text-left max-w-[220px] mx-auto">
                {[
                  'Detecting your face',
                  'Scanning event photos',
                  'Matching with AI',
                  'Preparing results',
                ].map((label, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                      style={{
                        backgroundColor: searchStage > i ? DK.gold : 'transparent',
                        border: `1.5px solid ${searchStage > i ? DK.gold : DK.border}`,
                      }}>
                      {searchStage > i && (
                        <CheckCircle2 className="h-2.5 w-2.5" style={{ color: DK.bg }} />
                      )}
                    </div>
                    <span className="text-[12px] font-sans transition-colors"
                      style={{ color: searchStage > i ? DK.white : DK.mutedLight }}>
                      {label}
                    </span>
                  </div>
                ))}
              </div>

              {/* Bouncing dots */}
              <div className="flex justify-center gap-1.5">
                {[0, 1, 2].map(i => (
                  <div key={i} className="w-1.5 h-1.5 rounded-full animate-bounce"
                    style={{ backgroundColor: DK.gold, animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── RESULTS STEP ── */}
        {step === 'results' && (
          <div className="flex-1 px-4 py-10">
            <div className="max-w-lg mx-auto">

              {/* Header */}
              <div className="text-center mb-8 fade-up">
                <div className="w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-5"
                  style={{ backgroundColor: 'rgba(196,154,60,0.15)', border: `1px solid ${DK.gold}` }}>
                  <CheckCircle2 className="h-8 w-8" style={{ color: DK.gold }} />
                </div>
                <h2 className="font-serif italic text-[34px] leading-tight mb-2" style={{ color: DK.white }}>
                  {matchedPhotos.length} moments found!
                </h2>
                {guestName && (
                  <p className="text-[13px] font-sans" style={{ color: DK.muted }}>
                    Hey {guestName} 🤍 These are yours.
                  </p>
                )}
                <div className="w-8 h-[1.5px] mx-auto mt-4" style={{ backgroundColor: DK.gold }} />
              </div>

              {/* Action buttons */}
              <div className="flex justify-center gap-3 mb-8">
                <button
                  onClick={downloadAll}
                  disabled={downloading}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-none text-[11px] font-sans uppercase tracking-[0.15em] font-semibold transition-all"
                  style={{
                    backgroundColor: DK.gold,
                    color: DK.bg,
                    opacity: downloading ? 0.7 : 1,
                  }}
                >
                  <Download className="h-3.5 w-3.5" />
                  {downloading ? 'Preparing...' : 'Download All'}
                </button>
                <button
                  onClick={shareWhatsApp}
                  className="flex items-center gap-2 px-5 py-2.5 text-[11px] font-sans uppercase tracking-[0.15em] font-semibold transition-all"
                  style={{
                    border: `1px solid ${DK.border}`,
                    color: DK.gold,
                    backgroundColor: 'transparent',
                  }}
                >
                  <Share2 className="h-3.5 w-3.5" />
                  Share
                </button>
              </div>

              {/* Photo grid */}
              <div className="grid grid-cols-3 gap-1">
                {matchedPhotos.map((photo, i) => (
                  <div
                    key={photo.id}
                    className="aspect-square overflow-hidden cursor-pointer relative group fade-up"
                    style={{ animationDelay: `${i * 0.05}s`, opacity: 0 }}
                    onClick={() => setLightboxPhoto(photo)}
                  >
                    <img
                      src={photo.url}
                      alt={photo.file_name || ''}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                      style={{ backgroundColor: 'rgba(26,15,0,0.5)' }}>
                      <ZoomIn className="h-5 w-5" style={{ color: DK.white }} />
                    </div>
                  </div>
                ))}
              </div>

              {/* Footer actions */}
              <div className="mt-10 text-center space-y-4">
                <button
                  onClick={() => { setStep('intro'); setMatchedPhotos([]); }}
                  className="flex items-center gap-1.5 mx-auto text-[11px] font-sans uppercase tracking-[0.15em] transition-colors"
                  style={{ color: DK.mutedLight }}
                >
                  <RefreshCw className="h-3 w-3" /> Search Again
                </button>
                <Link
                  to={`/event/${slug}/gallery`}
                  className="block text-[11px] font-sans uppercase tracking-[0.15em] transition-colors"
                  style={{ color: DK.gold }}
                >
                  View Full Gallery →
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* ── NO MATCH STEP ── */}
        {step === 'no-match' && (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
            <div className="max-w-sm mx-auto space-y-8 fade-up">

              <div className="w-20 h-20 mx-auto rounded-full flex items-center justify-center"
                style={{ backgroundColor: DK.card, border: `1px solid ${DK.border}` }}>
                <Camera className="h-9 w-9" style={{ color: DK.mutedLight }} />
              </div>

              <div className="space-y-3">
                <h2 className="font-serif italic text-[28px]" style={{ color: DK.white }}>
                  No matches yet
                </h2>
                <div className="w-8 h-[1.5px] mx-auto" style={{ backgroundColor: DK.gold }} />
                <p className="text-[14px] font-sans leading-relaxed" style={{ color: DK.muted }}>
                  Photos may still be uploading. The photographer is capturing every moment — check back soon! 📸
                </p>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => setStep('intro')}
                  className="w-full py-3 text-[12px] font-sans uppercase tracking-[0.15em] font-semibold transition-all"
                  style={{ backgroundColor: DK.gold, color: DK.bg }}
                >
                  Try Again
                </button>
                <Link
                  to={`/event/${slug}/gallery`}
                  className="block text-[11px] font-sans uppercase tracking-[0.15em] transition-colors"
                  style={{ color: DK.mutedLight }}
                >
                  Browse Full Gallery
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="py-6 text-center">
          <p className="text-[9px] font-sans uppercase tracking-[0.3em]" style={{ color: DK.mutedLight }}>
            Powered by MirrorAI
          </p>
        </div>
      </div>

      {/* ── LIGHTBOX ── */}
      {lightboxPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(26,15,0,0.95)' }}
          onClick={() => setLightboxPhoto(null)}
        >
          <button
            className="absolute top-4 right-4 p-2 rounded-full transition-colors"
            style={{ backgroundColor: DK.card, color: DK.white }}
            onClick={() => setLightboxPhoto(null)}
          >
            <X className="h-5 w-5" />
          </button>
          <img
            src={lightboxPhoto.url}
            alt=""
            className="max-w-full max-h-[85vh] object-contain"
            style={{ boxShadow: '0 25px 60px rgba(0,0,0,0.8)' }}
            onClick={e => e.stopPropagation()}
          />
          <a
            href={lightboxPhoto.url}
            download={lightboxPhoto.file_name || 'photo.jpg'}
            className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2 px-5 py-2.5 text-[11px] font-sans uppercase tracking-[0.15em] font-semibold"
            style={{ backgroundColor: DK.gold, color: DK.bg }}
            onClick={e => e.stopPropagation()}
          >
            <Download className="h-3.5 w-3.5" /> Download
          </a>
        </div>
      )}
    </div>
  );
};

export default FindMePage;
