import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const MirrorLive = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [events, setEvents] = useState<any[]>([]);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [photos, setPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [liveActive, setLiveActive] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "slideshow">("grid");
  const [slideshowIndex, setSlideshowIndex] = useState(0);

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchEvents();
  }, [session]);

  useEffect(() => {
    if (!selectedEvent) return;
    fetchPhotos();

    // Real-time subscription
    const channel = supabase
      .channel(`mirror-live-${selectedEvent.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "photos",
          filter: `event_id=eq.${selectedEvent.id}`,
        },
        (payload) => {
          setPhotos((prev) => [payload.new as any, ...prev]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedEvent]);

  // Slideshow auto-advance
  useEffect(() => {
    if (!liveActive || viewMode !== "slideshow" || photos.length === 0) return;
    const timer = setInterval(() => {
      setSlideshowIndex((prev) =>
        prev < photos.length - 1 ? prev + 1 : 0
      );
    }, 4000);
    return () => clearInterval(timer);
  }, [liveActive, viewMode, photos.length]);

  const fetchEvents = async () => {
    try {
      const { data } = await supabase
        .from("events")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false });
      if (data) setEvents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchPhotos = async () => {
    if (!selectedEvent) return;
    try {
      const { data } = await supabase
        .from("photos")
        .select("*")
        .eq("event_id", selectedEvent.id)
        .order("created_at", { ascending: false });
      if (data) setPhotos(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !selectedEvent) return;
    setUploading(true);
    setError("");
    try {
      for (const file of Array.from(files)) {
        const fileExt = file.name.split(".").pop();
        const fileName = `${session.user.id}/${selectedEvent.id}/${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from("photos")
          .upload(fileName, file);
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage
          .from("photos")
          .getPublicUrl(fileName);
        await supabase.from("photos").insert({
          event_id: selectedEvent.id,
          user_id: session.user.id,
          url: urlData.publicUrl,
          filename: file.name,
        });
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const copyLiveLink = () => {
    if (!selectedEvent) return;
    const slug = selectedEvent.slug || selectedEvent.id;
    const link = `${window.location.origin}/live/${slug}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  // Slideshow fullscreen view
  if (liveActive && viewMode === "slideshow" && photos.length > 0) {
    return (
      <div className="fixed inset-0 bg-black flex flex-col items-center justify-center z-50">
        {/* Slideshow Image */}
        <img
          src={photos[slideshowIndex]?.url}
          alt=""
          className="max-h-[85vh] max-w-[90vw] object-contain rounded-2xl shadow-2xl"
        />

        {/* Slideshow Controls */}
        <div className="absolute bottom-8 left-0 right-0 flex flex-col items-center gap-4 px-6">
          <div className="flex items-center gap-2">
            {photos.slice(0, 10).map((_, i) => (
              <div
                key={i}
                onClick={() => setSlideshowIndex(i)}
                className={`w-2 h-2 rounded-full cursor-pointer transition-all ${
                  i === slideshowIndex
                    ? "bg-[#c9a96e] w-4"
                    : "bg-[#444]"
                }`}
              />
            ))}
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() =>
                setSlideshowIndex((p) => (p > 0 ? p - 1 : photos.length - 1))
              }
              className="bg-white/10 hover:bg-white/20 text-white w-10 h-10 rounded-full flex items-center justify-center transition-all"
            >
              ‹
            </button>
            <button
              onClick={() => setLiveActive(false)}
              className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-2 rounded-xl tracking-widest uppercase transition-all"
            >
              Exit
            </button>
            <button
              onClick={() =>
                setSlideshowIndex((p) => (p < photos.length - 1 ? p + 1 : 0))
              }
              className="bg-white/10 hover:bg-white/20 text-white w-10 h-10 rounded-full flex items-center justify-center transition-all"
            >
              ›
            </button>
          </div>
          <p className="text-[#888] text-xs tracking-widest uppercase">
            {slideshowIndex + 1} / {photos.length} · Live updating
          </p>
        </div>

        {/* Live badge */}
        <div className="absolute top-6 left-6 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <span className="text-white text-xs tracking-widest uppercase">
            Mirror Live
          </span>
        </div>

        {/* Upload in slideshow */}
        <label className="absolute top-6 right-6 bg-[#c9a96e] hover:bg-[#b8924f] text-black text-xs font-semibold px-4 py-2 rounded-xl tracking-widest uppercase cursor-pointer transition-all">
          {uploading ? "..." : "+ Photo"}
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={handleUpload}
            className="hidden"
            disabled={uploading}
          />
        </label>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-40">
        <button
          onClick={() => navigate("/dashboard")}
          className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
        >
          ← Dashboard
        </button>
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
            Mirror Live
          </h1>
        </div>
        {selectedEvent && (
          <button
            onClick={copyLiveLink}
            className={`border text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all ${
              copied
                ? "border-green-500 text-green-400"
                : "border-[#c9a96e] text-[#c9a96e] hover:bg-[#c9a96e] hover:text-black"
            }`}
          >
            {copied ? "Copied! ✓" : "Live Link"}
          </button>
        )}
        {!selectedEvent && <div className="w-24" />}
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">

        {/* Intro */}
        {!selectedEvent && (
          <div className="text-center mb-12">
            <div className="text-5xl mb-4">🪞</div>
            <h2 className="text-3xl font-serif text-white mb-3">
              Mirror Live
            </h2>
            <p className="text-[#888] text-sm tracking-widest max-w-md mx-auto leading-relaxed">
              Share a live photo feed at your event. Guests see photos appear
              in real time on any device — no app needed.
            </p>
          </div>
        )}

        {/* Event Selector */}
        {!selectedEvent ? (
          <div>
            <p className="text-[#888] text-xs tracking-widest uppercase mb-4 text-center">
              Select an event to go live
            </p>
            {events.length === 0 ? (
              <div className="text-center py-16 border border-dashed border-[#2a2a2a] rounded-2xl">
                <p className="text-[#444] text-sm tracking-widest uppercase mb-4">
                  No events found
                </p>
                <button
                  onClick={() => navigate("/events")}
                  className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-3 rounded-xl tracking-widest uppercase transition-all"
                >
                  Create an Event
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {events.map((event) => (
                  <div
                    key={event.id}
                    onClick={() => setSelectedEvent(event)}
                    className="bg-[#111] border border-[#1a1a1a] rounded-2xl overflow-hidden cursor-pointer hover:border-[#c9a96e] transition-all group"
                  >
                    <div className="h-40 bg-[#1a1a1a] flex items-center justify-center overflow-hidden">
                      {event.cover_image ? (
                        <img
                          src={event.cover_image}
                          alt={event.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      ) : (
                        <span className="text-[#333] text-3xl">📷</span>
                      )}
                    </div>
                    <div className="p-4">
                      <h3 className="text-white font-serif text-lg mb-1">
                        {event.name}
                      </h3>
                      <p className="text-[#888] text-xs tracking-widest">
                        {event.date
                          ? new Date(event.date).toLocaleDateString()
                          : "No date"}{" "}
                        · {event.location || "No location"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div>
            {/* Event Header */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
              <div>
                <button
                  onClick={() => {
                    setSelectedEvent(null);
                    setLiveActive(false);
                    setPhotos([]);
                  }}
                  className="text-[#888] hover:text-[#c9a96e] text-xs tracking-widest uppercase transition-all mb-2 block"
                >
                  ← Change Event
                </button>
                <h2 className="text-2xl font-serif text-white">
                  {selectedEvent.name}
                </h2>
                <p className="text-[#888] text-sm tracking-widest">
                  {selectedEvent.location || "No location"} ·{" "}
                  <span className="text-[#c9a96e]">
                    {photos.length} photos
                  </span>
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                {/* View Mode */}
                <div className="flex border border-[#2a2a2a] rounded-xl overflow-hidden">
                  <button
                    onClick={() => setViewMode("grid")}
                    className={`px-4 py-2 text-xs tracking-widest uppercase transition-all ${
                      viewMode === "grid"
                        ? "bg-[#1a1a1a] text-white"
                        : "text-[#888] hover:text-white"
                    }`}
                  >
                    Grid
                  </button>
                  <button
                    onClick={() => setViewMode("slideshow")}
                    className={`px-4 py-2 text-xs tracking-widest uppercase transition-all ${
                      viewMode === "slideshow"
                        ? "bg-[#1a1a1a] text-white"
                        : "text-[#888] hover:text-white"
                    }`}
                  >
                    Slideshow
                  </button>
                </div>

                {/* Upload */}
                <label className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all cursor-pointer">
                  {uploading ? "Uploading..." : "+ Upload"}
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleUpload}
                    className="hidden"
                    disabled={uploading}
                  />
                </label>

                {/* Go Live */}
                <button
                  onClick={() => {
                    setLiveActive(true);
                    if (viewMode === "slideshow") setSlideshowIndex(0);
                  }}
                  className="bg-red-600 hover:bg-red-500 text-white text-sm font-semibold px-5 py-2 rounded-xl tracking-widest uppercase transition-all flex items-center gap-2"
                >
                  <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                  Go Live
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-6">
                {error}
              </div>
            )}

            {/* Live Link Banner */}
            <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl px-6 py-4 mb-8 flex flex-wrap items-center justify-between gap-4">
              <div>
                <p className="text-[#888] text-xs tracking-widest uppercase mb-1">
                  Guest Live Link
                </p>
                <p className="text-white text-sm font-mono">
                  {window.location.origin}/live/
                  {selectedEvent.slug || selectedEvent.id}
                </p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={copyLiveLink}
                  className={`text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all border ${
                    copied
                      ? "border-green-500 text-green-400"
                      : "border-[#c9a96e] text-[#c9a96e] hover:bg-[#c9a96e] hover:text-black"
                  }`}
                >
                  {copied ? "Copied! ✓" : "Copy Link"}
                </button>
                <button
                  onClick={() =>
                    window.open(
                      `/live/${selectedEvent.slug || selectedEvent.id}`,
                      "_blank"
                    )
                  }
                  className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
                >
                  Preview
                </button>
              </div>
            </div>

            {/* Photos Grid */}
            {photos.length === 0 ? (
              <div className="text-center py-24 border border-dashed border-[#2a2a2a] rounded-2xl">
                <div className="text-4xl mb-4">📸</div>
                <p className="text-[#444] text-sm tracking-widest uppercase mb-4">
                  No photos yet — upload to start the live feed
                </p>
                <label className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-3 rounded-xl tracking-widest uppercase transition-all cursor-pointer">
                  Upload First Photo
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleUpload}
                    className="hidden"
                  />
                </label>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {photos.map((photo, index) => (
                  <div
                    key={photo.id}
                    onClick={() => {
                      setSlideshowIndex(index);
                      setViewMode("slideshow");
                      setLiveActive(true);
                    }}
                    className="aspect-square bg-[#1a1a1a] rounded-xl overflow-hidden cursor-pointer group relative"
                  >
                    <img
                      src={photo.url}
                      alt={photo.filename}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-300 flex items-center justify-center">
                      <span className="text-white text-xl opacity-0 group-hover:opacity-100 transition-all">
                        ▶
                      </span>
                    </div>
                    {index === 0 && (
                      <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded-lg tracking-widest flex items-center gap-1">
                        <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                        New
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1a1a1a] mt-16 px-6 py-6 text-center">
        <p className="text-[#444] text-xs tracking-widest uppercase">
          © 2024 MirrorAI · Mirror Live — Real-Time Photo Feed
        </p>
      </footer>
    </div>
  );
};

export default MirrorLive;
