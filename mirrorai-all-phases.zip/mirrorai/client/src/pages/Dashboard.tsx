import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const Dashboard = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    events: 0,
    photos: 0,
    views: 0,
    storage: 0,
  });
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchData();
  }, [session]);

  const fetchData = async () => {
    try {
      // Fetch events
      const { data: eventsData } = await supabase
        .from("events")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false });

      if (eventsData) {
        // Fetch photo count per event
        const eventsWithCount = await Promise.all(
          eventsData.map(async (event) => {
            const { count } = await supabase
              .from("photos")
              .select("*", { count: "exact", head: true })
              .eq("event_id", event.id);
            return { ...event, photo_count: count || 0 };
          })
        );
        setEvents(eventsWithCount);
        setStats((prev) => ({ ...prev, events: eventsData.length }));
      }

      // Fetch total photos count
      const { count: photosCount } = await supabase
        .from("photos")
        .select("*", { count: "exact", head: true })
        .eq("user_id", session.user.id);

      if (photosCount) {
        setStats((prev) => ({ ...prev, photos: photosCount }));
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const navLinks = [
    { label: "Events", path: "/events", icon: "📅" },
    { label: "Upload", path: "/upload", icon: "📸" },
    { label: "Mirror Live", path: "/mirror-live", icon: "🪞" },
    { label: "Analytics", path: "/analytics", icon: "📊" },
    { label: "Branding", path: "/branding", icon: "🎨" },
    { label: "Blog", path: "/blog", icon: "📝" },
    { label: "Find Me", path: "/find-me", icon: "🔍" },
    { label: "My Book", path: "/my-book", icon: "📖" },
    { label: "Portfolio", path: "/portfolio", icon: "🖼️" },
    { label: "Settings", path: "/settings", icon: "⚙️" },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-40">
        <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
          MirrorAI
        </h1>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {navLinks.map((link) => (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className="text-[#888] hover:text-[#c9a96e] text-xs tracking-widest uppercase px-3 py-2 rounded-xl hover:bg-[#1a1a1a] transition-all"
            >
              {link.icon} {link.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <span className="text-[#888] text-sm hidden lg:block">
            {session?.user?.email}
          </span>
          <button
            onClick={() => navigate("/events")}
            className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-4 py-2 rounded-xl tracking-widest uppercase transition-all hidden md:block"
          >
            + New Event
          </button>
          <button
            onClick={handleSignOut}
            className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all hidden md:block"
          >
            Sign Out
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden border border-[#2a2a2a] text-[#888] px-3 py-2 rounded-xl text-sm"
          >
            {menuOpen ? "✕" : "☰"}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-[#111] border-b border-[#1a1a1a] px-6 py-4 z-30">
          <div className="grid grid-cols-2 gap-2 mb-4">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => { navigate(link.path); setMenuOpen(false); }}
                className="text-[#888] hover:text-[#c9a96e] text-xs tracking-widest uppercase px-3 py-3 rounded-xl hover:bg-[#1a1a1a] transition-all text-left border border-[#1a1a1a]"
              >
                {link.icon} {link.label}
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => { navigate("/events"); setMenuOpen(false); }}
              className="flex-1 bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
            >
              + New Event
            </button>
            <button
              onClick={handleSignOut}
              className="flex-1 border border-[#2a2a2a] text-[#888] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
            >
              Sign Out
            </button>
          </div>
          <p className="text-[#555] text-xs mt-3 text-center">
            {session?.user?.email}
          </p>
        </div>
      )}

      <main className="max-w-6xl mx-auto px-6 py-10">

        {/* Welcome */}
        <div className="mb-10">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-1">
            Welcome back
          </p>
          <h2 className="text-3xl font-serif text-white">
            Your Studio Dashboard
          </h2>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: "Events", value: stats.events, icon: "📅" },
            { label: "Photos", value: stats.photos, icon: "📷" },
            { label: "Storage", value: "1 MB", icon: "💾" },
            { label: "Views", value: stats.views, icon: "👁️" },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-5 text-center hover:border-[#c9a96e] transition-all"
            >
              <div className="text-2xl mb-2">{stat.icon}</div>
              <div className="text-3xl font-serif text-white mb-1">
                {stat.value}
              </div>
              <div className="text-[#888] text-xs tracking-widest uppercase">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mb-12">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
            Quick Actions
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {[
              { label: "New Event", path: "/events", icon: "📅", primary: true },
              { label: "Upload Photos", path: "/upload", icon: "📸", primary: false },
              { label: "Mirror Live", path: "/mirror-live", icon: "🪞", primary: false },
              { label: "Analytics", path: "/analytics", icon: "📊", primary: false },
              { label: "Branding", path: "/branding", icon: "🎨", primary: false },
            ].map((action) => (
              <button
                key={action.path}
                onClick={() => navigate(action.path)}
                className={`flex flex-col items-center gap-2 py-4 px-3 rounded-2xl text-xs tracking-widest uppercase transition-all border ${
                  action.primary
                    ? "bg-[#c9a96e] hover:bg-[#b8924f] text-black border-transparent font-semibold"
                    : "bg-[#111] border-[#1a1a1a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e]"
                }`}
              >
                <span className="text-2xl">{action.icon}</span>
                {action.label}
              </button>
            ))}
          </div>
        </div>

        {/* Recent Events */}
        <div className="mb-6 flex items-center justify-between">
          <div>
            <p className="text-[#888] text-xs tracking-widest uppercase mb-1">
              Your Work
            </p>
            <h2 className="text-2xl font-serif text-white">Recent Events</h2>
          </div>
          <button
            onClick={() => navigate("/events")}
            className="text-[#c9a96e] text-sm tracking-widest uppercase hover:underline"
          >
            View All →
          </button>
        </div>

        {/* Events Grid */}
        {events.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-[#2a2a2a] rounded-2xl">
            <p className="text-[#444] text-sm tracking-widest uppercase mb-4">
              No events yet
            </p>
            <button
              onClick={() => navigate("/events")}
              className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-3 rounded-xl tracking-widest uppercase transition-all"
            >
              Create Your First Event
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {events.slice(0, 6).map((event) => (
              <div
                key={event.id}
                onClick={() => navigate(`/event/${event.id}`)}
                className="bg-[#111] border border-[#1a1a1a] rounded-2xl overflow-hidden cursor-pointer hover:border-[#c9a96e] transition-all group"
              >
                {/* Thumbnail */}
                <div className="h-48 bg-[#1a1a1a] flex items-center justify-center overflow-hidden">
                  {event.cover_image ? (
                    <img
                      src={event.cover_image}
                      alt={event.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <span className="text-[#333] text-4xl">📷</span>
                  )}
                </div>

                {/* Info */}
                <div className="p-4">
                  <h3 className="text-white font-serif text-lg mb-1">
                    {event.name}
                  </h3>
                  <p className="text-[#888] text-xs tracking-widest mb-3">
                    {new Date(event.created_at).toLocaleDateString()} ·{" "}
                    {event.photo_count} photo{event.photo_count !== 1 ? "s" : ""}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/event/${event.id}`);
                      }}
                      className="flex-1 text-xs border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      View
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/gallery-cover/${event.id}`);
                      }}
                      className="flex-1 text-xs border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Cover
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate("/upload");
                      }}
                      className="flex-1 text-xs border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Upload
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* All Tools */}
        <div className="mt-16">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
            All Tools
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => navigate(link.path)}
                className="flex flex-col items-center gap-2 py-5 px-3 rounded-2xl text-xs tracking-widest uppercase bg-[#111] border border-[#1a1a1a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] transition-all"
              >
                <span className="text-2xl">{link.icon}</span>
                {link.label}
              </button>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1a1a1a] mt-16 px-6 py-6 text-center">
        <p className="text-[#444] text-xs tracking-widest uppercase">
          © 2024 MirrorAI · Luxury Photo Gallery Platform
        </p>
      </footer>
    </div>
  );
};

export default Dashboard;
