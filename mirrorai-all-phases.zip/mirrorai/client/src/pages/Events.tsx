import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const Events = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [eventName, setEventName] = useState("");
  const [eventDate, setEventDate] = useState("");
  const [eventLocation, setEventLocation] = useState("");
  const [eventType, setEventType] = useState("");
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [photoCounts, setPhotoCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchEvents();
  }, [session]);

  const fetchEvents = async () => {
    try {
      const { data } = await supabase
        .from("events")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false });

      if (data) {
        setEvents(data);

        // Fetch photo counts per event
        const counts: Record<string, number> = {};
        await Promise.all(
          data.map(async (event) => {
            const { count } = await supabase
              .from("photos")
              .select("*", { count: "exact", head: true })
              .eq("event_id", event.id);
            counts[event.id] = count || 0;
          })
        );
        setPhotoCounts(counts);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setError("");
    try {
      const slug = eventName
        .toLowerCase()
        .replace(/\s+/g, "-")
        .replace(/[^a-z0-9-]/g, "");

      const { error } = await supabase.from("events").insert({
        name: eventName,
        date: eventDate,
        location: eventLocation,
        type: eventType,
        slug: `${slug}-${Date.now()}`,
        user_id: session.user.id,
      });

      if (error) throw error;

      setEventName("");
      setEventDate("");
      setEventLocation("");
      setEventType("");
      setShowForm(false);
      fetchEvents();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteEvent = async (id: string) => {
    if (!confirm("Delete this event and all its photos?")) return;
    await supabase.from("events").delete().eq("id", id);
    fetchEvents();
  };

  const copyGalleryLink = (event: any) => {
    const slug = event.slug || event.id;
    const link = `${window.location.origin}/gallery/${slug}`;
    navigator.clipboard.writeText(link);
    alert("Gallery link copied!");
  };

  const filteredEvents = events.filter((event) =>
    event.name.toLowerCase().includes(search.toLowerCase()) ||
    (event.location || "").toLowerCase().includes(search.toLowerCase())
  );

  const eventTypes = [
    "Wedding", "Portrait", "Corporate", "Birthday",
    "Engagement", "Concert", "Sports", "Other"
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-40">
        <button
          onClick={() => navigate("/dashboard")}
          className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
        >
          ← Dashboard
        </button>
        <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
          Events
        </h1>
        <button
          onClick={() => setShowForm(true)}
          className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
        >
          + New Event
        </button>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">

        {/* Stats Bar */}
        <div className="grid grid-cols-3 gap-4 mb-10">
          {[
            { label: "Total Events", value: events.length, icon: "📅" },
            {
              label: "Total Photos",
              value: Object.values(photoCounts).reduce((a, b) => a + b, 0),
              icon: "📷",
            },
            {
              label: "This Month",
              value: events.filter((e) => {
                const d = new Date(e.created_at);
                const now = new Date();
                return (
                  d.getMonth() === now.getMonth() &&
                  d.getFullYear() === now.getFullYear()
                );
              }).length,
              icon: "🗓️",
            },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-4 text-center"
            >
              <div className="text-2xl mb-1">{stat.icon}</div>
              <div className="text-2xl font-serif text-white">{stat.value}</div>
              <div className="text-[#888] text-xs tracking-widest uppercase mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Search */}
        <div className="mb-8">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search events by name or location..."
            className="w-full bg-[#111] border border-[#1a1a1a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
          />
        </div>

        {/* Create Event Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 px-4">
            <div className="bg-[#111] border border-[#2a2a2a] rounded-2xl p-8 w-full max-w-md">
              <h2 className="text-xl font-serif text-white mb-6">
                Create New Event
              </h2>
              <form onSubmit={handleCreateEvent} className="space-y-4">

                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Event Name *
                  </label>
                  <input
                    type="text"
                    value={eventName}
                    onChange={(e) => setEventName(e.target.value)}
                    required
                    placeholder="Wedding, Birthday, Corporate..."
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>

                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Event Type
                  </label>
                  <select
                    value={eventType}
                    onChange={(e) => setEventType(e.target.value)}
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#c9a96e] transition-all"
                  >
                    <option value="">Select type...</option>
                    {eventTypes.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Date
                  </label>
                  <input
                    type="date"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>

                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    value={eventLocation}
                    onChange={(e) => setEventLocation(e.target.value)}
                    placeholder="City, Venue..."
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>

                {error && (
                  <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 border border-[#2a2a2a] text-[#888] py-3 rounded-xl tracking-widest uppercase text-sm transition-all hover:border-[#444]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creating}
                    className="flex-1 bg-[#c9a96e] hover:bg-[#b8924f] text-black font-semibold py-3 rounded-xl tracking-widest uppercase text-sm transition-all disabled:opacity-50"
                  >
                    {creating ? "Creating..." : "Create"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Events Grid */}
        {filteredEvents.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-[#2a2a2a] rounded-2xl">
            <p className="text-[#444] text-sm tracking-widest uppercase mb-4">
              {search ? "No events match your search" : "No events yet"}
            </p>
            {!search && (
              <button
                onClick={() => setShowForm(true)}
                className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-3 rounded-xl tracking-widest uppercase transition-all"
              >
                Create Your First Event
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {filteredEvents.map((event) => (
              <div
                key={event.id}
                className="bg-[#111] border border-[#1a1a1a] rounded-2xl overflow-hidden hover:border-[#c9a96e] transition-all group"
              >
                {/* Thumbnail */}
                <div
                  className="h-48 bg-[#1a1a1a] flex items-center justify-center cursor-pointer overflow-hidden relative"
                  onClick={() => navigate(`/event/${event.id}`)}
                >
                  {event.cover_image ? (
                    <img
                      src={event.cover_image}
                      alt={event.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  ) : (
                    <span className="text-[#333] text-4xl">📷</span>
                  )}

                  {/* Photo count badge */}
                  <div className="absolute top-3 right-3 bg-black/60 text-white text-xs px-2 py-1 rounded-lg tracking-widest">
                    {photoCounts[event.id] || 0} photos
                  </div>

                  {/* Type badge */}
                  {event.type && (
                    <div className="absolute top-3 left-3 bg-[#c9a96e]/80 text-black text-xs px-2 py-1 rounded-lg tracking-widest uppercase font-semibold">
                      {event.type}
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="p-4">
                  <h3
                    className="text-white font-serif text-lg mb-1 cursor-pointer hover:text-[#c9a96e] transition-all"
                    onClick={() => navigate(`/event/${event.id}`)}
                  >
                    {event.name}
                  </h3>
                  <p className="text-[#888] text-xs tracking-widest mb-4">
                    {event.date
                      ? new Date(event.date).toLocaleDateString()
                      : "No date"}{" "}
                    · {event.location || "No location"}
                  </p>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => navigate(`/event/${event.id}`)}
                      className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-xs font-semibold py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Open
                    </button>
                    <button
                      onClick={() => copyGalleryLink(event)}
                      className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-xs py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Share
                    </button>
                    <button
                      onClick={() => navigate(`/gallery-cover/${event.id}`)}
                      className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-xs py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Cover
                    </button>
                    <button
                      onClick={() => handleDeleteEvent(event.id)}
                      className="border border-[#2a2a2a] hover:border-red-500 text-[#888] hover:text-red-400 text-xs py-2 rounded-xl tracking-widest uppercase transition-all"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1a1a1a] mt-16 px-6 py-6 text-center">
        <p className="text-[#444] text-xs tracking-widest uppercase">
          © 2024 MirrorAI · Luxury Photo Gallery Platform
        </p>
      </footer>
    </div>
  );
};

export default Events;
