import { useState, useEffect, useRef } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import {
  Instagram, Phone, Globe, Check, Upload, Loader2,
  Building2, Sparkles, Palette, Link2, Save, Trash2, Eye
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const ACCENT_SWATCHES = [
  { label: 'Gold',       value: '#C9A96E' },
  { label: 'Dusty Rose', value: '#C4A8A8' },
  { label: 'Sage',       value: '#8FB5A0' },
  { label: 'Steel Blue', value: '#B5C4D1' },
  { label: 'Classic',    value: '#1A1A1A' },
];

// ── Section wrapper ──────────────────────────────────────────
const Section = ({ icon: Icon, title, description, children }: {
  icon: any; title: string; description?: string; children: React.ReactNode;
}) => (
  <div className="bg-card border border-border rounded-lg p-6 space-y-5">
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div>
        <h2 className="font-semibold text-foreground text-[15px]">{title}</h2>
        {description && <p className="text-[12px] text-muted-foreground mt-0.5">{description}</p>}
      </div>
    </div>
    <Separator className="bg-border/50" />
    <div className="space-y-4">{children}</div>
  </div>
);

const Field = ({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) => (
  <div className="space-y-1.5">
    <Label className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</Label>
    {children}
    {hint && <p className="text-[11px] text-muted-foreground/50">{hint}</p>}
  </div>
);

// ────────────────────────────────────────────────────────────
const StudioProfile = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const logoInputRef = useRef<HTMLInputElement>(null);

  const [studioName, setStudioName]   = useState('');
  const [tagline, setTagline]         = useState('');
  const [logoUrl, setLogoUrl]         = useState('');
  const [logoPreview, setLogoPreview] = useState('');
  const [logoFile, setLogoFile]       = useState<File | null>(null);
  const [instagram, setInstagram]     = useState('');
  const [whatsapp, setWhatsapp]       = useState('');
  const [websiteUrl, setWebsiteUrl]   = useState('');
  const [accentColor, setAccentColor] = useState('#C9A96E');
  const [customColor, setCustomColor] = useState('#C9A96E');

  const [loading, setLoading]         = useState(false);
  const [pageLoading, setPageLoading] = useState(true);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  // ── Load ─────────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await (supabase.from('studio_profiles' as any).select('*') as any)
        .eq('user_id', user.id).maybeSingle();

      if (data) {
        setStudioName(data.studio_name ?? '');
        setTagline(data.tagline ?? '');
        setLogoUrl(data.logo_url ?? '');
        setInstagram(data.instagram ?? '');
        setWhatsapp(data.whatsapp ?? '');
        setWebsiteUrl(data.website_url ?? '');
        setAccentColor(data.accent_color ?? '#C9A96E');
        setCustomColor(data.accent_color ?? '#C9A96E');
      } else {
        const { data: p } = await (supabase.from('profiles').select('studio_name') as any)
          .eq('user_id', user.id).single();
        if (p) setStudioName(p.studio_name ?? '');
      }
      setPageLoading(false);
    })();
  }, [user]);

  // ── Logo file pick ────────────────────────────────────────
  const handleLogoFile = (file: File) => {
    setLogoFile(file);
    setLogoPreview(URL.createObjectURL(file));
  };

  // ── Upload logo ───────────────────────────────────────────
  const uploadLogo = async (): Promise<string> => {
    if (!logoFile || !user) return logoUrl;
    setUploadingLogo(true);
    try {
      const ext = logoFile.name.split('.').pop();
      const path = `${user.id}/logo-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from('event-covers').upload(path, logoFile, { upsert: true });
      if (error) throw error;
      const { data: { publicUrl } } = supabase.storage.from('event-covers').getPublicUrl(path);
      return publicUrl;
    } catch (err: any) {
      toast({ title: 'Logo upload failed', description: err.message, variant: 'destructive' });
      return logoUrl;
    } finally {
      setUploadingLogo(false);
    }
  };

  // ── Save ──────────────────────────────────────────────────
  const save = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const finalLogoUrl = logoFile ? await uploadLogo() : logoUrl;

      const payload: any = {
        user_id:      user.id,
        studio_name:  studioName,
        tagline:      tagline || null,
        logo_url:     finalLogoUrl || null,
        instagram:    instagram || null,
        whatsapp:     whatsapp || null,
        website_url:  websiteUrl || null,
        accent_color: accentColor,
        updated_at:   new Date().toISOString(),
      };

      const { error } = await (supabase
        .from('studio_profiles' as any)
        .upsert(payload, { onConflict: 'user_id' }) as any);

      if (error) throw error;

      setLogoUrl(finalLogoUrl);
      setLogoFile(null);
      setLogoPreview('');
      toast({ title: 'Studio profile saved ✓' });
    } catch (err: any) {
      toast({ title: 'Error saving', description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  // ── Loading ───────────────────────────────────────────────
  if (pageLoading) return (
    <DashboardLayout>
      <div className="flex items-center justify-center py-32">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    </DashboardLayout>
  );

  const displayLogo = logoPreview || logoUrl;

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto pb-16">

        {/* Header */}
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-foreground">Studio Profile</h1>
          <p className="text-[13px] text-muted-foreground mt-1">
            Your brand identity shown on Studio-style galleries.
          </p>
        </div>

        {/* Live preview strip */}
        <div
          className="rounded-lg p-5 mb-6 flex items-center gap-4 border"
          style={{ backgroundColor: `${accentColor}12`, borderColor: `${accentColor}30` }}
        >
          <div className="w-12 h-12 rounded-full overflow-hidden bg-muted border border-border flex-shrink-0 flex items-center justify-center">
            {displayLogo
              ? <img src={displayLogo} alt="Logo" className="w-full h-full object-contain p-1" />
              : <Building2 className="h-5 w-5 text-muted-foreground/30" />
            }
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-serif font-semibold text-[15px] text-foreground truncate">
              {studioName || 'Your Studio Name'}
            </p>
            <p className="text-[12px] text-muted-foreground truncate">
              {tagline || 'Your tagline appears here'}
            </p>
          </div>
          <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ backgroundColor: accentColor }} />
        </div>

        <div className="space-y-5">

          {/* ── 1. IDENTITY ──────────────────────────────────── */}
          <Section icon={Building2} title="Studio Identity" description="Name and tagline shown on your galleries">

            {/* Logo */}
            <Field label="Studio Logo">
              <div className="flex items-center gap-4">
                <div className="w-20 h-14 rounded-md border border-border bg-background flex items-center justify-center overflow-hidden flex-shrink-0">
                  {displayLogo
                    ? <img src={displayLogo} alt="Logo" className="w-full h-full object-contain p-1.5" />
                    : <Building2 className="h-5 w-5 text-muted-foreground/20" />
                  }
                </div>
                <div className="space-y-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => logoInputRef.current?.click()}
                    disabled={uploadingLogo}
                    className="h-8 text-[11px] gap-1.5"
                  >
                    {uploadingLogo
                      ? <Loader2 className="h-3 w-3 animate-spin" />
                      : <Upload className="h-3 w-3" />
                    }
                    {displayLogo ? 'Change Logo' : 'Upload Logo'}
                  </Button>
                  {displayLogo && (
                    <button
                      onClick={() => { setLogoUrl(''); setLogoPreview(''); setLogoFile(null); }}
                      className="flex items-center gap-1 text-[11px] text-destructive hover:underline"
                    >
                      <Trash2 className="h-3 w-3" /> Remove
                    </button>
                  )}
                </div>
              </div>
              <input
                ref={logoInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={e => { const f = e.target.files?.[0]; if (f) handleLogoFile(f); }}
              />
              {logoFile && (
                <p className="text-[11px] text-primary">
                  ✓ {logoFile.name} — will upload on save
                </p>
              )}
            </Field>

            <Field label="Studio Name">
              <Input
                value={studioName}
                onChange={e => setStudioName(e.target.value)}
                placeholder="e.g. Sharma Photography"
                className="bg-background"
              />
            </Field><Field label="Tagline" hint="One line shown under your name on galleries">
              <Input
                value={tagline}
                onChange={e => setTagline(e.target.value)}
                placeholder="Capturing moments that matter"
                className="bg-background"
              />
            </Field>
          </Section>

          {/* ── 2. SOCIAL LINKS ──────────────────────────────── */}
          <Section icon={Link2} title="Social Links" description="Shown on your public gallery pages">
            <Field label="Instagram" hint="Without @">
              <div className="relative">
                <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/40" />
                <Input
                  value={instagram}
                  onChange={e => setInstagram(e.target.value)}
                  placeholder="yourstudio"
                  className="bg-background pl-9"
                />
              </div>
            </Field>

            <Field label="WhatsApp" hint="Include country code">
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/40" />
                <Input
                  value={whatsapp}
                  onChange={e => setWhatsapp(e.target.value)}
                  placeholder="+91 9876543210"
                  className="bg-background pl-9"
                />
              </div>
            </Field>

            <Field label="Website">
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/40" />
                <Input
                  value={websiteUrl}
                  onChange={e => setWebsiteUrl(e.target.value)}
                  placeholder="https://yourstudio.com"
                  className="bg-background pl-9"
                />
              </div>
            </Field>
          </Section>

          {/* ── 3. ACCENT COLOR ──────────────────────────────── */}
          <Section icon={Palette} title="Accent Color" description="Used for buttons and highlights on your galleries">

            {/* Swatches */}
            <div className="flex flex-wrap gap-3">
              {ACCENT_SWATCHES.map(s => (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => { setAccentColor(s.value); setCustomColor(s.value); }}
                  className="relative w-10 h-10 rounded-full border-2 transition-all flex items-center justify-center"
                  style={{
                    backgroundColor: s.value,
                    borderColor: accentColor === s.value ? s.value : 'transparent',
                    boxShadow: accentColor === s.value
                      ? `0 0 0 2px hsl(var(--background)), 0 0 0 4px ${s.value}`
                      : 'none',
                  }}
                  title={s.label}
                >
                  {accentColor === s.value && (
                    <Check className="h-4 w-4" style={{ color: s.value === '#1A1A1A' ? '#fff' : '#1A1A1A' }} />
                  )}
                </button>
              ))}

              {/* Custom color */}
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={customColor}
                  onChange={e => { setCustomColor(e.target.value); setAccentColor(e.target.value); }}
                  className="w-10 h-10 rounded-full border border-border cursor-pointer p-0.5 bg-background"
                  title="Custom color"
                />
                <span className="text-[11px] text-muted-foreground font-mono">{accentColor}</span>
              </div>
            </div>

            {/* Preview bar */}
            <div className="flex items-center gap-3 p-3 rounded-md border border-border bg-background">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: accentColor }} />
              <span className="text-[12px] text-muted-foreground">Gallery button preview</span>
              <div
                className="ml-auto px-3 py-1 rounded text-[11px] font-semibold"
                style={{ backgroundColor: accentColor, color: '#fff' }}
              >
                View Gallery
              </div>
            </div>
          </Section>

          {/* ── SAVE ─────────────────────────────────────────── */}
          <Button
            onClick={save}
            disabled={loading}
            className="w-full h-11 text-[12px] uppercase tracking-wider font-bold gap-2"
          >
            {loading
              ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving...</>
              : <><Save className="h-4 w-4" /> Save Studio Profile</>
            }
          </Button></div>
      </div>
    </DashboardLayout>
  );
};

export default StudioProfile;
