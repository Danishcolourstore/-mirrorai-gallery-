import { useState, useEffect, useMemo } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { MyBookInstallPrompt } from '@/components/MyBookInstallPrompt';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Calendar, Plus, ChevronLeft, ChevronRight, MapPin, Clock, Palette, Sparkles, BookOpen, X } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, addMonths, subMonths, isToday, isSameMonth, isSameDay, startOfWeek, endOfWeek, addWeeks, subWeeks, addDays, subDays, isPast, isWeekend, getDaysInMonth } from 'date-fns';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { useIsMobile } from '@/hooks/use-mobile';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarPicker } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';

// Dark theme constants
const DK = {
  pageBg: 'hsl(24, 22%, 9%)',
  cardBg: 'hsl(24, 15%, 15%)',
  calBg: 'hsl(24, 18%, 12%)',
  border: 'hsl(24, 15%, 20%)',
  gold: '#C9A96E',
  white: '#FFFFFF',
  muted: 'hsl(30, 10%, 55%)',
  mutedLight: 'hsl(30, 10%, 45%)',
  greenDot: '#8FB5A0',
};

interface Shoot {
  id: string;
  user_id: string;
  client_name: string;
  shoot_type: string;
  shoot_date: string;
  start_time: string | null;
  end_time: string | null;
  location: string | null;
  map_link: string | null;
  shoot_vibe: string | null;
  shot_list: string | null;
  outfit_props: string | null;
  mood_board_links: string[];
  color_palette: string[];
  reminder_timing: string | null;
  status: string;
  color_tag: string;
  event_id: string | null;
  created_at: string;
  updated_at: string;
}

const SHOOT_TYPES = [
  { label: 'Wedding', emoji: '💍' },
  { label: 'Pre-Wedding', emoji: '💑' },
  { label: 'Maternity', emoji: '👶' },
  { label: 'Family', emoji: '👨‍👩‍👧' },
  { label: 'Birthday', emoji: '🎂' },
  { label: 'Corporate', emoji: '💼' },
  { label: 'Portrait', emoji: '📸' },
  { label: 'Graduation', emoji: '🎓' },
  { label: 'Other', emoji: '✨' },
];

const STATUS_OPTIONS = [
  { label: 'Tentative', value: 'tentative', emoji: '🟡' },
  { label: 'Confirmed', value: 'confirmed', emoji: '🟢' },
  { label: 'Completed', value: 'completed', emoji: '✅' },
  { label: 'Cancelled', value: 'cancelled', emoji: '❌' },
];

const COLOR_TAGS = ['#C9A96E', '#8FB5A0', '#C4A8A8', '#B5C4D1', '#3A3A3A'];

const REMINDER_OPTIONS = [
  { label: 'Same day at 7 AM', value: 'same_day' },
  { label: '1 day before', value: '1_day' },
  { label: '2 days before', value: '2_days' },
  { label: '3 days before', value: '3_days' },
  { label: '1 week before', value: '1_week' },
];

type CalView = 'month' | 'week' | 'day';

const MyBook = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const isMobile = useIsMobile();
  const [shoots, setShoots] = useState<Shoot[]>([]);
  const [view, setView] = useState<CalView>('month');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [addOpen, setAddOpen] = useState(false);
  const [detailShoot, setDetailShoot] = useState<Shoot | null>(null);
  const [showFreeDays, setShowFreeDays] = useState(false);

  // Form state
  const [form, setForm] = useState({
    client_name: '',
    shoot_type: 'Wedding',
    shoot_date: new Date(),
    start_time: '10:00',
    end_time: '18:00',
    location: '',
    map_link: '',
    shoot_vibe: '',
    shot_list: '',
    outfit_props: '',
    reminder_enabled: false,
    reminder_timing: '1_day',
    status: 'confirmed',
    color_tag: '#C9A96E',
  });

  const fetchShoots = async () => {
    if (!user) return;
    const { data } = await (supabase
      .from('shoots' as any)
      .select('*') as any)
      .eq('user_id', user.id)
      .order('shoot_date', { ascending: true });
    if (data) setShoots(data as Shoot[]);
  };

  useEffect(() => { fetchShoots(); }, [user]);

  const resetForm = () => setForm({
    client_name: '', shoot_type: 'Wedding', shoot_date: new Date(),
    start_time: '10:00', end_time: '18:00', location: '', map_link: '',
    shoot_vibe: '', shot_list: '', outfit_props: '',
    reminder_enabled: false, reminder_timing: '1_day',
    status: 'confirmed', color_tag: '#C9A96E',
  });

  const saveShoot = async () => {
    if (!user || !form.client_name.trim()) {
      toast({ title: 'Client name required', variant: 'destructive' });
      return;
    }
    const { error } = await (supabase.from('shoots' as any).insert({
      user_id: user.id,
      client_name: form.client_name,
      shoot_type: form.shoot_type,
      shoot_date: format(form.shoot_date, 'yyyy-MM-dd'),
      start_time: form.start_time,
      end_time: form.end_time,
      location: form.location || null,
      map_link: form.map_link || null,
      shoot_vibe: form.shoot_vibe || null,
      shot_list: form.shot_list || null,
      outfit_props: form.outfit_props || null,
      mood_board_links: [],
      color_palette: [],
      reminder_timing: form.reminder_enabled ? form.reminder_timing : null,
      status: form.status,
      color_tag: form.color_tag,
    }) as any);
    if (error) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Shoot added ✨' });
      setAddOpen(false);
      resetForm();
      fetchShoots();
    }
  };

  const deleteShoot = async (id: string) => {
    await (supabase.from('shoots' as any).delete() as any).eq('id', id);
    setDetailShoot(null);
    fetchShoots();
  };

  // Stats
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const thisMonthShoots = shoots.filter(s => {
    const d = new Date(s.shoot_date);
    return d >= monthStart && d <= monthEnd && s.status !== 'cancelled';
  });
  const upcomingShoots = shoots.filter(s => new Date(s.shoot_date) >= new Date() && s.status !== 'cancelled');
  const daysInMonth = getDaysInMonth(currentDate);
  const shootDatesThisMonth = new Set(thisMonthShoots.map(s => s.shoot_date));
  const freeDays = daysInMonth - shootDatesThisMonth.size;

  const upcomingStrip = upcomingShoots.slice(0, 8);

  const getTypeEmoji = (type: string) => SHOOT_TYPES.find(t => t.label === type)?.emoji || '📸';
  const getStatusEmoji = (status: string) => STATUS_OPTIONS.find(s => s.value === status)?.emoji || '🟢';

  const getShootsForDate = (date: Date) => shoots.filter(s => isSameDay(new Date(s.shoot_date), date));

  const calcDuration = () => {
    if (!form.start_time || !form.end_time) return '';
    const [sh, sm] = form.start_time.split(':').map(Number);
    const [eh, em] = form.end_time.split(':').map(Number);
    const diff = (eh * 60 + em) - (sh * 60 + sm);
    if (diff <= 0) return '';
    const h = Math.floor(diff / 60);
    const m = diff % 60;
    return m > 0 ? `${h}h ${m}m` : `${h} hours`;
  };

  // Dark stat card for this page
  const DarkStatCard = ({ label, value, icon }: { label: string; value: string | number; icon: React.ReactNode }) => (
    <div className="px-5 py-5" style={{ backgroundColor: DK.cardBg }}>
      <div className="flex items-center justify-between mb-2">
        <p className="text-[10px] uppercase tracking-[0.14em] font-semibold font-sans" style={{ color: DK.muted }}>{label}</p>
        <span style={{ color: DK.mutedLight }}>{icon}</span>
      </div>
      <p className="font-serif text-[32px] font-semibold leading-none tracking-tight" style={{ color: DK.gold }}>{value}</p>
    </div>
  );

  // Month view
  const renderMonth = () => {
    const start = startOfWeek(monthStart, { weekStartsOn: 1 });
    const end = endOfWeek(monthEnd, { weekStartsOn: 1 });
    const days = eachDayOfInterval({ start, end });
    const dayHeaders = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

    return (
      <div style={{ backgroundColor: DK.calBg, borderRadius: 6 }} className="overflow-hidden">
        <div className="grid grid-cols-7">
          {dayHeaders.map(d => (
            <div key={d} className="py-2 text-center text-[9px] font-sans uppercase tracking-[0.15em]" style={{ color: DK.muted }}>{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7" style={{ borderTop: `1px solid ${DK.border}` }}>
          {days.map(day => {
            const dayDateStr = format(day, 'yyyy-MM-dd');
            const dayShoots = getShootsForDate(day);
            const inMonth = isSameMonth(day, currentDate);
            const today = isToday(day);
            const past = isPast(day) && !today;
            const isFree = inMonth && dayShoots.length === 0 && !past;

            return (
              <div
                key={dayDateStr}
                className={cn(
                  'min-h-[56px] sm:min-h-[80px] p-1 sm:p-1.5 transition-colors cursor-pointer',
                  !inMonth && 'opacity-25',
                  past && inMonth && 'opacity-40',
                )}
                style={{
                  borderRight: `1px solid ${DK.border}`,
                  borderBottom: `1px solid ${DK.border}`,
                  backgroundColor: showFreeDays && isFree ? 'rgba(143,181,160,0.08)' : 'transparent',
                }}
                onClick={() => { setCurrentDate(day); setView('day'); }}
              >
                <div className="flex flex-col items-center">
                  <span className={cn(
                    'text-[13px] font-sans inline-flex items-center justify-center',
                    today && 'rounded-full w-6 h-6',
                  )}
                  style={{
                    backgroundColor: today ? DK.gold : 'transparent',
                    color: today ? DK.pageBg : DK.white,
                    fontWeight: today ? 700 : 400,
                  }}>
                    {format(day, 'd')}
                  </span>
                  {/* Dots below number */}
                  {dayShoots.length > 0 && (
                    <span className="w-1 h-1 rounded-full mt-0.5" style={{ backgroundColor: DK.gold }} />
                  )}
                  {showFreeDays && isFree && (
                    <span className="w-1 h-1 rounded-full mt-0.5" style={{ backgroundColor: DK.greenDot }} />
                  )}
                </div>
                <div className="mt-0.5 space-y-0.5">
                  {dayShoots.slice(0, 2).map(s => (
                    <div
                      key={s.id}
                      className="truncate rounded px-1 py-0.5 text-[9px] sm:text-[10px] font-sans text-white font-medium"
                      style={{ backgroundColor: s.color_tag }}
                      onClick={(e) => { e.stopPropagation(); setDetailShoot(s); }}
                    >
                      {getTypeEmoji(s.shoot_type)} {s.client_name}
                    </div>
                  ))}
                  {dayShoots.length > 2 && (
                    <div className="text-[9px] font-sans" style={{ color: DK.muted }}>+{dayShoots.length - 2} more</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Week view
  const renderWeek = () => {
    const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
    const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
    const hours = Array.from({ length: 18 }, (_, i) => i + 6);

    return (
      <div className="overflow-x-auto" style={{ backgroundColor: DK.calBg, borderRadius: 6 }}>
        <div className="grid grid-cols-[50px_repeat(7,1fr)] min-w-[700px]">
          <div style={{ borderBottom: `1px solid ${DK.border}` }} />
          {days.map(day => (
            <div key={day.toString()} className="text-center py-2 text-[11px] font-sans"
              style={{
                borderBottom: `1px solid ${DK.border}`,
                borderLeft: `1px solid ${DK.border}`,
                backgroundColor: isToday(day) ? 'rgba(201,169,110,0.08)' : 'transparent',
              }}>
              <div className="text-[9px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>{format(day, 'EEE')}</div>
              <div className={cn('text-[15px] font-serif mt-0.5')} style={{ color: isToday(day) ? DK.gold : DK.white, fontWeight: isToday(day) ? 600 : 400 }}>{format(day, 'd')}</div>
            </div>
          ))}
          {hours.map(hour => (
            <>
              <div key={`h-${hour}`} className="text-[10px] font-sans pr-2 text-right py-2" style={{ color: DK.mutedLight, borderBottom: `1px solid ${DK.border}` }}>
                {hour > 12 ? `${hour - 12} PM` : hour === 12 ? '12 PM' : `${hour} AM`}
              </div>
              {days.map(day => {
                const dayShoots = getShootsForDate(day).filter(s => {
                  if (!s.start_time) return hour === 10;
                  const sh = parseInt(s.start_time.split(':')[0]);
                  return sh === hour;
                });
                return (
                  <div key={`${day}-${hour}`} className="min-h-[40px] p-0.5"
                    style={{
                      borderLeft: `1px solid ${DK.border}`,
                      borderBottom: `1px solid ${DK.border}`,
                      backgroundColor: isToday(day) ? 'rgba(201,169,110,0.03)' : 'transparent',
                    }}>
                    {dayShoots.map(s => (
                      <div
                        key={s.id}
                        className="rounded px-1.5 py-1 text-[10px] text-white font-sans cursor-pointer truncate"
                        style={{ backgroundColor: s.color_tag }}
                        onClick={() => setDetailShoot(s)}
                      >
                        <span className="font-medium">{s.client_name}</span>
                        {s.start_time && <span className="ml-1 opacity-70">{s.start_time}</span>}
                      </div>
                    ))}
                  </div>
                );
              })}
            </>
          ))}
        </div>
      </div>
    );
  };

  // Day view
  const renderDay = () => {
    const dayShoots = getShootsForDate(currentDate);
    const hours = Array.from({ length: 18 }, (_, i) => i + 6);

    return (
      <div>
        <div className="mb-6">
          <h3 className="font-serif italic text-[36px] font-light tracking-tight" style={{ color: DK.white }}>{format(currentDate, 'EEEE')}</h3>
          <p className="text-[13px] font-sans" style={{ color: DK.muted }}>{format(currentDate, 'd MMMM yyyy')}</p>
        </div>
        <div className="space-y-0">
          {hours.map(hour => {
            const hourShoots = dayShoots.filter(s => {
              if (!s.start_time) return hour === 10;
              return parseInt(s.start_time.split(':')[0]) === hour;
            });
            return (
              <div key={hour} className="flex" style={{ borderBottom: `1px solid ${DK.border}` }}>
                <div className="w-[60px] py-3 text-[11px] font-sans text-right pr-3 flex-shrink-0" style={{ color: DK.mutedLight }}>
                  {hour > 12 ? `${hour - 12} PM` : hour === 12 ? '12 PM' : `${hour} AM`}
                </div>
                <div className="flex-1 py-2 pl-3 min-h-[44px]">
                  {hourShoots.length > 0 ? hourShoots.map(s => (
                    <div
                      key={s.id}
                      className="rounded p-3 cursor-pointer hover:brightness-110 transition-all mb-1"
                      style={{ backgroundColor: DK.cardBg, borderLeft: `3px solid ${s.color_tag}` }}
                      onClick={() => setDetailShoot(s)}
                    >
                      <div className="font-sans text-[13px] font-medium" style={{ color: DK.white }}>{s.client_name}</div>
                      <div className="text-[10px] font-sans mt-0.5" style={{ color: DK.muted }}>
                        {getTypeEmoji(s.shoot_type)} {s.shoot_type}
                        {s.start_time && s.end_time && <span className="ml-2">{s.start_time} → {s.end_time}</span>}
                      </div>
                      {s.location && <div className="text-[10px] font-sans mt-0.5" style={{ color: DK.muted }}>📍 {s.location}</div>}
                      {s.shoot_vibe && <div className="text-[10px] font-sans italic mt-0.5" style={{ color: DK.mutedLight }}>🎨 {s.shoot_vibe}</div>}
                    </div>
                  )) : (
                    <span className="text-[11px] italic font-sans" style={{ color: DK.mutedLight }}>Available</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Navigate
  const navigate = (dir: 1 | -1) => {
    if (view === 'month') setCurrentDate(dir === 1 ? addMonths(currentDate, 1) : subMonths(currentDate, 1));
    else if (view === 'week') setCurrentDate(dir === 1 ? addWeeks(currentDate, 1) : subWeeks(currentDate, 1));
    else setCurrentDate(dir === 1 ? addDays(currentDate, 1) : subDays(currentDate, 1));
  };

  const formContent = (
    <ScrollArea className="max-h-[75vh]">
      <div className="space-y-6 p-1">
        {/* Client */}
        <div>
          <div className="text-[9px] font-sans uppercase tracking-[0.2em] mb-3 pb-1" style={{ color: DK.muted, borderBottom: `1px solid ${DK.border}` }}>Client</div>
          <div className="space-y-3">
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Client Name *</Label>
              <Input value={form.client_name} onChange={e => setForm(p => ({ ...p, client_name: e.target.value }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" placeholder="e.g. Sharma & Priya" />
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em] mb-2 block" style={{ color: DK.muted }}>Shoot Type *</Label>
              <div className="flex flex-wrap gap-1.5">
                {SHOOT_TYPES.map(t => (
                  <button
                    key={t.label}
                    onClick={() => setForm(p => ({ ...p, shoot_type: t.label }))}
                    className={cn(
                      'px-3 py-1.5 rounded-full text-[11px] font-sans border transition-colors',
                      form.shoot_type === t.label
                        ? 'text-white'
                        : 'hover:border-[#C9A96E80]'
                    )}
                    style={{
                      backgroundColor: form.shoot_type === t.label ? DK.gold : 'transparent',
                      borderColor: form.shoot_type === t.label ? DK.gold : DK.border,
                      color: form.shoot_type === t.label ? DK.white : DK.muted,
                    }}
                  >
                    {t.emoji} {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Schedule */}
        <div>
          <div className="text-[9px] font-sans uppercase tracking-[0.2em] mb-3 pb-1" style={{ color: DK.muted, borderBottom: `1px solid ${DK.border}` }}>Schedule</div>
          <div className="space-y-3">
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full mt-1 justify-start text-left font-normal text-[13px] bg-transparent border-[hsl(24,15%,25%)] text-white">
                    <Calendar className="mr-2 h-4 w-4" style={{ color: DK.gold }} />
                    {format(form.shoot_date, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarPicker mode="single" selected={form.shoot_date} onSelect={d => d && setForm(p => ({ ...p, shoot_date: d }))} className="p-3 pointer-events-auto" />
                </PopoverContent>
              </Popover>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Start Time</Label>
                <Input type="time" value={form.start_time} onChange={e => setForm(p => ({ ...p, start_time: e.target.value }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" />
              </div>
              <div>
                <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>End Time</Label>
                <Input type="time" value={form.end_time} onChange={e => setForm(p => ({ ...p, end_time: e.target.value }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" />
              </div>
            </div>
            {calcDuration() && <p className="text-[11px] font-sans" style={{ color: DK.muted }}>{calcDuration()}</p>}
          </div>
        </div>

        {/* Location */}
        <div>
          <div className="text-[9px] font-sans uppercase tracking-[0.2em] mb-3 pb-1" style={{ color: DK.muted, borderBottom: `1px solid ${DK.border}` }}>Location</div>
          <div className="space-y-3">
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Location</Label>
              <div className="relative mt-1">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5" style={{ color: DK.muted }} />
                <Input value={form.location} onChange={e => setForm(p => ({ ...p, location: e.target.value }))} className="pl-9 bg-transparent border-[hsl(24,15%,25%)] text-white" placeholder="e.g. Taj Hotel, Mumbai" />
              </div>
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Map Link (optional)</Label>
              <Input value={form.map_link} onChange={e => setForm(p => ({ ...p, map_link: e.target.value }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" placeholder="Google Maps link" />
            </div>
          </div>
        </div>

        {/* Creative Notes */}
        <div>
          <div className="text-[9px] font-sans uppercase tracking-[0.2em] mb-3 pb-1" style={{ color: DK.muted, borderBottom: `1px solid ${DK.border}` }}>Creative Notes</div>
          <div className="space-y-3">
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Shoot Vibe / Mood</Label>
              <Input value={form.shoot_vibe} onChange={e => setForm(p => ({ ...p, shoot_vibe: e.target.value }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" placeholder="e.g. Golden hour, romantic, candid, moody" />
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Shot List / Ideas</Label>
              <Textarea value={form.shot_list} onChange={e => setForm(p => ({ ...p, shot_list: e.target.value.slice(0, 500) }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" rows={4} placeholder="Notes to self, must-have shots, creative ideas..." />
              <p className="text-[9px] font-sans mt-1 text-right" style={{ color: DK.mutedLight }}>{form.shot_list.length}/500</p>
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em]" style={{ color: DK.muted }}>Outfit / Props Notes</Label>
              <Input value={form.outfit_props} onChange={e => setForm(p => ({ ...p, outfit_props: e.target.value }))} className="mt-1 bg-transparent border-[hsl(24,15%,25%)] text-white" placeholder="e.g. White lehenga, family in pastels" />
            </div>
          </div>
        </div>

        {/* Reminder */}
        <div>
          <div className="text-[9px] font-sans uppercase tracking-[0.2em] mb-3 pb-1" style={{ color: DK.muted, borderBottom: `1px solid ${DK.border}` }}>Reminder</div>
          <div className="flex items-center justify-between">
            <Label className="text-[12px] font-sans" style={{ color: DK.white }}>Set reminder</Label>
            <Switch checked={form.reminder_enabled} onCheckedChange={v => setForm(p => ({ ...p, reminder_enabled: v }))} />
          </div>
          {form.reminder_enabled && (
            <Select value={form.reminder_timing} onValueChange={v => setForm(p => ({ ...p, reminder_timing: v }))}>
              <SelectTrigger className="mt-2 bg-transparent border-[hsl(24,15%,25%)] text-white"><SelectValue /></SelectTrigger>
              <SelectContent>
                {REMINDER_OPTIONS.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Status & Color */}
        <div>
          <div className="text-[9px] font-sans uppercase tracking-[0.2em] mb-3 pb-1" style={{ color: DK.muted, borderBottom: `1px solid ${DK.border}` }}>Status & Color</div>
          <div className="space-y-3">
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em] mb-2 block" style={{ color: DK.muted }}>Status</Label>
              <div className="flex gap-1.5">
                {STATUS_OPTIONS.map(s => (
                  <button
                    key={s.value}
                    onClick={() => setForm(p => ({ ...p, status: s.value }))}
                    className="px-3 py-1.5 rounded-full text-[11px] font-sans border transition-colors"
                    style={{
                      backgroundColor: form.status === s.value ? DK.white : 'transparent',
                      borderColor: form.status === s.value ? DK.white : DK.border,
                      color: form.status === s.value ? DK.pageBg : DK.muted,
                    }}
                  >
                    {s.emoji} {s.label}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <Label className="text-[10px] uppercase tracking-[0.15em] mb-2 block" style={{ color: DK.muted }}>Color Tag</Label>
              <div className="flex gap-2">
                {COLOR_TAGS.map(c => (
                  <button
                    key={c}
                    onClick={() => setForm(p => ({ ...p, color_tag: c }))}
                    className={cn('w-7 h-7 rounded-full border-2 transition-transform', form.color_tag === c ? 'scale-110' : '')}
                    style={{ backgroundColor: c, borderColor: form.color_tag === c ? DK.white : 'transparent' }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>

        <Button onClick={saveShoot} className="w-full font-sans text-[13px] tracking-[0.1em] font-medium py-6"
          style={{ backgroundColor: DK.gold, color: DK.pageBg }}>
          Save Shoot
        </Button>
      </div>
    </ScrollArea>
  );

  // Shoot detail
  const detailContent = detailShoot && (
    <ScrollArea className="max-h-[75vh]">
      <div className="space-y-5 p-1">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-sans uppercase tracking-[0.15em]" style={{ color: DK.muted }}>{getTypeEmoji(detailShoot.shoot_type)} {detailShoot.shoot_type}</span>
          <span className="text-[11px] font-sans px-2.5 py-0.5 rounded-full border" style={{ borderColor: detailShoot.color_tag, color: detailShoot.color_tag }}>
            {getStatusEmoji(detailShoot.status)} {detailShoot.status}
          </span>
        </div>

        <h3 className="font-serif italic text-[32px] font-light tracking-tight leading-tight" style={{ color: DK.white }}>{detailShoot.client_name}</h3>

        <div className="space-y-3 text-[13px] font-sans" style={{ color: DK.white }}>
          <div className="flex gap-2"><span>📅</span><span>{format(new Date(detailShoot.shoot_date), 'EEEE, d MMMM yyyy')}</span></div>
          {detailShoot.start_time && detailShoot.end_time && (
            <div className="flex gap-2"><span>⏰</span><span>{detailShoot.start_time} → {detailShoot.end_time}</span></div>
          )}
          {detailShoot.location && (
            <div className="flex gap-2">
              <span>📍</span>
              <div>
                <span>{detailShoot.location}</span>
                {detailShoot.map_link && (
                  <a href={detailShoot.map_link} target="_blank" rel="noopener noreferrer" className="ml-2 text-[11px] hover:underline" style={{ color: DK.gold }}>Open in Maps →</a>
                )}
              </div>
            </div>
          )}
          {detailShoot.shoot_vibe && <div className="flex gap-2"><span>🎨</span><span className="italic" style={{ color: DK.muted }}>{detailShoot.shoot_vibe}</span></div>}
          {detailShoot.shot_list && (
            <div className="flex gap-2">
              <span>📝</span>
              <p className="font-serif italic whitespace-pre-wrap" style={{ color: DK.muted }}>{detailShoot.shot_list}</p>
            </div>
          )}
          {detailShoot.outfit_props && <div className="flex gap-2"><span>👗</span><span style={{ color: DK.muted }}>{detailShoot.outfit_props}</span></div>}
          {detailShoot.reminder_timing && <div className="flex gap-2"><span>🔔</span><span style={{ color: DK.muted }}>{REMINDER_OPTIONS.find(r => r.value === detailShoot.reminder_timing)?.label}</span></div>}
        </div>

        <div className="pt-3" style={{ borderTop: `1px solid ${DK.border}` }}>
          <Button variant="ghost" className="w-full text-destructive text-[12px]" onClick={() => deleteShoot(detailShoot.id)}>
            Delete Shoot
          </Button>
        </div>
      </div>
    </ScrollArea>
  );

  return (
    <DashboardLayout>
      <div className="-mx-4 sm:-mx-6 lg:-mx-8 -mt-4 sm:-mt-6 px-4 sm:px-6 lg:px-8 pt-4 sm:pt-6 pb-8 min-h-[calc(100vh-64px)]" style={{ backgroundColor: DK.pageBg }}>
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="font-display italic text-[40px] font-semibold tracking-tight leading-none" style={{ color: DK.white, fontFamily: "'Playfair Display', serif" }}>My Book</h1>
            <div className="w-12 h-[1.5px] mt-2 mb-2" style={{ backgroundColor: DK.gold }} />
            <p className="text-[12px] uppercase tracking-[0.2em] font-sans font-medium" style={{ color: DK.muted }}>Every shoot. Every story.</p>
          </div>
          <Button onClick={() => { resetForm(); setAddOpen(true); }} className="font-sans text-[12px] tracking-[0.1em] font-medium h-9 px-4"
            style={{ backgroundColor: DK.gold, color: DK.pageBg }}>
            <Plus className="mr-1 h-3.5 w-3.5" /> Add Shoot
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 overflow-hidden mb-6 rounded-md" style={{ border: `1px solid ${DK.border}` }}>
          <DarkStatCard label="This Month" value={thisMonthShoots.length} icon={<Calendar className="h-4 w-4" />} />
          <div style={{ borderLeft: `1px solid ${DK.border}` }}>
            <DarkStatCard label="Upcoming" value={upcomingShoots.length} icon={<Clock className="h-4 w-4" />} />
          </div>
          <div style={{ borderLeft: `1px solid ${DK.border}` }}>
            <DarkStatCard label="Free Days" value={freeDays} icon={<Sparkles className="h-4 w-4" />} />
          </div>
        </div>

        {/* Upcoming strip */}
        {upcomingStrip.length > 0 && (
          <div className="mb-6">
            <p className="text-[10px] font-sans uppercase tracking-[0.15em] mb-2" style={{ color: DK.muted }}>Coming up</p>
            <div className="flex gap-2.5 overflow-x-auto pb-2 snap-x snap-mandatory scrollbar-hide">
              {upcomingStrip.map(s => (
                <div
                  key={s.id}
                  className="flex-shrink-0 w-[200px] snap-start rounded p-3 cursor-pointer hover:brightness-110 transition-all"
                  style={{ backgroundColor: DK.cardBg, borderLeft: `3px solid ${s.color_tag}` }}
                  onClick={() => setDetailShoot(s)}
                >
                  <div className="text-[10px] font-sans" style={{ color: DK.muted }}>{getTypeEmoji(s.shoot_type)}</div>
                  <div className="text-[13px] font-sans font-medium mt-0.5 truncate" style={{ color: DK.white }}>{s.client_name}</div>
                  <div className="text-[10px] font-sans mt-0.5" style={{ color: DK.muted }}>
                    {format(new Date(s.shoot_date), 'EEE, d MMM')} {s.start_time && `· ${s.start_time}`}
                  </div>
                  {s.location && <div className="text-[10px] font-sans mt-0.5 truncate" style={{ color: DK.mutedLight }}>📍 {s.location}</div>}
                  {s.shoot_vibe && <div className="text-[10px] font-sans italic mt-0.5 truncate" style={{ color: DK.mutedLight }}>🎨 {s.shoot_vibe}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Calendar nav + view toggle */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="p-1 transition-colors" style={{ color: DK.gold }}>
              <ChevronLeft className="h-4 w-4" />
            </button>
            <h2 className="font-serif italic text-[20px] sm:text-[24px] font-semibold tracking-tight min-w-[180px] text-center" style={{ color: DK.white }}>
              {view === 'month' && format(currentDate, 'MMMM yyyy')}
              {view === 'week' && `Week of ${format(startOfWeek(currentDate, { weekStartsOn: 1 }), 'd MMM')}`}
              {view === 'day' && format(currentDate, 'd MMMM yyyy')}
            </h2>
            <button onClick={() => navigate(1)} className="p-1 transition-colors" style={{ color: DK.gold }}>
              <ChevronRight className="h-4 w-4" />
            </button>
            <button onClick={() => setCurrentDate(new Date())} className="text-[10px] font-sans px-2.5 py-1 rounded-full border transition-colors"
              style={{ borderColor: DK.gold, color: DK.gold }}>Today</button>
          </div>
          <div className="flex gap-0.5">
            {(['month', 'week', 'day'] as CalView[]).map(v => (
              <button
                key={v}
                onClick={() => setView(v)}
                className="px-3 py-1.5 text-[11px] font-sans capitalize rounded transition-colors"
                style={{
                  backgroundColor: view === v ? DK.gold : 'transparent',
                  color: view === v ? DK.pageBg : DK.muted,
                  border: view === v ? 'none' : `1px solid ${DK.border}`,
                }}
              >
                {v}
              </button>
            ))}
          </div>
        </div>

        {/* Free days toggle */}
        <div className="flex items-center gap-3 mb-4">
          <button
            onClick={() => setShowFreeDays(!showFreeDays)}
            className="text-[11px] font-sans px-3 py-1 rounded-full border transition-colors"
            style={{
              borderColor: showFreeDays ? DK.gold : DK.border,
              color: showFreeDays ? DK.gold : DK.muted,
              backgroundColor: showFreeDays ? 'rgba(201,169,110,0.1)' : 'transparent',
            }}
          >
            Show free days
          </button>
          {showFreeDays && <span className="text-[11px] font-sans" style={{ color: DK.muted }}>{freeDays} free days this month</span>}
        </div>

        {/* Calendar */}
        {view === 'month' && renderMonth()}
        {view === 'week' && renderWeek()}
        {view === 'day' && renderDay()}

        {/* Empty state */}
        {shoots.length === 0 && (
          <div className="text-center py-20">
            <BookOpen className="mx-auto h-12 w-12 mb-4" style={{ color: DK.gold, opacity: 0.5 }} />
            <h3 className="font-serif italic text-[24px] font-semibold" style={{ color: DK.white }}>Your book is empty.</h3>
            <p className="text-[13px] font-sans mt-2 max-w-[260px] mx-auto" style={{ color: DK.muted }}>
              Every great photographer has a book. Start filling yours.
            </p>
            <Button onClick={() => { resetForm(); setAddOpen(true); }} className="mt-6 font-sans text-[12px] tracking-[0.1em] font-medium"
              style={{ backgroundColor: DK.gold, color: DK.pageBg }}>
              Add Your First Shoot →
            </Button>
          </div>
        )}
      </div>

      {/* Add shoot modal/sheet */}
      {isMobile ? (
        <Sheet open={addOpen} onOpenChange={setAddOpen}>
          <SheetContent side="bottom" className="h-[90vh] rounded-t-2xl" style={{ backgroundColor: DK.pageBg, borderColor: DK.border }}>
            <SheetHeader>
              <SheetTitle className="font-serif italic text-[26px] font-light" style={{ color: DK.white }}>New Shoot</SheetTitle>
            </SheetHeader>
            {formContent}
          </SheetContent>
        </Sheet>
      ) : (
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent className="max-w-[480px]" style={{ backgroundColor: DK.pageBg, borderColor: DK.border }}>
            <DialogHeader>
              <DialogTitle className="font-serif italic text-[26px] font-light" style={{ color: DK.white }}>New Shoot</DialogTitle>
            </DialogHeader>
            {formContent}
          </DialogContent>
        </Dialog>
      )}

      {/* Shoot detail modal/sheet */}
      {isMobile ? (
        <Sheet open={!!detailShoot} onOpenChange={() => setDetailShoot(null)}>
          <SheetContent side="bottom" className="h-auto max-h-[85vh] rounded-t-2xl" style={{ backgroundColor: DK.pageBg, borderColor: DK.border }}>
            <SheetHeader>
              <SheetTitle className="sr-only">Shoot Details</SheetTitle>
            </SheetHeader>
            {detailContent}
          </SheetContent>
        </Sheet>
      ) : (
        <Dialog open={!!detailShoot} onOpenChange={() => setDetailShoot(null)}>
          <DialogContent className="max-w-[480px]" style={{ backgroundColor: DK.pageBg, borderColor: DK.border }}>
            <DialogHeader>
              <DialogTitle className="sr-only">Shoot Details</DialogTitle>
            </DialogHeader>
            {detailContent}
          </DialogContent>
        </Dialog>
      )}

      <MyBookInstallPrompt />
    </DashboardLayout>
  );
};

export default MyBook;
