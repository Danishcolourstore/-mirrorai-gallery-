import { Check, X, Crown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { usePlan } from '@/hooks/use-plan';
import { useRazorpay } from '@/hooks/use-razorpay';

const features = [
  { name: 'Events', free: '3', pro: 'Unlimited' },
  { name: 'Storage', free: '5 GB', pro: '500 GB' },
  { name: 'Gallery Styles', free: 'Standard only', pro: 'Standard + Studio' },
  { name: 'MirrorAI Watermark', free: true, pro: false, invertIcon: true },
  { name: 'Studio Branding', free: false, pro: true },
  { name: 'Analytics', free: false, pro: true },
  { name: 'Email Collection', free: false, pro: true },
  { name: 'Photo Selection Mode', free: false, pro: true },
  { name: 'Support', free: 'Basic', pro: 'Priority' },
];

const Pricing = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isPro } = usePlan();
  const { openCheckout } = useRazorpay();

  const handleFreeCTA = () => {
    if (user) navigate('/dashboard');
    else navigate('/register');
  };

  const handleProCTA = () => {
    if (!user) { navigate('/register'); return; }
    if (isPro) { navigate('/dashboard'); return; }
    openCheckout();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="text-center pt-16 pb-12 px-4">
        <h1 className="font-serif text-4xl md:text-5xl font-semibold text-foreground tracking-tight">
          Simple, Transparent Pricing
        </h1>
        <p className="mt-3 text-muted-foreground text-[15px] max-w-md mx-auto">
          Start free, upgrade when you're ready. No hidden fees.
        </p>
      </div>

      {/* Cards */}
      <div className="max-w-4xl mx-auto px-4 pb-20 grid md:grid-cols-2 gap-6">
        {/* Free Card */}
        <div className="border border-border rounded-xl p-8 bg-card flex flex-col">
          <h2 className="font-serif text-2xl font-semibold text-foreground">Free</h2>
          <div className="mt-4 mb-1">
            <span className="font-serif text-4xl font-bold text-foreground">₹0</span>
          </div>
          <p className="text-[13px] text-muted-foreground mb-8">Forever free</p>

          <div className="space-y-3 flex-1">
            {features.map((f) => {
              const value = f.free;
              const isCheck = typeof value === 'boolean';
              const show = isCheck ? (f.invertIcon ? value : value) : true;
              return (
                <div key={f.name} className="flex items-center gap-2.5 text-[13px]">
                  {isCheck ? (
                    f.invertIcon ? (
                      value ? <Check className="h-4 w-4 text-muted-foreground shrink-0" /> : <X className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                    ) : (
                      value ? <Check className="h-4 w-4 text-primary shrink-0" /> : <X className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                    )
                  ) : (
                    <Check className="h-4 w-4 text-primary shrink-0" />
                  )}
                  <span className={!show && isCheck ? 'text-muted-foreground/50' : 'text-foreground'}>
                    {f.name}{typeof value === 'string' ? `: ${value}` : ''}
                  </span>
                </div>
              );
            })}
          </div>

          <Button
            variant="outline"
            className="w-full mt-8 h-11 text-[13px] font-medium"
            onClick={handleFreeCTA}
          >
            {user ? 'Go to Dashboard' : 'Get Started Free'}
          </Button>
        </div>

        {/* Pro Card */}
        <div className="border-2 border-primary rounded-xl p-8 bg-card flex flex-col relative">
          <div className="absolute -top-3 right-6 bg-primary text-primary-foreground text-[10px] uppercase tracking-[0.15em] font-semibold px-3 py-1 rounded-full flex items-center gap-1">
            <Crown className="h-3 w-3" />
            Most Popular
          </div>

          <h2 className="font-serif text-2xl font-semibold text-foreground">Pro</h2>
          <div className="mt-4 mb-1 flex items-baseline gap-1.5">
            <span className="font-serif text-4xl font-bold text-foreground">₹3,750</span>
            <span className="text-[13px] text-muted-foreground">/year</span>
          </div>
          <p className="text-[13px] text-primary font-medium mb-8">Just ₹312/month</p>

          <div className="space-y-3 flex-1">
            {features.map((f) => {
              const value = f.pro;
              const isCheck = typeof value === 'boolean';
              return (
                <div key={f.name} className="flex items-center gap-2.5 text-[13px]">
                  {isCheck ? (
                    f.invertIcon ? (
                      !value ? <Check className="h-4 w-4 text-primary shrink-0" /> : <X className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                    ) : (
                      value ? <Check className="h-4 w-4 text-primary shrink-0" /> : <X className="h-4 w-4 text-muted-foreground/40 shrink-0" />
                    )
                  ) : (
                    <Check className="h-4 w-4 text-primary shrink-0" />
                  )}
                  <span className="text-foreground">
                    {f.name}{typeof value === 'string' ? `: ${value}` : ''}
                  </span>
                </div>
              );
            })}
          </div>

          <Button
            className="w-full mt-8 h-11 text-[13px] font-medium tracking-wide"
            onClick={handleProCTA}
          >
            {isPro ? 'You\'re on Pro ✦' : 'Go Pro Now'}
          </Button>

          <p className="text-center text-[11px] text-muted-foreground mt-3">
            30-day money-back guarantee · Cancel anytime
          </p>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
