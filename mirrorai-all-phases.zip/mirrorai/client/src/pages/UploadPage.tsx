import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const UploadPage = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [events, setEvents] = useState<any[]>([]);
  const [selectedEvent, setSelectedEvent] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [previews, setPreviews] = useState<string[]>([]);

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchEvents();
  }, [session]);

  const fetchEvents = async () => {
    try {
      const { data } = await supabase
        .from("events")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false });
      if (data) setEvents(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(e.target.files || []);
    setFiles(selected);
    setSuccess("");
    setError("");

    // Generate previews
    const urls = selected.map((file) => URL.createObjectURL(file));
    setPreviews(urls);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer.files).filter((f) =>
      f.type.startsWith("image/")
    );
    setFiles(dropped);
    setSuccess("");
    setError("");
    const urls = dropped.map((file) => URL.createObjectURL(file));
    setPreviews(urls);
  };

  const handleUpload = async () => {
    if (!selectedEvent) {
      setError("Please select an event first.");
      return;
    }
    if (files.length === 0) {
      setError("Please select photos to upload.");
      return;
    }

    setUploading(true);
    setError("");
    setSuccess("");
    setProgress(0);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileExt = file.name.split(".").pop();
        const fileName = `${session.user.id}/${selectedEvent}/${Date.now()}-${i}.${fileExt}`;

        const { error: uploadError } = await supabase.storage
          .from("photos")
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from("photos")
          .getPublicUrl(fileName);

        await supabase.from("photos").insert({
          event_id: selectedEvent,
          user_id: session.user.id,
          url: urlData.publicUrl,
          filename: file.name,
        });

        setProgress(Math.round(((i + 1) / files.length) * 100));
      }

      setSuccess(`${files.length} photo(s) uploaded successfully!`);
      setFiles([]);
      setPreviews([]);
      setProgress(0);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const removeFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index);
    const newPreviews = previews.filter((_, i) => i !== index);
    setFiles(newFiles);
    setPreviews(newPreviews);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between">
        <button
          onClick={() => navigate("/dashboard")}
          className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
        >
          ← Dashboard
        </button>
        <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
          Upload Photos
        </h1>
        <div className="w-24" />
      </header>

      <main className="max-w-3xl mx-auto px-6 py-10">

        {/* Select Event */}
        <div className="mb-8">
          <label className="text-[#888] text-xs tracking-widest uppercase block mb-3">
            Select Event
          </label>
          <select
            value={selectedEvent}
            onChange={(e) => setSelectedEvent(e.target.value)}
            className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#c9a96e] transition-all"
          >
            <option value="">Choose an event...</option>
            {events.map((event) => (
              <option key={event.id} value={event.id}>
                {event.name}
              </option>
            ))}
          </select>
          {events.length === 0 && (
            <p className="text-[#555] text-xs mt-2 tracking-widest">
              No events found.{" "}
              <button
                onClick={() => navigate("/events")}
                className="text-[#c9a96e] underline"
              >
                Create one first
              </button>
            </p>
          )}
        </div>

        {/* Drop Zone */}
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="border-2 border-dashed border-[#2a2a2a] hover:border-[#c9a96e] rounded-2xl p-12 text-center transition-all mb-8 cursor-pointer"
          onClick={() => document.getElementById("fileInput")?.click()}
        >
          <div className="text-5xl mb-4">📸</div>
          <p className="text-white text-lg font-serif mb-2">
            Drop photos here
          </p>
          <p className="text-[#888] text-sm tracking-widest uppercase mb-4">
            or click to browse
          </p>
          <span className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-2 rounded-xl tracking-widest uppercase transition-all">
            Browse Files
          </span>
          <input
            id="fileInput"
            type="file"
            multiple
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>

        {/* Previews */}
        {previews.length > 0 && (
          <div className="mb-8">
            <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
              {files.length} photo(s) selected
            </p>
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
              {previews.map((url, index) => (
                <div
                  key={index}
                  className="relative aspect-square rounded-xl overflow-hidden group"
                >
                  <img
                    src={url}
                    alt={`preview-${index}`}
                    className="w-full h-full object-cover"
                  />
                  <button
                    onClick={() => removeFile(index)}
                    className="absolute top-1 right-1 bg-black/70 hover:bg-red-900/80 text-white text-xs w-6 h-6 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Progress Bar */}
        {uploading && (
          <div className="mb-6">
            <div className="flex justify-between text-xs text-[#888] tracking-widest uppercase mb-2">
              <span>Uploading...</span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-[#1a1a1a] rounded-full h-2">
              <div
                className="bg-[#c9a96e] h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Error & Success */}
        {error && (
          <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-6">
            {error}
          </div>
        )}
        {success && (
          <div className="bg-green-900/20 border border-green-500/30 rounded-xl px-4 py-3 text-green-400 text-sm mb-6">
            {success}
          </div>
        )}

        {/* Upload Button */}
        <button
          onClick={handleUpload}
          disabled={uploading || files.length === 0 || !selectedEvent}
          className="w-full bg-[#c9a96e] hover:bg-[#b8924f] text-black font-semibold py-4 rounded-xl tracking-widest uppercase transition-all disabled:opacity-40 disabled:cursor-not-allowed text-sm"
        >
          {uploading
            ? `Uploading ${progress}%...`
            : `Upload ${files.length > 0 ? files.length : ""} Photo${files.length !== 1 ? "s" : ""}`}
        </button>

        {/* View Events Link */}
        {success && (
          <button
            onClick={() => navigate("/events")}
            className="w-full mt-4 border border-[#c9a96e] text-[#c9a96e] hover:bg-[#c9a96e] hover:text-black font-semibold py-4 rounded-xl tracking-widest uppercase transition-all text-sm"
          >
            View My Events
          </button>
        )}
      </main>
    </div>
  );
};

export default UploadPage;
