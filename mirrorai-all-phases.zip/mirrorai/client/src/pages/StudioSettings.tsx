import { useState, useEffect, useRef } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import {
  User, Phone, Palette, Globe, Instagram, Image, Watermark,
  Save, Upload, Loader2, Check, Building2, Mail, Link2,
  ChevronRight, Camera, Type, AlignRight, Eye, EyeOff,
  Trash2, RefreshCw
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';

// ── Section wrapper ──────────────────────────────────────────
const Section = ({ icon: Icon, title, description, children }: {
  icon: any; title: string; description?: string; children: React.ReactNode;
}) => (
  <div className="bg-card border border-border rounded-lg p-6 space-y-5">
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
        <Icon className="h-4 w-4 text-primary" />
      </div>
      <div>
        <h2 className="font-semibold text-foreground text-[15px]">{title}</h2>
        {description && <p className="text-[12px] text-muted-foreground mt-0.5">{description}</p>}
      </div>
    </div>
    <Separator className="bg-border/50" />
    <div className="space-y-4">{children}</div>
  </div>
);

// ── Field wrapper ────────────────────────────────────────────
const Field = ({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) => (
  <div className="space-y-1.5">
    <Label className="text-[11px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</Label>
    {children}
    {hint && <p className="text-[11px] text-muted-foreground/50">{hint}</p>}
  </div>
);

// ── Save indicator ───────────────────────────────────────────
const SaveBtn = ({ onClick, loading, saved }: { onClick: () => void; loading: boolean; saved: boolean }) => (
  <Button
    onClick={onClick}
    disabled={loading}
    size="sm"
    className="h-8 px-4 text-[11px] uppercase tracking-wider font-bold gap-1.5"
  >
    {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : saved ? <Check className="h-3 w-3" /> : <Save className="h-3 w-3" />}
    {loading ? 'Saving...' : saved ? 'Saved!' : 'Save'}
  </Button>
);

// ────────────────────────────────────────────────────────────
const StudioSettings = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const logoInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  // Profile state
  const [studioName, setStudioName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [instagram, setInstagram] = useState('');
  const [website, setWebsite] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [logoUrl, setLogoUrl] = useState('');

  // Branding state
  const [brandColor, setBrandColor] = useState('#C4956A');
  const [brandFont, setBrandFont] = useState('Cormorant Garamond');

  // Watermark state
  const [watermarkText, setWatermarkText] = useState('');
  const [watermarkPosition, setWatermarkPosition] = useState('bottom-right');

  // Gallery defaults
  const [galleryLayout, setGalleryLayout] = useState('masonry');
  const [galleryStyle, setGalleryStyle] = useState('standard');
  const [downloadsEnabled, setDownloadsEnabled] = useState(true);
  const [watermarkEnabled, setWatermarkEnabled] = useState(false);

  // UI state
  const [loadings, setLoadings] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);

  // ── Load profile ──────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await (supabase.from('profiles').select('*') as any)
        .eq('user_id', user.id).single();
      if (data) {
        setStudioName(data.studio_name ?? '');
        setEmail(data.email ?? user.email ?? '');
        setMobile(data.mobile ?? '');
        setInstagram(data.social_instagram ?? '');
        setWebsite(data.social_website ?? '');
        setAvatarUrl(data.avatar_url ?? '');
        setLogoUrl(data.brand_logo_url ?? '');
        setBrandColor(data.brand_color ?? '#C4956A');
        setBrandFont(data.brand_font ?? 'Cormorant Garamond');
        setWatermarkText(data.watermark_text ?? '');
        setWatermarkPosition(data.watermark_position ?? 'bottom-right');
        setGalleryLayout(data.gallery_cover_style ?? 'masonry');
        setDownloadsEnabled(data.downloads_enabled ?? true);
        setWatermarkEnabled(data.watermark_enabled ?? false);
      }
      setPageLoading(false);
    })();
  }, [user]);

  // ── Save helper ───────────────────────────────────────────
  const saveSection = async (key: string, data: Record<string, any>) => {
    if (!user) return;
    setLoadings(l => ({ ...l, [key]: true }));
    setSaved(s => ({ ...s, [key]: false }));
    const { error } = await (supabase.from('profiles').update(data as any) as any).eq('user_id', user.id);
    if (error) {
      toast({ title: 'Error saving', description: error.message, variant: 'destructive' });
    } else {
      setSaved(s => ({ ...s, [key]: true }));
      setTimeout(() => setSaved(s => ({ ...s, [key]: false })), 2500);
      toast({ title: 'Saved! ✓' });
    }
    setLoadings(l => ({ ...l, [key]: false }));
  };

  // ── Upload image ──────────────────────────────────────────
  const uploadImage = async (
    file: File,
    bucket: string,
    pathPrefix: string,
    onDone: (url: string) => void,
    setUploading: (v: boolean) => void
  ) => {
    if (!user) return;
    setUploading(true);
    try {
      const ext = file.name.split('.').pop();
      const path = `${pathPrefix}/${user.id}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from(bucket).upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      const { data: { publicUrl } } = supabase.storage.from(bucket).getPublicUrl(path);
      onDone(publicUrl);
      toast({ title: 'Image uploaded ✓' });
    } catch (err: any) {
      toast({ title: 'Upload failed', description: err.message, variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  };

  // ── Link phone ────────────────────────────────────────────
  const linkPhone = async () => {
    if (!mobile) return;
    setLoadings(l => ({ ...l, phone: true }));
    const { error } = await supabase.auth.updateUser({ phone: mobile });
    if (error) toast({ title: 'Phone update failed', description: error.message, variant: 'destructive' });
    else toast({ title: 'Phone linked ✓' });
    setLoadings(l => ({ ...l, phone: false }));
  };

  // ── Loading screen ────────────────────────────────────────
  if (pageLoading) return (
    <DashboardLayout>
      <div className="flex items-center justify-center py-32">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto pb-16">

        {/* Header */}
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-foreground">Studio Settings</h1>
          <p className="text-[13px] text-muted-foreground mt-1">
            Manage your studio profile, branding, and gallery defaults.
          </p>
        </div>

        <div className="space-y-5">

          {/* ── 1. STUDIO IDENTITY ───────────────────────────── */}
          <Section icon={Building2} title="Studio Identity" description="Your public studio name and avatar">
            <div className="flex items-center gap-4">
              <div className="relative flex-shrink-0">
                <div className="w-16 h-16 rounded-full overflow-hidden bg-muted border border-border flex items-center justify-center">
                  {avatarUrl
                    ? <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                    : <User className="h-7 w-7 text-muted-foreground/30" />
                  }
                </div>
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center"
                >
                  {uploadingAvatar
                    ? <Loader2 className="h-3 w-3 text-primary-foreground animate-spin" />
                    : <Upload className="h-3 w-3 text-primary-foreground" />
                  }
                </button>
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={e => {
                    const f = e.target.files?.[0];
                    if (f) uploadImage(f, 'avatars', 'avatars', url => {
                      setAvatarUrl(url);
                      saveSection('avatar', { avatar_url: url });
                    }, setUploadingAvatar);
                  }}
                />
              </div>
              <div className="flex-1">
                <p className="text-[13px] font-semibold text-foreground">{studioName || 'Your Studio'}</p>
                <p className="text-[11px] text-muted-foreground">{email || user?.email}</p>
                <button
                  onClick={() => avatarInputRef.current?.click()}
                  className="text-[11px] text-primary mt-1 hover:underline"
                >
                  Change photo
                </button>
              </div>
            </div>

            <Field label="Studio Name">
              <Input
                value={studioName}
                onChange={e => setStudioName(e.target.value)}
                placeholder="e.g. Sharma Photography"
                className="bg-background"
              />
            </Field>

            <Field label="Email Address">
              <Input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@studio.com"
                className="bg-background"
              />
            </Field>

            <div className="flex justify-end">
              <SaveBtn
                onClick={() => saveSection('identity', { studio_name: studioName, email })}
                loading={loadings.identity}
                saved={saved.identity}
              />
            </div>
          </Section>

          {/* ── 2. CONTACT & SOCIAL ──────────────────────────── */}
          <Section icon={Phone} title="Contact & Social" description="How clients reach and find you">
            <Field label="Mobile Number" hint="Include country code, e.g. +91 9876543210">
              <div className="flex gap-2">
                <Input
                  type="tel"
                  value={mobile}
                  onChange={e => setMobile(e.target.value)}
                  placeholder="+91 9876543210"
                  className="bg-background flex-1"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={linkPhone}
                  disabled={loadings.phone || !mobile}
                  className="h-10 px-3 text-[11px] uppercase tracking-wider flex-shrink-0"
                >
                  {loadings.phone ? <Loader2 className="h-3 w-3 animate-spin" /> : 'Link'}
                </Button>
              </div>
            </Field>

            <Field label="Instagram Handle" hint="Without @">
              <div className="relative">
                <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/50" />
                <Input
                  value={instagram}
                  onChange={e => setInstagram(e.target.value)}
                  placeholder="yourstudio"
                  className="bg-background pl-9"
                />
              </div>
            </Field>

            <Field label="Website URL">
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground/50" />
                <Input
                  value={website}
                  onChange={e => setWebsite(e.target.value)}
                  placeholder="https://yourstudio.com"
                  className="bg-background pl-9"
                />
              </div>
            </Field>

            <div className="flex justify-end">
              <SaveBtn
                onClick={() => saveSection('social', {
                  mobile,
                  social_instagram: instagram,
                  social_website: website,
                })}
                loading={loadings.social}
                saved={saved.social}
              />
            </div>
          </Section>

          {/* ── 3. BRANDING ──────────────────────────────────── */}
          <Section icon={Palette} title="Branding" description="Colors, fonts, and your studio logo">

            {/* Logo upload */}
            <Field label="Studio Logo">
              <div className="flex items-center gap-3">
                <div className="w-24 h-14 rounded-md border border-border bg-background flex items-center justify-center overflow-hidden">
                  {logoUrl
                    ? <img src={logoUrl} alt="Logo" className="w-full h-full object-contain p-1" />
                    : <Image className="h-5 w-5 text-muted-foreground/30" />
                  }
                </div>
                <div className="space-y-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => logoInputRef.current?.click()}
                    disabled={uploadingLogo}
                    className="h-8 text-[11px] gap-1.5"
                  >
                    {uploadingLogo
                      ? <Loader2 className="h-3 w-3 animate-spin" />
                      : <Upload className="h-3 w-3" />
                    }
                    Upload Logo
                  </Button>
                  {logoUrl && (
                    <button
                      onClick={() => { setLogoUrl(''); saveSection('logo', { brand_logo_url: null }); }}
                      className="flex items-center gap-1 text-[11px] text-destructive hover:underline"
                    >
                      <Trash2 className="h-3 w-3" /> Remove
                    </button>
                  )}
                </div>
              </div>
              <input
                ref={logoInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={e => {
                  const f = e.target.files?.[0];
                  if (f) uploadImage(f, 'logos', 'logos', url => {
                    setLogoUrl(url);
                    saveSection('logo', { brand_logo_url: url });
                  }, setUploadingLogo);
                }}
              />
            </Field>

            {/* Brand color */}
            <Field label="Brand Color">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <input
                    type="color"
                    value={brandColor}
                    onChange={e => setBrandColor(e.target.value)}
                    className="w-10 h-10 rounded-md border border-border cursor-pointer p-0.5 bg-background"
                  />
                </div>
                <Input
                  value={brandColor}
                  onChange={e => setBrandColor(e.target.value)}
                  placeholder="#C4956A"
                  className="bg-background font-mono text-[13px] w-32"
                />
                <div className="flex gap-2">
                  {['#C4956A', '#8B6914', '#C49A3C', '#1A0F00', '#2A1A05'].map(c => (
                    <button
                      key={c}
                      onClick={() => setBrandColor(c)}
                      className="w-6 h-6 rounded-full border-2 transition-transform hover:scale-110"
                      style={{
                        backgroundColor: c,
                        borderColor: brandColor === c ? '#C49A3C' : 'transparent',
                      }}
                    />
                  ))}
                </div>
              </div>
            </Field>

            {/* Brand font */}
            <Field label="Gallery Font">
              <Select value={brandFont} onValueChange={setBrandFont}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Cormorant Garamond">Cormorant Garamond</SelectItem>
                  <SelectItem value="Playfair Display">Playfair Display</SelectItem>
                  <SelectItem value="Inter">Inter</SelectItem>
                  <SelectItem value="Lato">Lato</SelectItem>
                  <SelectItem value="Montserrat">Montserrat</SelectItem>
                </SelectContent>
              </Select>
            </Field>

            <div className="flex justify-end">
              <SaveBtn
                onClick={() => saveSection('branding', {
                  brand_color: brandColor,
                  brand_font: brandFont,
                  brand_logo_url: logoUrl || null,
                })}
                loading={loadings.branding}
                saved={saved.branding}
              />
            </div>
          </Section>

          {/* ── 4. WATERMARK ─────────────────────────────────── */}
          <Section icon={Type} title="Watermark" description="Add your studio name to gallery photos">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[13px] font-semibold text-foreground">Enable Watermark</p>
                <p className="text-[11px] text-muted-foreground">Overlay text on all gallery photos</p>
              </div>
              <Switch
                checked={watermarkEnabled}
                onCheckedChange={setWatermarkEnabled}
              />
            </div>

            {watermarkEnabled && (
              <>
                <Field label="Watermark Text" hint="Usually your studio name or Instagram handle">
                  <Input
                    value={watermarkText}
                    onChange={e => setWatermarkText(e.target.value)}
                    placeholder="@yourstudio"
                    className="bg-background"
                  />
                </Field>

                <Field label="Position">
                  <Select value={watermarkPosition} onValueChange={setWatermarkPosition}>
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="top-left">Top Left</SelectItem>
                      <SelectItem value="top-right">Top Right</SelectItem>
                      <SelectItem value="bottom-left">Bottom Left</SelectItem>
                      <SelectItem value="bottom-right">Bottom Right</SelectItem>
                      <SelectItem value="center">Center</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>

                {/* Preview */}
                <div className="relative rounded-md overflow-hidden bg-muted h-28 flex items-center justify-center">
                  <p className="text-[13px] text-muted-foreground/30 italic">Photo Preview</p>
                  <div className={`absolute text-[11px] font-semibold text-white/70 px-2 py-0.5
                    ${watermarkPosition === 'top-left' ? 'top-2 left-2' : ''}
                    ${watermarkPosition === 'top-right' ? 'top-2 right-2' : ''}
                    ${watermarkPosition === 'bottom-left' ? 'bottom-2 left-2' : ''}
                    ${watermarkPosition === 'bottom-right' ? 'bottom-2 right-2' : ''}
                    ${watermarkPosition === 'center' ? 'top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2' : ''}
                  `}>
                    {watermarkText || '@yourstudio'}
                  </div>
                </div>
              </>
            )}

            <div className="flex justify-end">
              <SaveBtn
                onClick={() => saveSection('watermark', {
                  watermark_enabled: watermarkEnabled,
                  watermark_text: watermarkText,
                  watermark_position: watermarkPosition,
                })}
                loading={loadings.watermark}
                saved={saved.watermark}
              />
            </div>
          </Section>

          {/* ── 5. GALLERY DEFAULTS ──────────────────────────── */}
          <Section icon={Camera} title="Gallery Defaults" description="Default settings for new events">
            <Field label="Default Layout">
              <Select value={galleryLayout} onValueChange={setGalleryLayout}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="masonry">Masonry</SelectItem>
                  <SelectItem value="classic">Classic Grid</SelectItem>
                  <SelectItem value="justified">Justified</SelectItem>
                  <SelectItem value="editorial">Editorial</SelectItem>
                  <SelectItem value="cinematic">Cinematic</SelectItem>
                </SelectContent>
              </Select>
            </Field>

            <div className="flex items-center justify-between py-1">
              <div>
                <p className="text-[13px] font-semibold text-foreground">Enable Downloads</p>
                <p className="text-[11px] text-muted-foreground">Allow guests to download photos by default</p>
              </div>
              <Switch
                checked={downloadsEnabled}
                onCheckedChange={setDownloadsEnabled}
              />
            </div>

            <div className="flex justify-end">
              <SaveBtn
                onClick={() => saveSection('gallery', {
                  gallery_cover_style: galleryLayout,
                  downloads_enabled: downloadsEnabled,
                })}
                loading={loadings.gallery}
                saved={saved.gallery}
              />
            </div>
          </Section>

          {/* ── 6. ACCOUNT ───────────────────────────────────── */}
          <Section icon={User} title="Account" description="Your login and account details">
            <div className="rounded-md bg-muted/30 border border-border p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[12px] text-muted-foreground uppercase tracking-wider">Email</span>
                <span className="text-[13px] text-foreground font-medium">{user?.email}</span>
              </div>
              <Separator className="bg-border/30" />
              <div className="flex items-center justify-between">
                <span className="text-[12px] text-muted-foreground uppercase tracking-wider">Account ID</span>
                <span className="text-[11px] text-muted-foreground font-mono">{user?.id?.slice(0, 8)}...</span>
              </div>
              <Separator className="bg-border/30" />
              <div className="flex items-center justify-between">
                <span className="text-[12px] text-muted-foreground uppercase tracking-wider">Provider</span>
                <span className="text-[13px] text-foreground font-medium capitalize">
                  {user?.app_metadata?.provider || 'Email'}
                </span>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              className="h-8 text-[11px] uppercase tracking-wider gap-1.5"
              onClick={async () => {
                await supabase.auth.resetPasswordForEmail(user?.email || '');
                toast({ title: 'Password reset email sent ✓' });
              }}
            >
              <RefreshCw className="h-3 w-3" /> Reset Password
            </Button>
          </Section>

        </div>
      </div>
    </DashboardLayout>
  );
};

export default StudioSettings;
