import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, Share2, ExternalLink } from 'lucide-react';

interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string | null;
  cover_url: string | null;
  event_id: string | null;
  seo_title: string | null;
  seo_description: string | null;
  created_at: string;
  user_id: string;
}

interface Photo {
  url: string;
  file_name: string | null;
}

const PublicBlog = () => {
  const { slug } = useParams();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [studioName, setStudioName] = useState('');
  const [eventSlug, setEventSlug] = useState('');
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!slug) return;
    (async () => {
      const { data } = await (supabase.from('blog_posts' as any).select('*') as any)
        .eq('slug', slug)
        .eq('published', true)
        .single();
      if (!data) { setLoading(false); return; }
      const p = data as BlogPost;
      setPost(p);

      // Set SEO
      document.title = p.seo_title || p.title;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.setAttribute('content', p.seo_description || '');

      // Fetch studio name
      const { data: profile } = await (supabase.from('profiles').select('studio_name, brand_name') as any)
        .eq('user_id', p.user_id).single();
      if (profile) setStudioName(profile.brand_name || profile.studio_name || '');

      // Fetch event photos if linked
      if (p.event_id) {
        const { data: event } = await (supabase.from('events').select('slug') as any).eq('id', p.event_id).single();
        if (event) setEventSlug(event.slug);
        const { data: photoData } = await (supabase.from('photos').select('url, file_name') as any)
          .eq('event_id', p.event_id).limit(12);
        if (photoData) setPhotos(photoData as Photo[]);
      }
      setLoading(false);
    })();
  }, [slug]);

  if (loading) return <div className="flex min-h-screen items-center justify-center bg-background"><div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" /></div>;
  if (!post) return <div className="flex min-h-screen items-center justify-center bg-background"><p className="text-foreground/40">Post not found</p></div>;

  const shareUrl = window.location.href;

  // Simple markdown-to-html (headers, bold, italic, paragraphs)
  const renderContent = (md: string) => {
    return md.split('\n\n').map((block, i) => {
      if (block.startsWith('# ')) return <h1 key={i} className="font-serif text-[36px] font-medium text-foreground mt-8 mb-4 leading-tight">{block.slice(2)}</h1>;
      if (block.startsWith('## ')) return <h2 key={i} className="font-serif text-[26px] font-medium text-foreground mt-6 mb-3">{block.slice(3)}</h2>;
      if (block.startsWith('### ')) return <h3 key={i} className="font-serif text-[20px] font-medium text-foreground mt-5 mb-2">{block.slice(4)}</h3>;
      const html = block
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(/\n/g, '<br/>');
      return <p key={i} className="text-[15px] text-foreground/70 leading-relaxed mb-4" dangerouslySetInnerHTML={{ __html: html }} />;
    });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero */}
      {post.cover_url && (
        <div className="relative w-full h-[50vh] overflow-hidden">
          <img src={post.cover_url} alt={post.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        </div>
      )}

      <article className="max-w-2xl mx-auto px-6 py-12">
        {/* Studio branding */}
        {studioName && (
          <p className="text-[10px] uppercase tracking-[0.3em] text-primary font-medium mb-6">{studioName}</p>
        )}

        <h1 className="font-serif text-[40px] font-medium text-foreground leading-[1.1] mb-4">{post.title}</h1>
        <p className="text-[12px] text-muted-foreground/50 mb-10">
          {new Date(post.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
        </p>

        {/* Content */}
        <div className="prose-mirror">
          {post.content && renderContent(post.content)}
        </div>

        {/* Event photos grid */}
        {photos.length > 0 && (
          <div className="mt-12">
            <p className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground/50 mb-4 font-medium">From the Gallery</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {photos.map((photo, i) => (
                <img key={i} src={photo.url} alt={photo.file_name || ''} className="w-full aspect-[4/3] object-cover" loading="lazy" />
              ))}
            </div>
            {eventSlug && (
              <div className="mt-4 text-center">
                <Link to={`/event/${eventSlug}/gallery`} className="inline-flex items-center gap-1.5 text-[12px] text-primary font-medium hover:underline">
                  <ExternalLink className="h-3 w-3" /> View Full Gallery
                </Link>
              </div>
            )}
          </div>
        )}

        {/* Share buttons */}
        <div className="mt-12 pt-6 border-t border-border flex items-center gap-3">
          <span className="text-[10px] uppercase tracking-[0.15em] text-muted-foreground/50 font-medium">Share</span>
          <a href={`https://wa.me/?text=${encodeURIComponent(post.title + ' ' + shareUrl)}`} target="_blank" rel="noopener noreferrer" className="text-[11px] text-foreground/50 hover:text-foreground transition-colors">WhatsApp</a>
          <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(post.title)}`} target="_blank" rel="noopener noreferrer" className="text-[11px] text-foreground/50 hover:text-foreground transition-colors">Twitter</a>
          <button onClick={() => navigator.clipboard.writeText(shareUrl)} className="text-[11px] text-foreground/50 hover:text-foreground transition-colors">Copy Link</button>
        </div>

        {/* Back */}
        <div className="mt-8">
          <Link to="/" className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground/40 hover:text-foreground transition-colors">
            <ArrowLeft className="h-3 w-3" /> Back
          </Link>
        </div>
      </article>
    </div>
  );
};

export default PublicBlog;
