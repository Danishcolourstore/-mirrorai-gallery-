import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const EventGallery = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [event, setEvent] = useState<any>(null);
  const [photos, setPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState<any>(null);
  const [selectedIndex, setSelectedIndex] = useState<number>(0);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchEvent();
    fetchPhotos();
  }, [session, id]);

  const fetchEvent = async () => {
    try {
      const { data } = await supabase
        .from("events")
        .select("*")
        .eq("id", id)
        .single();
      if (data) setEvent(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchPhotos = async () => {
    try {
      const { data } = await supabase
        .from("photos")
        .select("*")
        .eq("event_id", id)
        .order("created_at", { ascending: false });
      if (data) setPhotos(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setUploading(true);
    setError("");
    try {
      for (const file of Array.from(files)) {
        const fileExt = file.name.split(".").pop();
        const fileName = `${session.user.id}/${id}/${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from("photos")
          .upload(fileName, file);
        if (uploadError) throw uploadError;
        const { data: urlData } = supabase.storage
          .from("photos")
          .getPublicUrl(fileName);
        await supabase.from("photos").insert({
          event_id: id,
          user_id: session.user.id,
          url: urlData.publicUrl,
          filename: file.name,
        });
      }
      fetchPhotos();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleDeletePhoto = async (photo: any) => {
    if (!confirm("Delete this photo?")) return;
    try {
      await supabase.from("photos").delete().eq("id", photo.id);
      fetchPhotos();
      setSelectedPhoto(null);
    } catch (err) {
      console.error(err);
    }
  };

  const copyGalleryLink = () => {
    if (!event) return;
    const slug = event.slug || event.id;
    const link = `${window.location.origin}/gallery/${slug}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const openLightbox = (photo: any, index: number) => {
    setSelectedPhoto(photo);
    setSelectedIndex(index);
  };

  const prevPhoto = () => {
    if (selectedIndex > 0) {
      setSelectedIndex(selectedIndex - 1);
      setSelectedPhoto(photos[selectedIndex - 1]);
    }
  };

  const nextPhoto = () => {
    if (selectedIndex < photos.length - 1) {
      setSelectedIndex(selectedIndex + 1);
      setSelectedPhoto(photos[selectedIndex + 1]);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!selectedPhoto) return;
      if (e.key === "ArrowLeft") prevPhoto();
      if (e.key === "ArrowRight") nextPhoto();
      if (e.key === "Escape") setSelectedPhoto(null);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selectedPhoto, selectedIndex]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-40">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/dashboard")}
            className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
          >
            ← Dashboard
          </button>
          <span className="text-[#2a2a2a]">|</span>
          <button
            onClick={() => navigate("/events")}
            className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
          >
            Events
          </button>
        </div>

        <h1 className="text-xl font-serif text-[#c9a96e] tracking-widest uppercase hidden md:block">
          {event?.name || "Event Gallery"}
        </h1>

        <button
          onClick={copyGalleryLink}
          className={`border text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all ${
            copied
              ? "border-green-500 text-green-400"
              : "border-[#c9a96e] text-[#c9a96e] hover:bg-[#c9a96e] hover:text-black"
          }`}
        >
          {copied ? "Copied! ✓" : "Share Link"}
        </button>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">

        {/* Event Info Bar */}
        {event && (
          <div className="mb-8 flex flex-wrap gap-4 items-start justify-between">
            <div>
              <h2 className="text-2xl font-serif text-white mb-1">
                {event.name}
              </h2>
              <p className="text-[#888] text-sm tracking-widest">
                {event.date
                  ? new Date(event.date).toLocaleDateString()
                  : "No date"}{" "}
                · {event.location || "No location"} ·{" "}
                <span className="text-[#c9a96e]">{photos.length} photos</span>
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => navigate(`/gallery-cover/${id}`)}
                className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
              >
                🎨 Cover
              </button>
              <button
                onClick={() => navigate("/mirror-live")}
                className="border border-[#2a2a2a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
              >
                🪞 Mirror Live
              </button>
              <label className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-5 py-2 rounded-xl tracking-widest uppercase transition-all cursor-pointer">
                {uploading ? "Uploading..." : "+ Upload"}
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleUpload}
                  className="hidden"
                  disabled={uploading}
                />
              </label>
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-6">
            {error}
          </div>
        )}

        {/* Uploading indicator */}
        {uploading && (
          <div className="bg-[#111] border border-[#1a1a1a] rounded-xl px-4 py-3 text-center mb-6">
            <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
              Uploading photos... please wait
            </div>
          </div>
        )}

        {/* Photos Grid */}
        {photos.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-[#2a2a2a] rounded-2xl">
            <p className="text-[#444] text-sm tracking-widest uppercase mb-4">
              No photos yet
            </p>
            <label className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-6 py-3 rounded-xl tracking-widest uppercase transition-all cursor-pointer">
              Upload First Photo
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleUpload}
                className="hidden"
              />
            </label>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {photos.map((photo, index) => (
              <div
                key={photo.id}
                onClick={() => openLightbox(photo, index)}
                className="aspect-square bg-[#1a1a1a] rounded-xl overflow-hidden cursor-pointer group relative"
              >
                <img
                  src={photo.url}
                  alt={photo.filename}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all duration-300 flex items-center justify-center">
                  <span className="text-white text-2xl opacity-0 group-hover:opacity-100 transition-all">
                    🔍
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Lightbox */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 bg-black/95 flex items-center justify-center z-50 px-4"
          onClick={() => setSelectedPhoto(null)}
        >
          <div
            className="relative max-w-4xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Counter */}
            <p className="text-[#888] text-xs tracking-widest uppercase text-center mb-4">
              {selectedIndex + 1} / {photos.length}
            </p>

            {/* Image */}
            <img
              src={selectedPhoto.url}
              alt={selectedPhoto.filename}
              className="w-full max-h-[70vh] object-contain rounded-xl"
            />

            {/* Prev / Next */}
            <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex justify-between px-2 pointer-events-none">
              <button
                onClick={(e) => { e.stopPropagation(); prevPhoto(); }}
                disabled={selectedIndex === 0}
                className="pointer-events-auto bg-black/60 hover:bg-black/80 text-white w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-20 transition-all"
              >
                ‹
              </button>
              <button
                onClick={(e) => { e.stopPropagation(); nextPhoto(); }}
                disabled={selectedIndex === photos.length - 1}
                className="pointer-events-auto bg-black/60 hover:bg-black/80 text-white w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-20 transition-all"
              >
                ›
              </button>
            </div>

            {/* Bottom Bar */}
            <div className="flex justify-between items-center mt-4 flex-wrap gap-3">
              <p className="text-[#888] text-sm truncate max-w-xs">
                {selectedPhoto.filename}
              </p>
              <div className="flex gap-3">
                <a
                  href={selectedPhoto.url}
                  download
                  target="_blank"
                  rel="noreferrer"
                  className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
                  onClick={(e) => e.stopPropagation()}
                >
                  Download
                </a>
                <button
                  onClick={() => handleDeletePhoto(selectedPhoto)}
                  className="bg-red-900/40 hover:bg-red-900/60 text-red-400 text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all"
                >
                  Delete
                </button>
                <button
                  onClick={() => setSelectedPhoto(null)}
                  className="border border-[#2a2a2a] text-[#888] text-sm px-4 py-2 rounded-xl tracking-widest uppercase transition-all hover:border-[#444]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventGallery;
