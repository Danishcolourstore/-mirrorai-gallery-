import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const LandingPage = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  if (session) {
    navigate("/dashboard");
    return null;
  }

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setMessage("");

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        navigate("/dashboard");
      } else {
        const { error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        setMessage("Check your email to confirm your account!");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${window.location.origin}/dashboard`,
        },
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError("Please enter your email first.");
      return;
    }
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      setMessage("Password reset email sent! Check your inbox.");
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Hero Section */}
      <div className="relative overflow-hidden border-b border-[#1a1a1a]">
        <div className="absolute inset-0 bg-gradient-to-br from-[#c9a96e]/10 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-6xl mx-auto px-6 py-20 flex flex-col md:flex-row items-center gap-12">

          {/* Left: Text */}
          <div className="flex-1 text-center md:text-left">
            <p className="text-[#c9a96e] text-xs tracking-widest uppercase mb-4">
              Welcome to
            </p>
            <h1 className="text-6xl md:text-7xl font-serif text-white mb-4 leading-tight">
              Mirror<span className="text-[#c9a96e]">AI</span>
            </h1>
            <p className="text-[#888] text-lg mb-6 leading-relaxed">
              The luxury photo gallery platform for professional photographers.
              Deliver stunning galleries, impress clients, grow your studio.
            </p>
            <div className="flex flex-wrap gap-4 justify-center md:justify-start">
              {[
                "📸 Event Galleries",
                "🪞 Mirror Live",
                "📊 Analytics",
                "🎨 Custom Branding",
              ].map((feature) => (
                <span
                  key={feature}
                  className="bg-[#1a1a1a] border border-[#2a2a2a] px-4 py-2 rounded-full text-sm text-[#888] tracking-widest"
                >
                  {feature}
                </span>
              ))}
            </div>
          </div>

          {/* Right: Auth Card */}
          <div className="w-full max-w-md">
            <div className="bg-[#111] border border-[#2a2a2a] rounded-2xl p-8 shadow-2xl">

              {/* Tabs */}
              <div className="flex mb-8 border border-[#2a2a2a] rounded-xl overflow-hidden">
                <button
                  className={`flex-1 py-3 text-sm tracking-widest uppercase transition-all ${
                    isLogin
                      ? "bg-[#c9a96e] text-black font-semibold"
                      : "bg-transparent text-[#888] hover:text-white"
                  }`}
                  onClick={() => setIsLogin(true)}
                >
                  Sign In
                </button>
                <button
                  className={`flex-1 py-3 text-sm tracking-widest uppercase transition-all ${
                    !isLogin
                      ? "bg-[#c9a96e] text-black font-semibold"
                      : "bg-transparent text-[#888] hover:text-white"
                  }`}
                  onClick={() => setIsLogin(false)}
                >
                  Sign Up
                </button>
              </div>

              {/* Google Login */}
              <button
                onClick={handleGoogleLogin}
                className="w-full flex items-center justify-center gap-3 border border-[#2a2a2a] hover:border-[#c9a96e] text-white py-3 rounded-xl mb-6 tracking-widest uppercase text-sm transition-all"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Continue with Google
              </button>

              {/* Divider */}
              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1 h-px bg-[#2a2a2a]" />
                <span className="text-[#444] text-xs tracking-widest uppercase">or</span>
                <div className="flex-1 h-px bg-[#2a2a2a]" />
              </div>

              {/* Form */}
              <form onSubmit={handleAuth} className="space-y-5">
                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="your@email.com"
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>

                <div>
                  <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="••••••••"
                    className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                  />
                </div>

                {/* Forgot Password */}
                {isLogin && (
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="text-[#888] hover:text-[#c9a96e] text-xs tracking-widest uppercase transition-all"
                  >
                    Forgot Password?
                  </button>
                )}

                {/* Error & Success */}
                {error && (
                  <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
                    {error}
                  </div>
                )}
                {message && (
                  <div className="bg-green-900/20 border border-green-500/30 rounded-xl px-4 py-3 text-green-400 text-sm">
                    {message}
                  </div>
                )}

                {/* Submit */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#c9a96e] hover:bg-[#b8924f] text-black font-semibold py-3 rounded-xl tracking-widest uppercase transition-all disabled:opacity-50"
                >
                  {loading
                    ? "Please wait..."
                    : isLogin
                    ? "Sign In"
                    : "Create Account"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-6xl mx-auto px-6 py-20">
        <h2 className="text-3xl font-serif text-center text-white mb-4">
          Everything You Need
        </h2>
        <p className="text-[#888] text-center text-sm tracking-widest uppercase mb-12">
          Built for professional photographers
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[
            {
              icon: "📸",
              title: "Event Galleries",
              desc: "Create stunning galleries for weddings, portraits, corporate events and more.",
            },
            {
              icon: "🔗",
              title: "Shareable Links",
              desc: "Share beautiful public galleries with your clients instantly.",
            },
            {
              icon: "🪞",
              title: "Mirror Live",
              desc: "Live photo sharing at events — guests see photos in real time.",
            },
            {
              icon: "🎨",
              title: "Custom Branding",
              desc: "Your logo, your colors, your watermark on every gallery.",
            },
            {
              icon: "📊",
              title: "Analytics",
              desc: "Track views, downloads, and engagement across all your galleries.",
            },
            {
              icon: "📝",
              title: "Studio Blog",
              desc: "Publish blog posts to attract clients and showcase your work.",
            },
          ].map((feature) => (
            <div
              key={feature.title}
              className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6 hover:border-[#c9a96e] transition-all"
            >
              <div className="text-3xl mb-4">{feature.icon}</div>
              <h3 className="text-white font-serif text-lg mb-2">
                {feature.title}
              </h3>
              <p className="text-[#888] text-sm leading-relaxed">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="border-t border-[#1a1a1a] py-16 text-center px-6">
        <h2 className="text-4xl font-serif text-white mb-4">
          Start Delivering{" "}
          <span className="text-[#c9a96e]">Luxury Galleries</span>
        </h2>
        <p className="text-[#888] text-sm tracking-widest uppercase mb-8">
          Join photographers who trust MirrorAI
        </p>
        <button
          onClick={() => setIsLogin(false)}
          className="bg-[#c9a96e] hover:bg-[#b8924f] text-black font-semibold px-10 py-4 rounded-xl tracking-widest uppercase transition-all"
        >
          Get Started Free
        </button>
      </div>

      {/* Footer */}
      <footer className="border-t border-[#1a1a1a] px-6 py-6 text-center">
        <p className="text-[#444] text-xs tracking-widest uppercase">
          © 2024 MirrorAI · Luxury Photo Gallery Platform
        </p>
      </footer>
    </div>
  );
};

export default LandingPage;
