import { DashboardLayout } from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { usePlan } from '@/hooks/use-plan';
import { useRazorpay } from '@/hooks/use-razorpay';
import { Check, Crown, X } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const features = [
  { name: 'Events', free: '3', pro: 'Unlimited' },
  { name: 'Storage', free: '5 GB', pro: '500 GB' },
  { name: 'Gallery Styles', free: 'Standard', pro: 'Standard + Studio' },
  { name: 'MirrorAI Watermark', free: 'Yes', pro: 'No' },
  { name: 'Studio Branding', free: false, pro: true },
  { name: 'Analytics', free: false, pro: true },
  { name: 'Email Collection', free: false, pro: true },
  { name: 'Photo Selection', free: false, pro: true },
  { name: 'Support', free: 'Basic', pro: 'Priority' },
];

const Billing = () => {
  const { plan, isPro, planExpiresAt, eventCount, storageUsedMb, storageLimitMb, loading } = usePlan();
  const { openCheckout } = useRazorpay();
  const navigate = useNavigate();

  if (loading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center py-24">
          <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <h1 className="font-serif text-4xl font-bold text-foreground mb-8">Plan & Billing</h1>

      {/* Current Plan */}
      <div className="border border-border rounded-xl p-6 bg-card mb-8">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-bold text-foreground">
                {isPro ? 'Pro Plan' : 'Free Plan'}
              </h2>
              {isPro && (
                <span className="bg-primary/10 text-primary text-[11px] uppercase tracking-[0.12em] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Crown className="h-3 w-3" /> Pro
                </span>
              )}
            </div>
            {isPro && planExpiresAt && (
              <p className="text-[15px] text-muted-foreground">
                Valid until {format(new Date(planExpiresAt), 'MMMM d, yyyy')}
              </p>
            )}
            {!isPro && (
              <p className="text-[15px] text-muted-foreground">
                {eventCount}/3 events · {Math.round(storageUsedMb)}MB / {Math.round(storageLimitMb / 1024)}GB storage
              </p>
            )}
          </div>
          {!isPro && (
            <Button onClick={openCheckout} className="gap-1.5">
              <Crown className="h-4 w-4" />
              Upgrade to Pro — ₹3,750/year
            </Button>
          )}
        </div>
      </div>

      {/* Feature comparison */}
      <div className="border border-border rounded-xl overflow-hidden bg-card">
        <table className="w-full text-[15px]">
          <thead>
            <tr className="border-b border-border bg-secondary/30">
              <th className="text-left px-5 py-3 font-semibold text-foreground">Feature</th>
              <th className="text-center px-5 py-3 font-semibold text-foreground w-32">Free</th>
              <th className="text-center px-5 py-3 font-semibold text-primary w-32">
                <span className="flex items-center justify-center gap-1">
                  <Crown className="h-3.5 w-3.5" /> Pro
                </span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {features.map((f) => (
              <tr key={f.name}>
                <td className="px-5 py-3 text-foreground">{f.name}</td>
                <td className="px-5 py-3 text-center">
                  {typeof f.free === 'boolean' ? (
                    f.free ? <Check className="h-4 w-4 text-primary mx-auto" /> : <X className="h-4 w-4 text-muted-foreground/40 mx-auto" />
                  ) : (
                    <span className="text-muted-foreground">{f.free}</span>
                  )}
                </td>
                <td className="px-5 py-3 text-center">
                  {typeof f.pro === 'boolean' ? (
                    f.pro ? <Check className="h-4 w-4 text-primary mx-auto" /> : <X className="h-4 w-4 text-muted-foreground/40 mx-auto" />
                  ) : (
                    <span className="text-foreground font-semibold">{f.pro}</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* View full pricing */}
      <div className="mt-6 text-center">
        <button
          onClick={() => navigate('/pricing')}
          className="text-[15px] text-primary hover:text-primary/80 transition-colors"
        >
          View full pricing page →
        </button>
      </div>
    </DashboardLayout>
  );
};

export default Billing;
