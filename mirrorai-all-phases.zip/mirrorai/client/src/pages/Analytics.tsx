import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const Analytics = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [events, setEvents] = useState<any[]>([]);
  const [totalPhotos, setTotalPhotos] = useState(0);
  const [totalEvents, setTotalEvents] = useState(0);
  const [recentPhotos, setRecentPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchAnalytics();
  }, [session]);

  const fetchAnalytics = async () => {
    try {
      // Fetch events with photo counts
      const { data: eventsData } = await supabase
        .from("events")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false });

      if (eventsData) {
        const eventsWithCount = await Promise.all(
          eventsData.map(async (event) => {
            const { count } = await supabase
              .from("photos")
              .select("*", { count: "exact", head: true })
              .eq("event_id", event.id);
            return { ...event, photo_count: count || 0 };
          })
        );
        setEvents(eventsWithCount);
        setTotalEvents(eventsData.length);
      }

      // Total photos
      const { count: photosCount } = await supabase
        .from("photos")
        .select("*", { count: "exact", head: true })
        .eq("user_id", session.user.id);
      setTotalPhotos(photosCount || 0);

      // Recent photos
      const { data: recentData } = await supabase
        .from("photos")
        .select("*")
        .eq("user_id", session.user.id)
        .order("created_at", { ascending: false })
        .limit(8);
      if (recentData) setRecentPhotos(recentData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getThisMonthEvents = () => {
    const now = new Date();
    return events.filter((e) => {
      const d = new Date(e.created_at);
      return (
        d.getMonth() === now.getMonth() &&
        d.getFullYear() === now.getFullYear()
      );
    }).length;
  };

  const getTopEvent = () => {
    if (events.length === 0) return null;
    return events.reduce((a, b) =>
      a.photo_count > b.photo_count ? a : b
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  const topEvent = getTopEvent();

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-40">
        <button
          onClick={() => navigate("/dashboard")}
          className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
        >
          ← Dashboard
        </button>
        <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
          Analytics
        </h1>
        <div className="w-24" />
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10">

        {/* Page Title */}
        <div className="mb-10">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-1">
            Studio Insights
          </p>
          <h2 className="text-3xl font-serif text-white">Your Analytics</h2>
        </div>

        {/* Top Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { label: "Total Events", value: totalEvents, icon: "📅" },
            { label: "Total Photos", value: totalPhotos, icon: "📷" },
            { label: "This Month", value: getThisMonthEvents(), icon: "🗓️" },
            {
              label: "Avg Photos/Event",
              value:
                totalEvents > 0
                  ? Math.round(totalPhotos / totalEvents)
                  : 0,
              icon: "📊",
            },
          ].map((stat) => (
            <div
              key={stat.label}
              className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-5 text-center hover:border-[#c9a96e] transition-all"
            >
              <div className="text-2xl mb-2">{stat.icon}</div>
              <div className="text-3xl font-serif text-white mb-1">
                {stat.value}
              </div>
              <div className="text-[#888] text-xs tracking-widest uppercase">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Top Event */}
        {topEvent && (
          <div className="mb-12">
            <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
              Top Performing Event
            </p>
            <div
              className="bg-[#111] border border-[#c9a96e]/30 rounded-2xl p-6 flex flex-wrap items-center justify-between gap-4 cursor-pointer hover:border-[#c9a96e] transition-all"
              onClick={() => navigate(`/event/${topEvent.id}`)}
            >
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl bg-[#1a1a1a] overflow-hidden flex items-center justify-center">
                  {topEvent.cover_image ? (
                    <img
                      src={topEvent.cover_image}
                      alt={topEvent.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-2xl">📷</span>
                  )}
                </div>
                <div>
                  <h3 className="text-white font-serif text-xl mb-1">
                    {topEvent.name}
                  </h3>
                  <p className="text-[#888] text-xs tracking-widest">
                    {topEvent.location || "No location"} ·{" "}
                    {topEvent.date
                      ? new Date(topEvent.date).toLocaleDateString()
                      : "No date"}
                  </p>
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-serif text-[#c9a96e]">
                  {topEvent.photo_count}
                </div>
                <div className="text-[#888] text-xs tracking-widest uppercase">
                  Photos
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Events Breakdown */}
        <div className="mb-12">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
            Events Breakdown
          </p>
          {events.length === 0 ? (
            <div className="text-center py-16 border border-dashed border-[#2a2a2a] rounded-2xl">
              <p className="text-[#444] text-sm tracking-widest uppercase">
                No events yet
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {events.map((event) => {
                const pct =
                  totalPhotos > 0
                    ? Math.round((event.photo_count / totalPhotos) * 100)
                    : 0;
                return (
                  <div
                    key={event.id}
                    className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-4 hover:border-[#c9a96e] transition-all cursor-pointer"
                    onClick={() => navigate(`/event/${event.id}`)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h3 className="text-white text-sm font-serif">
                          {event.name}
                        </h3>
                        <p className="text-[#888] text-xs tracking-widest">
                          {event.date
                            ? new Date(event.date).toLocaleDateString()
                            : "No date"}{" "}
                          · {event.location || "No location"}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="text-white font-serif text-lg">
                          {event.photo_count}
                        </span>
                        <span className="text-[#888] text-xs ml-1">
                          photos
                        </span>
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div className="w-full bg-[#1a1a1a] rounded-full h-1.5">
                      <div
                        className="bg-[#c9a96e] h-1.5 rounded-full transition-all duration-700"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <p className="text-[#555] text-xs mt-1 text-right">
                      {pct}% of total
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Recent Uploads */}
        <div className="mb-12">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
            Recent Uploads
          </p>
          {recentPhotos.length === 0 ? (
            <div className="text-center py-16 border border-dashed border-[#2a2a2a] rounded-2xl">
              <p className="text-[#444] text-sm tracking-widest uppercase">
                No photos yet
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3">
              {recentPhotos.map((photo) => (
                <div
                  key={photo.id}
                  className="aspect-square bg-[#1a1a1a] rounded-xl overflow-hidden"
                >
                  <img
                    src={photo.url}
                    alt={photo.filename}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div>
          <p className="text-[#888] text-xs tracking-widest uppercase mb-4">
            Quick Actions
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "New Event", path: "/events", icon: "📅" },
              { label: "Upload Photos", path: "/upload", icon: "📸" },
              { label: "Mirror Live", path: "/mirror-live", icon: "🪞" },
              { label: "Branding", path: "/branding", icon: "🎨" },
            ].map((action) => (
              <button
                key={action.path}
                onClick={() => navigate(action.path)}
                className="flex flex-col items-center gap-2 py-5 px-3 rounded-2xl text-xs tracking-widest uppercase bg-[#111] border border-[#1a1a1a] hover:border-[#c9a96e] text-[#888] hover:text-[#c9a96e] transition-all"
              >
                <span className="text-2xl">{action.icon}</span>
                {action.label}
              </button>
            ))}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1a1a1a] mt-16 px-6 py-6 text-center">
        <p className="text-[#444] text-xs tracking-widest uppercase">
          © 2024 MirrorAI · Studio Analytics
        </p>
      </footer>
    </div>
  );
};

export default Analytics;
