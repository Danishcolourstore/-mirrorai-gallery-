import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const Branding = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [logoUrl, setLogoUrl] = useState("");
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [brandName, setBrandName] = useState("");
  const [tagline, setTagline] = useState("");
  const [primaryColor, setPrimaryColor] = useState("#c9a96e");
  const [bgColor, setBgColor] = useState("#0a0a0a");
  const [fontStyle, setFontStyle] = useState("serif");
  const [watermarkText, setWatermarkText] = useState("");
  const [watermarkOpacity, setWatermarkOpacity] = useState(30);
  const [socialInstagram, setSocialInstagram] = useState("");
  const [socialWebsite, setSocialWebsite] = useState("");

  useEffect(() => {
    if (!session) {
      navigate("/");
      return;
    }
    fetchBranding();
  }, [session]);

  const fetchBranding = async () => {
    try {
      const { data } = await supabase
        .from("branding")
        .select("*")
        .eq("user_id", session.user.id)
        .single();
      if (data) {
        setBrandName(data.brand_name || "");
        setTagline(data.tagline || "");
        setPrimaryColor(data.primary_color || "#c9a96e");
        setBgColor(data.bg_color || "#0a0a0a");
        setFontStyle(data.font_style || "serif");
        setWatermarkText(data.watermark_text || "");
        setWatermarkOpacity(data.watermark_opacity || 30);
        setSocialInstagram(data.social_instagram || "");
        setSocialWebsite(data.social_website || "");setLogoUrl(data.logo_url || "");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingLogo(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${session.user.id}/logo.${fileExt}`;
      const { error: uploadError } = await supabase.storage
        .from("branding")
        .upload(fileName, file, { upsert: true });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage
        .from("branding")
        .getPublicUrl(fileName);
      setLogoUrl(urlData.publicUrl);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError("");
    try {
      const payload = {
        user_id: session.user.id,
        brand_name: brandName,
        tagline,
        primary_color: primaryColor,
        bg_color: bgColor,
        font_style: fontStyle,
        watermark_text: watermarkText,
        watermark_opacity: watermarkOpacity,
        social_instagram: socialInstagram,
        social_website: socialWebsite,
        logo_url: logoUrl,
      };
      const { error } = await supabase
        .from("branding")
        .upsert(payload, { onConflict: "user_id" });
      if (error) throw error;
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-[#c9a96e] text-sm tracking-widest uppercase animate-pulse">
          Loading...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">

      {/* Header */}
      <header className="border-b border-[#1a1a1a] px-6 py-4 flex items-center justify-between sticky top-0 bg-[#0a0a0a] z-40">
        <button
          onClick={() => navigate("/dashboard")}
          className="text-[#888] hover:text-[#c9a96e] text-sm tracking-widest uppercase transition-all"
        >
          ← Dashboard
        </button>
        <h1 className="text-2xl font-serif text-[#c9a96e] tracking-widest uppercase">
          Branding
        </h1>
        <button
          onClick={handleSave}
          disabled={saving}
          className={`text-sm font-semibold px-5 py-2 rounded-xl tracking-widest uppercase transition-all ${
            saved
              ? "bg-green-600 text-white"
              : "bg-[#c9a96e] hover:bg-[#b8924f] text-black"
          } disabled:opacity-50`}
        >
          {saved ? "Saved ✓" : saving ? "Saving..." : "Save"}
        </button>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-10">

        <div className="mb-10">
          <p className="text-[#888] text-xs tracking-widest uppercase mb-1">
            Studio Identity
          </p>
          <h2 className="text-3xl font-serif text-white">Your Branding</h2>
        </div>

        {error && (
          <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-6">
            {error}
          </div>
        )}

        <div className="space-y-8">

          {/* Logo */}
          <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6">
            <h3 className="text-white font-serif text-lg mb-4">Logo</h3>
            <div className="flex flex-wrap items-center gap-6">
              <div className="w-24 h-24 rounded-2xl bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center overflow-hidden">
                {logoUrl ? (
                  <img
                    src={logoUrl}
                    alt="Logo"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <span className="text-[#444] text-3xl">🎨</span>
                )}
              </div>
              <div>
                <label className="bg-[#c9a96e] hover:bg-[#b8924f] text-black text-sm font-semibold px-5 py-2 rounded-xl tracking-widest uppercase transition-all cursor-pointer block mb-2">
                  {uploadingLogo ? "Uploading..." : "Upload Logo"}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                    disabled={uploadingLogo}
                  />
                </label><p className="text-[#555] text-xs tracking-widest">
                  PNG or SVG recommended · Max 2MB
                </p>
              </div>
            </div>
          </div>

          {/* Brand Info */}
          <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6">
            <h3 className="text-white font-serif text-lg mb-4">
              Brand Info
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Studio / Brand Name
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  placeholder="Your Studio Name"
                  className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                />
              </div>
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Tagline
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="Capturing moments, forever."
                  className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                />
              </div></div>
          </div>

          {/* Colors */}
          <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6">
            <h3 className="text-white font-serif text-lg mb-4">Colors</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Primary / Accent Color
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="w-12 h-12 rounded-xl border border-[#2a2a2a] bg-transparent cursor-pointer"/>
                  <input
                    type="text"
                    value={primaryColor}
                    onChange={(e) => setPrimaryColor(e.target.value)}
                    className="flex-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#c9a96e] transition-all font-mono text-sm"
                  />
                </div>
              </div>
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Background Color
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                    className="w-12 h-12 rounded-xl border border-[#2a2a2a] bg-transparent cursor-pointer"
                  />
                  <input
                    type="text"
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                    className="flex-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-[#c9a96e] transition-all font-mono text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Preview */}
            <div
              className="mt-6 rounded-2xl p-6 text-center border border-[#2a2a2a]"
              style={{ backgroundColor: bgColor }}
            >
              <p
                className="text-2xl font-serif mb-1"
                style={{ color: primaryColor }}
              >
                {brandName || "Your Studio"}
              </p>
              <p className="text-sm" style={{ color: primaryColor + "99" }}>
                {tagline || "Your tagline here"}
              </p></div>
          </div>

          {/* Font */}
          <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6">
            <h3 className="text-white font-serif text-lg mb-4">Font Style</h3>
            <div className="grid grid-cols-3 gap-3">
              {["serif", "sans-serif", "monospace"].map((font) => (
                <button
                  key={font}
                  onClick={() => setFontStyle(font)}
                  className={`py-4 rounded-xl border text-sm tracking-widest uppercase transition-all ${
                    fontStyle === font
                      ? "border-[#c9a96e] text-[#c9a96e] bg-[#c9a96e]/10"
                      : "border-[#2a2a2a] text-[#888] hover:border-[#444]"
                  }`}style={{ fontFamily: font }}
                >
                  {font}
                </button>
              ))}
            </div>
          </div>

          {/* Watermark */}
          <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6">
            <h3 className="text-white font-serif text-lg mb-4">Watermark</h3>
            <div className="space-y-4">
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Watermark Text
                </label>
                <input
                  type="text"
                  value={watermarkText}
                  onChange={(e) => setWatermarkText(e.target.value)}
                  placeholder="© Your Studio Name"
                  className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                />
              </div>
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Opacity: {watermarkOpacity}%
                </label>
                <input
                  type="range"
                  min={10}
                  max={100}
                  value={watermarkOpacity}
                  onChange={(e) => setWatermarkOpacity(Number(e.target.value))}
                  className="w-full accent-[#c9a96e]"
                />
              </div>
              {/* Watermark Preview */}
              {watermarkText && (
                <div className="relative bg-[#1a1a1a] rounded-xl h-32 flex items-center justify-center overflow-hidden">
                  <span className="text-[#888] text-sm">Preview Image</span>
                  <span
                    className="absolute bottom-3 right-3 text-white text-xs tracking-widest pointer-events-none"
                    style={{ opacity: watermarkOpacity / 100 }}
                  >
                    {watermarkText}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Social Links */}
          <div className="bg-[#111] border border-[#1a1a1a] rounded-2xl p-6">
            <h3 className="text-white font-serif text-lg mb-4">
              Social Links
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Instagram
                </label>
                <input
                  type="text"
                  value={socialInstagram}
                  onChange={(e) => setSocialInstagram(e.target.value)}
                  placeholder="@yourstudio"
                  className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                />
              </div>
              <div>
                <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
                  Website
                </label>
                <input
                  type="text"
                  value={socialWebsite}
                  onChange={(e) => setSocialWebsite(e.target.value)}
                  placeholder="https://yourstudio.com"
                  className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
                />
              </div>
            </div>
          </div>

          {/* Save Button */}
          <button
            onClick={handleSave}
            disabled={saving}
            className={`w-full py-4 rounded-2xl text-sm font-semibold tracking-widest uppercase transition-all ${
              saved
                ? "bg-green-600 text-white"
                : "bg-[#c9a96e] hover:bg-[#b8924f] text-black"
            } disabled:opacity-50`}
          >
            {saved ? "Saved ✓" : saving ? "Saving..." : "Save Branding"}
          </button>
        </div>
      </main>

      <footer className="border-t border-[#1a1a1a] mt-16 px-6 py-6 text-center">
        <p className="text-[#444] text-xs tracking-widest uppercase">
          © 2024 MirrorAI · Studio Branding
        </p>
      </footer>
    </div>
  );
};

export default Branding;
