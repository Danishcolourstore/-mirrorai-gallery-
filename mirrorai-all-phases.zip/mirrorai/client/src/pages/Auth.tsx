import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

const Auth = ({ session }: { session: any }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLogin, setIsLogin] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  if (session) {
    navigate("/dashboard");
    return null;
  }

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setMessage("");

    try {
      if (isLogin) {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;
        navigate("/dashboard");
      } else {
        const { error } = await supabase.auth.signUp({
          email,
          password,
        });
        if (error) throw error;
        setMessage("Check your email to confirm your account!");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${window.location.origin}/dashboard`,
        },
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      setError("Please enter your email first.");
      return;
    }
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
      setMessage("Password reset email sent! Check your inbox.");
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col items-center justify-center px-4">

      {/* Logo */}
      <div className="mb-10 text-center">
        <h1 className="text-5xl font-serif text-[#c9a96e] tracking-widest uppercase">
          MirrorAI
        </h1>
        <p className="text-[#888] text-sm mt-2 tracking-widest uppercase">
          Moment Reflections Suite
        </p>
      </div>

      {/* Auth Card */}
      <div className="w-full max-w-md bg-[#111] border border-[#2a2a2a] rounded-2xl p-8 shadow-2xl">

        {/* Tabs */}
        <div className="flex mb-8 border border-[#2a2a2a] rounded-xl overflow-hidden">
          <button
            className={`flex-1 py-3 text-sm tracking-widest uppercase transition-all ${
              isLogin
                ? "bg-[#c9a96e] text-black font-semibold"
                : "bg-transparent text-[#888] hover:text-white"
            }`}
            onClick={() => setIsLogin(true)}
          >
            Sign In
          </button>
          <button
            className={`flex-1 py-3 text-sm tracking-widest uppercase transition-all ${
              !isLogin
                ? "bg-[#c9a96e] text-black font-semibold"
                : "bg-transparent text-[#888] hover:text-white"
            }`}
            onClick={() => setIsLogin(false)}
          >
            Sign Up
          </button>
        </div>

        {/* Google Login */}
        <button
          onClick={handleGoogleLogin}
          className="w-full flex items-center justify-center gap-3 border border-[#2a2a2a] hover:border-[#c9a96e] text-white py-3 rounded-xl mb-6 tracking-widest uppercase text-sm transition-all"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
            />
          </svg>
          Continue with Google
        </button>

        {/* Divider */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 h-px bg-[#2a2a2a]" />
          <span className="text-[#444] text-xs tracking-widest uppercase">or</span>
          <div className="flex-1 h-px bg-[#2a2a2a]" />
        </div>

        {/* Form */}
        <form onSubmit={handleAuth} className="space-y-5">
          <div>
            <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="your@email.com"
              className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
            />
          </div>

          <div>
            <label className="text-[#888] text-xs tracking-widest uppercase block mb-2">
              Password
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              className="w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl px-4 py-3 text-white placeholder-[#444] focus:outline-none focus:border-[#c9a96e] transition-all"
            />
          </div>

          {/* Forgot Password */}
          {isLogin && (
            <button
              type="button"
              onClick={handleForgotPassword}
              className="text-[#888] hover:text-[#c9a96e] text-xs tracking-widest uppercase transition-all"
            >
              Forgot Password?
            </button>
          )}

          {/* Error & Success Messages */}
          {error && (
            <div className="bg-red-900/20 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
              {error}
            </div>
          )}
          {message && (
            <div className="bg-green-900/20 border border-green-500/30 rounded-xl px-4 py-3 text-green-400 text-sm">
              {message}
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#c9a96e] hover:bg-[#b8924f] text-black font-semibold py-3 rounded-xl tracking-widest uppercase transition-all disabled:opacity-50"
          >
            {loading
              ? "Please wait..."
              : isLogin
              ? "Sign In"
              : "Create Account"}
          </button>
        </form>
      </div>

      {/* Footer */}
      <p className="text-[#444] text-xs mt-8 tracking-widest uppercase">
        Luxury Photo Gallery Platform
      </p>
    </div>
  );
};

export default Auth;
