import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  UserPlus,
  MoreVertical,
  Copy,
  Eye,
  EyeOff,
  KeyRound,
  LogIn,
  RefreshCw,
  Loader2,
  Search,
} from 'lucide-react';

interface Photographer {
  id: string;
  user_id: string;
  studio_name: string;
  email: string | null;
  plan: string;
  suspended: boolean;
  created_at: string;
  event_count: number;
  photo_count: number;
}

function generatePassword(len = 12): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$';
  let pw = '';
  const arr = new Uint32Array(len);
  crypto.getRandomValues(arr);
  for (let i = 0; i < len; i++) pw += chars[arr[i] % chars.length];
  return pw;
}

async function callAdminUsers(payload: Record<string, any>) {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) throw new Error('Not authenticated');

  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-users`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
        apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
      },
      body: JSON.stringify(payload),
    }
  );
  const json = await res.json();
  if (!res.ok) throw new Error(json.error || 'Request failed');
  return json;
}

export default function AdminPhotographers() {
  const { toast } = useToast();
  const [photographers, setPhotographers] = useState<Photographer[]>([]);
  const [search, setSearch] = useState('');

  // Add photographer modal
  const [addOpen, setAddOpen] = useState(false);
  const [addForm, setAddForm] = useState({ name: '', email: '', password: generatePassword(), plan: 'free' });
  const [addLoading, setAddLoading] = useState(false);
  const [createdCreds, setCreatedCreds] = useState<{ email: string; password: string } | null>(null);

  // Reset password modal
  const [resetOpen, setResetOpen] = useState(false);
  const [resetTarget, setResetTarget] = useState<Photographer | null>(null);
  const [resetPassword, setResetPassword] = useState(generatePassword());
  const [resetLoading, setResetLoading] = useState(false);
  const [resetDone, setResetDone] = useState(false);

  // View credentials / show password
  const [showPwFor, setShowPwFor] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data } = await (supabase
      .from('profiles')
      .select('id, user_id, studio_name, email, plan, suspended, created_at') as any);
    if (!data) return;

    // Paginate events to avoid 1000 row limit
    const eventUserIds: string[] = [];
    let from = 0;
    const PAGE = 1000;
    let hasMore = true;
    while (hasMore) {
      const { data: batch } = await (supabase.from('events').select('user_id').range(from, from + PAGE - 1) as any);
      if (!batch || batch.length === 0) break;
      batch.forEach((e: any) => eventUserIds.push(e.user_id));
      hasMore = batch.length === PAGE;
      from += PAGE;
    }
    const countMap: Record<string, number> = {};
    eventUserIds.forEach((uid) => { countMap[uid] = (countMap[uid] || 0) + 1; });

    // Paginate photos to avoid 1000 row limit
    const photoUserIds: string[] = [];
    from = 0;
    hasMore = true;
    while (hasMore) {
      const { data: batch } = await (supabase.from('photos').select('user_id').range(from, from + PAGE - 1) as any);
      if (!batch || batch.length === 0) break;
      batch.forEach((p: any) => photoUserIds.push(p.user_id));
      hasMore = batch.length === PAGE;
      from += PAGE;
    }
    const photoCountMap: Record<string, number> = {};
    photoUserIds.forEach((uid) => { photoCountMap[uid] = (photoCountMap[uid] || 0) + 1; });

    setPhotographers(
      (data as any[]).map((p: any) => ({
        ...p,
        event_count: countMap[p.user_id] || 0,
        photo_count: photoCountMap[p.user_id] || 0,
      }))
    );
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateProfile = async (userId: string, updates: Record<string, any>) => {
    const { error } = await (supabase.from('profiles').update(updates) as any).eq('user_id', userId);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: 'Updated' }); load(); }
  };

  const handleAddPhotographer = async () => {
    if (!addForm.email || !addForm.password) return;
    setAddLoading(true);
    try {
      await callAdminUsers({
        action: 'create_user',
        email: addForm.email,
        password: addForm.password,
        studio_name: addForm.name || 'My Studio',
        plan: addForm.plan,
      });
      setCreatedCreds({ email: addForm.email, password: addForm.password });
      toast({ title: 'Account created', description: `Account created for ${addForm.email}` });
      load();
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setAddLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!resetTarget || !resetPassword) return;
    setResetLoading(true);
    try {
      await callAdminUsers({
        action: 'reset_password',
        user_id: resetTarget.user_id,
        password: resetPassword,
      });
      setResetDone(true);
      toast({ title: 'Password updated', description: `Password updated for ${resetTarget.email}` });
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setResetLoading(false);
    }
  };

  const handleLoginAs = async (p: Photographer) => {
    if (!p.email) return;
    try {
      const result = await callAdminUsers({
        action: 'generate_login_link',
        email: p.email,
      });
      if (result.link) {
        window.open(result.link, '_blank');
        toast({ title: 'Login link opened', description: `Logged in as ${p.email} in new tab` });
      }
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    }
  };

  const copyText = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied to clipboard' });
  };

  const filtered = photographers.filter((p) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      (p.studio_name || '').toLowerCase().includes(q) ||
      (p.email || '').toLowerCase().includes(q)
    );
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold">Photographers</h1>
        <Button size="sm" className="gap-1.5 text-[12px]" onClick={() => {
          setAddForm({ name: '', email: '', password: generatePassword(), plan: 'free' });
          setCreatedCreds(null);
          setAddOpen(true);
        }}>
          <UserPlus className="h-3.5 w-3.5" />
          Add Photographer
        </Button>
      </div>

      {/* Search */}
      <div className="relative mb-4 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 h-9 text-[13px]"
        />
      </div>

      <div className="border border-border rounded-lg overflow-hidden">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/50">
            <tr>
              <th className="text-left px-4 py-2.5 font-medium">Studio</th>
              <th className="text-left px-4 py-2.5 font-medium">Email</th>
              <th className="text-left px-4 py-2.5 font-medium">Plan</th>
              <th className="text-left px-4 py-2.5 font-medium">Events</th>
              <th className="text-left px-4 py-2.5 font-medium">Photos</th>
              <th className="text-left px-4 py-2.5 font-medium">Joined</th>
              <th className="text-left px-4 py-2.5 font-medium">Status</th>
              <th className="text-right px-4 py-2.5 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-2.5 font-medium">{p.studio_name}</td>
                <td className="px-4 py-2.5 text-muted-foreground">{p.email || '—'}</td>
                <td className="px-4 py-2.5">
                  <select
                    value={p.plan}
                    onChange={(e) => updateProfile(p.user_id, { plan: e.target.value })}
                    className="bg-transparent border border-border rounded px-1.5 py-0.5 text-[12px]"
                  >
                    <option value="free">Free</option>
                    <option value="pro">Pro</option>
                  </select>
                </td>
                <td className="px-4 py-2.5">{p.event_count}</td>
                <td className="px-4 py-2.5">{p.photo_count}</td>
                <td className="px-4 py-2.5 text-muted-foreground">
                  {format(new Date(p.created_at), 'MMM d, yyyy')}
                </td>
                <td className="px-4 py-2.5">
                  {p.suspended ? (
                    <span className="text-destructive text-[11px] font-medium">Suspended</span>
                  ) : (
                    <span className="text-green-600 dark:text-green-400 text-[11px] font-medium">Active</span>
                  )}
                </td>
                <td className="px-4 py-2.5 text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="sm" variant="ghost" className="h-7 w-7 p-0">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuItem onClick={() => updateProfile(p.user_id, { suspended: !p.suspended })}>
                        {p.suspended ? '✅ Unsuspend' : '⚠️ Suspend'}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => {
                        setResetTarget(p);
                        setResetPassword(generatePassword());
                        setResetDone(false);
                        setResetOpen(true);
                      }}>
                        <KeyRound className="h-3.5 w-3.5 mr-2" />
                        Reset Password
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleLoginAs(p)}>
                        <LogIn className="h-3.5 w-3.5 mr-2" />
                        Login as Photographer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-muted-foreground">
                  {search ? 'No photographers match your search' : 'No photographers yet'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add Photographer Modal */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Photographer</DialogTitle>
          </DialogHeader>

          {createdCreds ? (
            <div className="space-y-4">
              <div className="bg-accent/10 border border-accent/30 rounded-lg p-4">
                <p className="text-sm font-medium text-foreground mb-3">
                  ✅ Account created! Share these credentials:
                </p>
                <div className="space-y-2 text-[13px]">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Email:</span>
                    <code className="bg-secondary px-2 py-0.5 rounded text-[12px]">{createdCreds.email}</code>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Password:</span>
                    <code className="bg-secondary px-2 py-0.5 rounded text-[12px]">{createdCreds.password}</code>
                  </div>
                </div>
              </div>
              <Button
                className="w-full gap-2"
                onClick={() => copyText(`Email: ${createdCreds.email}\nPassword: ${createdCreds.password}`)}
              >
                <Copy className="h-4 w-4" />
                Copy Credentials
              </Button>
              <Button variant="outline" className="w-full" onClick={() => setAddOpen(false)}>
                Done
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-[12px]">Full Name / Studio Name</Label>
                <Input
                  placeholder="Studio name"
                  value={addForm.name}
                  onChange={(e) => setAddForm((f) => ({ ...f, name: e.target.value }))}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Email</Label>
                <Input
                  type="email"
                  placeholder="photographer@example.com"
                  value={addForm.email}
                  onChange={(e) => setAddForm((f) => ({ ...f, email: e.target.value }))}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Password</Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type={showPwFor === 'add' ? 'text' : 'password'}
                      value={addForm.password}
                      onChange={(e) => setAddForm((f) => ({ ...f, password: e.target.value }))}
                      className="pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPwFor(showPwFor === 'add' ? null : 'add')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPwFor === 'add' ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => setAddForm((f) => ({ ...f, password: generatePassword() }))}
                    title="Auto-generate password"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Plan</Label>
                <div className="flex gap-2">
                  {['free', 'pro'].map((plan) => (
                    <button
                      key={plan}
                      onClick={() => setAddForm((f) => ({ ...f, plan }))}
                      className={`flex-1 px-3 py-2 rounded border text-[13px] font-medium transition-colors capitalize ${
                        addForm.plan === plan
                          ? 'border-primary bg-primary/10 text-primary'
                          : 'border-border text-muted-foreground hover:bg-secondary'
                      }`}
                    >
                      {plan}
                    </button>
                  ))}
                </div>
              </div>
              <Button className="w-full" onClick={handleAddPhotographer} disabled={addLoading || !addForm.email}>
                {addLoading ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Creating…</>
                ) : (
                  'Create Account'
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reset Password Modal */}
      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>

          {resetDone ? (
            <div className="space-y-4">
              <div className="bg-accent/10 border border-accent/30 rounded-lg p-4">
                <p className="text-sm font-medium text-foreground mb-3">
                  ✅ Password updated for {resetTarget?.email}
                </p>
                <div className="flex items-center justify-between text-[13px]">
                  <span className="text-muted-foreground">New Password:</span>
                  <code className="bg-secondary px-2 py-0.5 rounded text-[12px]">{resetPassword}</code>
                </div>
              </div>
              <Button className="w-full gap-2" onClick={() => copyText(resetPassword)}>
                <Copy className="h-4 w-4" />
                Copy Password
              </Button>
              <Button variant="outline" className="w-full" onClick={() => setResetOpen(false)}>
                Done
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-[13px] text-muted-foreground">
                Reset password for <span className="font-medium text-foreground">{resetTarget?.email}</span>
              </p>
              <div className="space-y-1.5">
                <Label className="text-[12px]">New Password</Label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Input
                      type={showPwFor === 'reset' ? 'text' : 'password'}
                      value={resetPassword}
                      onChange={(e) => setResetPassword(e.target.value)}
                      className="pr-9"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPwFor(showPwFor === 'reset' ? null : 'reset')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPwFor === 'reset' ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    onClick={() => setResetPassword(generatePassword())}
                    title="Auto-generate"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <Button className="w-full" onClick={handleResetPassword} disabled={resetLoading || !resetPassword}>
                {resetLoading ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Updating…</>
                ) : (
                  'Update Password'
                )}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
