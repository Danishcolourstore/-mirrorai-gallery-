import { useState, useEffect, useCallback } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Send, Clock, Users, Mail } from 'lucide-react';
import { format } from 'date-fns';

interface SentEmail {
  id: string;
  subject: string;
  sent_to: string;
  recipient_count: number;
  sent_at: string;
}

const AdminBulkEmail = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sendTo, setSendTo] = useState('all');
  const [sending, setSending] = useState(false);
  const [history, setHistory] = useState<SentEmail[]>([]);

  const templates = [
    { label: 'New Feature', subject: '🚀 New Feature on MirrorAI', message: 'We are excited to announce...' },
    { label: 'Pro Plan Offer', subject: '✨ Special Pro Plan Offer', message: 'Upgrade to Pro and unlock...' },
    { label: 'Maintenance Notice', subject: '🔧 Scheduled Maintenance', message: 'We will be performing maintenance...' },
  ];

  const fetchHistory = useCallback(async () => {
    const { data } = await (supabase
      .from('admin_emails' as any)
      .select('*') as any)
      .order('sent_at', { ascending: false })
      .limit(20);
    if (data) setHistory(data as SentEmail[]);
  }, []);

  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  const handleSend = async () => {
    if (!subject || !message) return;
    setSending(true);

    // Get recipients count
    let query = supabase.from('profiles').select('email', { count: 'exact', head: true }) as any;
    if (sendTo === 'free') query = query.eq('plan', 'free');
    if (sendTo === 'pro') query = query.eq('plan', 'pro');
    const { count } = await query;

    // Log the email
    await (supabase.from('admin_emails' as any).insert({
      subject,
      message,
      sent_to: sendTo,
      recipient_count: count || 0,
      sent_by: user?.id,
    }) as any);

    toast({ title: 'Email logged', description: `Would send to ${count || 0} photographers. Email delivery requires Resend integration.` });
    setSubject('');
    setMessage('');
    setSending(false);
    fetchHistory();
  };

  const sendToLabels: Record<string, string> = { all: 'All Photographers', free: 'Free Plan Only', pro: 'Pro Plan Only' };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-serif text-lg font-semibold text-foreground">Email Photographers</h2>
        <p className="text-[11px] text-muted-foreground/50">Send announcements to photographers</p>
      </div>

      {/* Templates */}
      <div className="flex gap-2 flex-wrap">
        {templates.map(t => (
          <button key={t.label} onClick={() => { setSubject(t.subject); setMessage(t.message); }}
            className="px-3 py-1.5 rounded-full border border-border text-[10px] uppercase tracking-[0.06em] text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors">
            {t.label}
          </button>
        ))}
      </div>

      {/* Compose */}
      <div className="border border-border rounded-sm p-4 space-y-3">
        <Select value={sendTo} onValueChange={setSendTo}>
          <SelectTrigger className="h-9 text-[12px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Photographers</SelectItem>
            <SelectItem value="free">Free Plan Only</SelectItem>
            <SelectItem value="pro">Pro Plan Only</SelectItem>
          </SelectContent>
        </Select>
        <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject" className="h-9 text-[13px]" />
        <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Message..." className="min-h-[120px] text-[13px]" />
        <div className="flex gap-2">
          <Button onClick={handleSend} disabled={sending || !subject || !message}
            className="text-[11px] uppercase tracking-[0.08em] h-9">
            <Send className="mr-1.5 h-3 w-3" /> {sending ? 'Sending...' : 'Send Email'}
          </Button>
        </div>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="border border-border rounded-sm">
          <div className="px-4 py-3 border-b border-border">
            <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/60 font-medium">Sent History</p>
          </div>
          <div className="divide-y divide-border">
            {history.map(e => (
              <div key={e.id} className="flex items-center justify-between px-4 py-3">
                <div>
                  <p className="text-[12px] text-foreground font-medium">{e.subject}</p>
                  <p className="text-[10px] text-muted-foreground/40">
                    {sendToLabels[e.sent_to] || e.sent_to} · {e.recipient_count} recipients
                  </p>
                </div>
                <p className="text-[10px] text-muted-foreground/40">{format(new Date(e.sent_at), 'MMM d, yyyy')}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminBulkEmail;
