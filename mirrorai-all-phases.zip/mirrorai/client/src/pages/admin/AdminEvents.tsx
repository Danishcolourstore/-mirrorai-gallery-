import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { Search, ArrowUpDown, ChevronUp, ChevronDown } from 'lucide-react';

interface AdminEvent {
  id: string;
  name: string;
  event_date: string;
  is_published: boolean;
  photo_count: number;
  views: number;
  user_id: string;
  photographer_name: string;
}

type SortKey = 'event_date' | 'photo_count' | 'views' | 'name';
type SortDir = 'asc' | 'desc';

async function fetchAllIds(table: 'photos' | 'event_views', column: string) {
  const ids: string[] = [];
  const PAGE = 1000;
  let from = 0;
  let hasMore = true;
  while (hasMore) {
    const { data } = await (supabase
      .from(table)
      .select(column)
      .range(from, from + PAGE - 1) as any);
    if (!data || data.length === 0) break;
    data.forEach((r: any) => ids.push(r[column]));
    hasMore = data.length === PAGE;
    from += PAGE;
  }
  return ids;
}

export default function AdminEvents() {
  const { toast } = useToast();
  const [events, setEvents] = useState<AdminEvent[]>([]);
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('event_date');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);

    const [evtsRes, profilesRes, photoEventIds, viewEventIds] = await Promise.all([
      supabase.from('events').select('id, name, event_date, is_published, user_id').order('created_at', { ascending: false }),
      supabase.from('profiles').select('user_id, studio_name'),
      fetchAllIds('photos', 'event_id'),
      fetchAllIds('event_views', 'event_id'),
    ]);

    const nameMap: Record<string, string> = {};
    (profilesRes.data || []).forEach((p: any) => { nameMap[p.user_id] = p.studio_name; });

    const photoCountMap: Record<string, number> = {};
    photoEventIds.forEach((eid) => { photoCountMap[eid] = (photoCountMap[eid] || 0) + 1; });

    const viewCountMap: Record<string, number> = {};
    viewEventIds.forEach((eid) => { viewCountMap[eid] = (viewCountMap[eid] || 0) + 1; });

    setEvents(
      (evtsRes.data || []).map((e: any) => ({
        ...e,
        photo_count: photoCountMap[e.id] || 0,
        views: viewCountMap[e.id] || 0,
        photographer_name: nameMap[e.user_id] || 'Unknown',
      }))
    );
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir('desc'); }
  };

  const SortIcon = ({ col }: { col: SortKey }) => {
    if (sortKey !== col) return <ArrowUpDown className="h-3 w-3 ml-1 opacity-30" />;
    return sortDir === 'asc' ? <ChevronUp className="h-3 w-3 ml-1" /> : <ChevronDown className="h-3 w-3 ml-1" />;
  };

  const filtered = useMemo(() => {
    let list = events;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter((e) =>
        e.name.toLowerCase().includes(q) || e.photographer_name.toLowerCase().includes(q)
      );
    }
    return [...list].sort((a, b) => {
      let cmp = 0;
      if (sortKey === 'event_date') cmp = new Date(a.event_date).getTime() - new Date(b.event_date).getTime();
      else if (sortKey === 'photo_count') cmp = a.photo_count - b.photo_count;
      else if (sortKey === 'views') cmp = a.views - b.views;
      else if (sortKey === 'name') cmp = a.name.localeCompare(b.name);
      return sortDir === 'asc' ? cmp : -cmp;
    });
  }, [events, search, sortKey, sortDir]);

  const unpublish = async (id: string) => {
    const { error } = await (supabase.from('events').update({ is_published: false }) as any).eq('id', id);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: 'Unpublished' }); load(); }
  };

  const publish = async (id: string) => {
    const { error } = await (supabase.from('events').update({ is_published: true }) as any).eq('id', id);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: 'Published' }); load(); }
  };

  const deleteEvent = async (id: string) => {
    const { error } = await supabase.from('events').delete().eq('id', id);
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else { toast({ title: 'Deleted' }); load(); }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold">All Events ({events.length})</h1>
      </div>

      <div className="relative mb-4 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by event or photographer..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 h-9 text-[13px]"
        />
      </div>

      <div className="border border-border rounded-lg overflow-x-auto">
        <table className="w-full text-[13px]">
          <thead className="bg-secondary/50">
            <tr>
              <th className="text-left px-4 py-2.5 font-medium cursor-pointer select-none" onClick={() => toggleSort('name')}>
                <span className="inline-flex items-center">Event <SortIcon col="name" /></span>
              </th>
              <th className="text-left px-4 py-2.5 font-medium">Photographer</th>
              <th className="text-left px-4 py-2.5 font-medium cursor-pointer select-none" onClick={() => toggleSort('event_date')}>
                <span className="inline-flex items-center">Date <SortIcon col="event_date" /></span>
              </th>
              <th className="text-left px-4 py-2.5 font-medium cursor-pointer select-none" onClick={() => toggleSort('photo_count')}>
                <span className="inline-flex items-center">Photos <SortIcon col="photo_count" /></span>
              </th>
              <th className="text-left px-4 py-2.5 font-medium cursor-pointer select-none" onClick={() => toggleSort('views')}>
                <span className="inline-flex items-center">Views <SortIcon col="views" /></span>
              </th>
              <th className="text-left px-4 py-2.5 font-medium">Published</th>
              <th className="text-right px-4 py-2.5 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">Loading…</td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center text-muted-foreground">
                  {search ? 'No events match your search' : 'No events yet'}
                </td>
              </tr>
            ) : (
              filtered.map((e) => (
                <tr key={e.id}>
                  <td className="px-4 py-2.5 font-medium">{e.name}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{e.photographer_name}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">
                    {format(new Date(e.event_date), 'MMM d, yyyy')}
                  </td>
                  <td className="px-4 py-2.5">{e.photo_count}</td>
                  <td className="px-4 py-2.5">{e.views}</td>
                  <td className="px-4 py-2.5">
                    {e.is_published ? (
                      <span className="text-green-600 dark:text-green-400 text-[11px] font-medium">Yes</span>
                    ) : (
                      <span className="text-muted-foreground text-[11px]">No</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 text-right space-x-1">
                    {e.is_published ? (
                      <Button size="sm" variant="ghost" className="text-[11px] h-7" onClick={() => unpublish(e.id)}>
                        Unpublish
                      </Button>
                    ) : (
                      <Button size="sm" variant="ghost" className="text-[11px] h-7" onClick={() => publish(e.id)}>
                        Publish
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-[11px] h-7 text-destructive"
                      onClick={() => deleteEvent(e.id)}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
