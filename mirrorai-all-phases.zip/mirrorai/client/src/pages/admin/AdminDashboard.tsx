import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { StatCard } from '@/components/StatCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Eye, Users, Camera, Image, Heart, Radio } from 'lucide-react';
import {
  ChartContainer, ChartTooltip, ChartTooltipContent,
} from '@/components/ui/chart';
import { LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts';
import { format, subDays, eachDayOfInterval } from 'date-fns';

export default function AdminDashboard() {
  const [stats, setStats] = useState({ photographers: 0, events: 0, photos: 0, guests: 0, favorites: 0, liveEvents: 0, livePhotosToday: 0 });
  const [views, setViews] = useState<any[]>([]);
  const [topGalleries, setTopGalleries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const [p, e, ph, g, f] = await Promise.all([
        (supabase.from('profiles').select('id', { count: 'exact', head: true }) as any),
        (supabase.from('events').select('id', { count: 'exact', head: true }) as any),
        (supabase.from('photos').select('id', { count: 'exact', head: true }) as any),
        (supabase.from('guest_sessions').select('id', { count: 'exact', head: true }) as any),
        (supabase.from('favorites').select('id', { count: 'exact', head: true }) as any),
      ]);
      // Live events count
      const { count: liveCount } = await supabase.from('events').select('id', { count: 'exact', head: true }).eq('camera_connected', true);
      
      setStats({
        photographers: (p as any).count ?? 0,
        events: (e as any).count ?? 0,
        photos: (ph as any).count ?? 0,
        guests: (g as any).count ?? 0,
        favorites: (f as any).count ?? 0,
        liveEvents: liveCount ?? 0,
        livePhotosToday: 0,
      });

      // Get views from last 30 days
      const since = subDays(new Date(), 30).toISOString();
      const { data: viewData } = await (supabase.from('event_views' as any).select('*') as any).gte('created_at', since);
      setViews(viewData || []);

      // Top galleries by view count
      const { data: allViews } = await (supabase.from('event_views' as any).select('event_id') as any);
      if (allViews) {
        const counts: Record<string, number> = {};
        (allViews as any[]).forEach(v => { counts[v.event_id] = (counts[v.event_id] || 0) + 1; });
        const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10);
        
        // Fetch event names
        const eventIds = sorted.map(([id]) => id);
        if (eventIds.length > 0) {
          const { data: events } = await supabase.from('events').select('id, name, user_id').in('id', eventIds);
          const eventMap: Record<string, any> = {};
          (events || []).forEach((ev: any) => { eventMap[ev.id] = ev; });
          
          // Get photographer names
          const userIds = [...new Set((events || []).map((ev: any) => ev.user_id))];
          const { data: profiles } = await (supabase.from('profiles').select('user_id, studio_name') as any).in('user_id', userIds);
          const profileMap: Record<string, string> = {};
          (profiles || []).forEach((p: any) => { profileMap[p.user_id] = p.studio_name; });

          setTopGalleries(sorted.map(([id, count]) => ({
            id, count,
            name: eventMap[id]?.name || 'Unknown',
            photographer: profileMap[eventMap[id]?.user_id] || 'Unknown',
          })));
        }
      }

      setLoading(false);
    };
    load();
  }, []);

  const viewsByDay = useMemo(() => {
    const interval = eachDayOfInterval({ start: subDays(new Date(), 29), end: new Date() });
    const counts: Record<string, number> = {};
    interval.forEach(d => counts[format(d, 'MMM dd')] = 0);
    views.forEach((v: any) => {
      const key = format(new Date(v.created_at), 'MMM dd');
      if (key in counts) counts[key]++;
    });
    return Object.entries(counts).map(([date, count]) => ({ date, count }));
  }, [views]);

  const todayViews = useMemo(() => {
    const today = format(new Date(), 'yyyy-MM-dd');
    return views.filter((v: any) => v.created_at.startsWith(today)).length;
  }, [views]);

  const chartConfig = { count: { label: 'Views', color: 'hsl(var(--primary))' } };

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-xl font-bold">Platform Overview</h1>
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-bold">Platform Overview</h1>

      {/* MirrorLive Status */}
      {stats.liveEvents > 0 && (
        <div className="rounded-xl bg-gradient-to-r from-[hsl(0,10%,8%)] to-[hsl(0,5%,14%)] border border-[hsl(0,84%,55%)]/20 p-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-full bg-[hsl(0,84%,55%)]/15 flex items-center justify-center">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[hsl(0,84%,55%)] opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-[hsl(0,84%,55%)]" />
              </span>
            </div>
            <div>
              <p className="text-white text-sm font-bold">MirrorLive Active</p>
              <p className="text-white/40 text-xs">{stats.liveEvents} event{stats.liveEvents !== 1 ? 's' : ''} streaming live right now</p>
            </div>
          </div>
          <Radio className="h-5 w-5 text-[hsl(0,84%,55%)]" />
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <StatCard label="Photographers" value={stats.photographers} icon={<Users className="h-5 w-5" />} />
        <StatCard label="Events" value={stats.events} icon={<Camera className="h-5 w-5" />} />
        <StatCard label="Photos" value={stats.photos} icon={<Image className="h-5 w-5" />} />
        <StatCard label="Views Today" value={todayViews} icon={<Eye className="h-5 w-5" />} />
        <StatCard label="Total Favorites" value={stats.favorites} icon={<Heart className="h-5 w-5" />} />
      </div>

      {/* Views chart */}
      <div className="bg-card border border-border/50 p-5">
        <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/60 mb-4">Platform Views — Last 30 Days</p>
        <ChartContainer config={chartConfig} className="h-[250px] w-full">
          <LineChart data={viewsByDay}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="date" tick={{ fontSize: 10 }} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Line type="monotone" dataKey="count" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
          </LineChart>
        </ChartContainer>
      </div>

      {/* Top galleries */}
      {topGalleries.length > 0 && (
        <div className="bg-card border border-border/50 p-5">
          <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/60 mb-4">Most Viewed Galleries</p>
          <div className="overflow-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr className="border-b border-border/50">
                  <th className="text-left py-2 text-muted-foreground font-medium">#</th>
                  <th className="text-left py-2 text-muted-foreground font-medium">Gallery</th>
                  <th className="text-left py-2 text-muted-foreground font-medium">Photographer</th>
                  <th className="text-right py-2 text-muted-foreground font-medium">Views</th>
                </tr>
              </thead>
              <tbody>
                {topGalleries.map((g, i) => (
                  <tr key={g.id} className="border-b border-white/[0.06] hover:bg-gold/[0.04] transition-colors">
                    <td className="py-2 text-muted-foreground">{i + 1}</td>
                    <td className="py-2 font-medium">{g.name}</td>
                    <td className="py-2 text-muted-foreground">{g.photographer}</td>
                    <td className="py-2 text-right font-medium">{g.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
