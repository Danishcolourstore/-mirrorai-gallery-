import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { OtpInput } from '@/components/OtpInput';
import { Fingerprint, Mail, ArrowRight, ShieldCheck, Loader2 } from 'lucide-react';

const ADMIN_EMAILS = (import.meta.env.VITE_ADMIN_EMAIL || 'danishsubair@gmail.com,lutstoreindia@gmail.com,mirrorai2050@gmail.com,danishcam43@gmail.com')
  .split(',').map((e: string) => e.trim().toLowerCase());

type Step = 'check' | 'fingerprint' | 'email' | 'otp' | 'register-fp' | 'success';

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  return btoa(String.fromCharCode(...new Uint8Array(buffer)));
}
function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer;
}

function logActivity(email: string, action: string) {
  supabase.from('admin_activity_log').insert({
    user_email: email,
    action,
    device_info: navigator.userAgent.slice(0, 200),
  } as any).then(() => {});
}

export default function AdminLogin() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('check');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [otpLoading, setOtpLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const [attempts, setAttempts] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const [fpRetries, setFpRetries] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval>>();

  const hasCredential = !!localStorage.getItem('admin_credential_id');

  // Check existing session
  useEffect(() => {
    if (loading) return;
    if (user) {
      // Check if admin
      supabase.from('user_roles').select('role').eq('user_id', user.id).eq('role', 'admin')
        .then(({ data }) => {
          if (data && data.length > 0) {
            if (hasCredential) {
              setStep('fingerprint');
            } else {
              navigate('/admin');
            }
          } else {
            setStep('email');
          }
        });
    } else {
      setStep(hasCredential ? 'fingerprint' : 'email');
    }
  }, [user, loading, navigate, hasCredential]);

  // Resend countdown
  useEffect(() => {
    if (resendTimer > 0) {
      timerRef.current = setInterval(() => setResendTimer(t => t <= 1 ? 0 : t - 1), 1000);
      return () => clearInterval(timerRef.current);
    }
  }, [resendTimer]);

  // Lockout check
  useEffect(() => {
    if (lockedUntil && Date.now() < lockedUntil) {
      const id = setTimeout(() => setLockedUntil(null), lockedUntil - Date.now());
      return () => clearTimeout(id);
    }
  }, [lockedUntil]);

  const webAuthnSupported = !!window.PublicKeyCredential;

  // ─── FINGERPRINT AUTH ───
  const triggerFingerprint = useCallback(async () => {
    if (!webAuthnSupported) { setStep('email'); return; }
    const credId = localStorage.getItem('admin_credential_id');
    if (!credId) { setStep('email'); return; }

    try {
      const credential = await navigator.credentials.get({
        publicKey: {
          challenge: crypto.getRandomValues(new Uint8Array(32)),
          allowCredentials: [{
            id: base64ToArrayBuffer(credId),
            type: 'public-key' as const,
            transports: ['internal' as AuthenticatorTransport],
          }],
          userVerification: 'required',
          timeout: 60000,
        },
      });

      if (credential) {
        logActivity(user?.email || 'admin', 'fingerprint_auth');
        // If we have a valid session, go straight in
        if (user) {
          setStep('success');
          setTimeout(() => navigate('/admin'), 600);
        } else {
          // No session - need OTP
          setStep('email');
        }
      }
    } catch {
      setFpRetries(r => r + 1);
      if (fpRetries >= 4) {
        setStep('email');
        setError('Too many attempts. Use email to verify.');
        logActivity('admin', 'fingerprint_lockout');
      }
    }
  }, [webAuthnSupported, user, navigate, fpRetries]);

  // Auto-trigger fingerprint
  useEffect(() => {
    if (step === 'fingerprint') {
      const t = setTimeout(triggerFingerprint, 500);
      return () => clearTimeout(t);
    }
  }, [step, triggerFingerprint]);

  // ─── SEND OTP ───
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const normalized = email.trim().toLowerCase();

    if (!ADMIN_EMAILS.includes(normalized)) {
      setError('Access denied');
      logActivity(normalized, 'login_denied');
      return;
    }

    if (lockedUntil && Date.now() < lockedUntil) {
      setError('Too many attempts. Try later.');
      return;
    }

    setOtpLoading(true);
    try {
      const { error: otpErr } = await supabase.auth.signInWithOtp({
        email: normalized,
        options: { shouldCreateUser: false },
      });
      if (otpErr) {
        setError(otpErr.message);
        logActivity(normalized, 'otp_send_failed');
      } else {
        setStep('otp');
        setResendTimer(30);
        logActivity(normalized, 'otp_sent');
      }
    } finally {
      setOtpLoading(false);
    }
  };

  // ─── VERIFY OTP ───
  const handleVerifyOtp = async (code: string) => {
    setError('');
    if (lockedUntil && Date.now() < lockedUntil) {
      setError('Account locked. Try later.');
      return;
    }

    setOtpLoading(true);
    try {
      const { data, error: verifyErr } = await supabase.auth.verifyOtp({
        email: email.trim().toLowerCase(),
        token: code,
        type: 'email',
      });

      if (verifyErr) {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        logActivity(email, 'otp_failed');

        if (newAttempts >= 3) {
          const lockTime = Date.now() + 30 * 60 * 1000;
          setLockedUntil(lockTime);
          setError('Too many attempts. Locked for 30 minutes.');
          logActivity(email, 'locked_out');
          setStep('email');
        } else if (verifyErr.message.includes('expired')) {
          setError('Code expired. Request a new one.');
        } else {
          setError('Incorrect code. Try again.');
        }
        return;
      }

      if (data?.user) {
        logActivity(email, 'login_success');
        setAttempts(0);
        // Check admin role
        const { data: roles } = await supabase.from('user_roles').select('role')
          .eq('user_id', data.user.id).eq('role', 'admin');
        if (!roles || roles.length === 0) {
          setError('Access denied');
          await supabase.auth.signOut();
          return;
        }

        // Offer fingerprint registration if supported and not registered
        if (webAuthnSupported && !hasCredential) {
          setStep('register-fp');
        } else {
          setStep('success');
          setTimeout(() => navigate('/admin'), 600);
        }
      }
    } finally {
      setOtpLoading(false);
    }
  };

  // ─── REGISTER FINGERPRINT ───
  const registerFingerprint = async () => {
    try {
      const credential = await navigator.credentials.create({
        publicKey: {
          challenge: crypto.getRandomValues(new Uint8Array(32)),
          rp: { name: 'MirrorAI Admin', id: window.location.hostname },
          user: {
            id: crypto.getRandomValues(new Uint8Array(16)),
            name: 'admin',
            displayName: 'MirrorAI Admin',
          },
          pubKeyCredParams: [{ alg: -7, type: 'public-key' as const }],
          authenticatorSelection: {
            authenticatorAttachment: 'platform',
            userVerification: 'required',
          },
          timeout: 60000,
        },
      });

      if (credential && 'rawId' in credential) {
        const credId = arrayBufferToBase64((credential as PublicKeyCredential).rawId);
        localStorage.setItem('admin_credential_id', credId);

        // Save to DB
        if (user) {
          await supabase.from('admin_credentials').insert({
            user_id: user.id,
            credential_id: credId,
          } as any);
        }

        logActivity(email || user?.email || 'admin', 'fingerprint_registered');
        setStep('success');
        setTimeout(() => navigate('/admin'), 1200);
      }
    } catch {
      // User cancelled - skip
      setStep('success');
      setTimeout(() => navigate('/admin'), 600);
    }
  };

  // ─── RESEND OTP ───
  const handleResend = async () => {
    if (resendTimer > 0) return;
    setError('');
    setOtpLoading(true);
    try {
      await supabase.auth.signInWithOtp({
        email: email.trim().toLowerCase(),
        options: { shouldCreateUser: false },
      });
      setResendTimer(30);
    } finally {
      setOtpLoading(false);
    }
  };

  // ─── RENDER ───
  if (step === 'check') {
    return (
      <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center">
        <Loader2 className="h-6 w-6 text-[#C9A96E] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0D0D0D] flex items-center justify-center px-4">
      <div className="w-full max-w-sm text-center">

        {/* ── FINGERPRINT SCREEN ── */}
        {step === 'fingerprint' && (
          <div className="space-y-8 animate-fade-in">
            <div className="relative inline-block">
              <Fingerprint className="h-20 w-20 text-[#C9A96E] mx-auto animate-pulse" />
              <div className="absolute inset-0 rounded-full"
                style={{ boxShadow: '0 0 60px rgba(201,169,110,0.3), 0 0 120px rgba(201,169,110,0.15)' }} />
            </div>
            <p className="text-white/60 text-sm font-sans tracking-wide">
              Place your finger to continue
            </p>
            {fpRetries > 0 && fpRetries < 5 && (
              <p className="text-red-400 text-xs">Try again</p>
            )}
            <button
              onClick={() => { setStep('email'); setError(''); }}
              className="text-white/20 text-[11px] tracking-widest uppercase hover:text-white/40 transition-colors"
            >
              Use email instead →
            </button>
          </div>
        )}

        {/* ── EMAIL SCREEN ── */}
        {step === 'email' && (
          <form onSubmit={handleSendOtp} className="space-y-8 animate-fade-in">
            <div className="space-y-1">
              <div className="w-10 h-10 mx-auto rounded-full bg-[#C9A96E]/20 flex items-center justify-center mb-6">
                <ShieldCheck className="h-5 w-5 text-[#C9A96E]" />
              </div>
              <h1 className="font-['Cormorant_Garamond'] text-3xl text-white font-light tracking-wide">
                Admin Access
              </h1>
            </div>

            <div className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
                autoFocus
                className="w-full bg-white/5 border border-white/10 focus:border-[#C9A96E] text-white placeholder:text-white/25 rounded-lg px-4 py-3 text-sm outline-none transition-colors"
              />
              <button
                type="submit"
                disabled={otpLoading || !email}
                className="w-full bg-[#C9A96E] text-[#0D0D0D] font-medium py-3 rounded-lg text-sm flex items-center justify-center gap-2 hover:bg-[#B8935A] transition-colors disabled:opacity-50"
              >
                {otpLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <>Send OTP <ArrowRight className="h-4 w-4" /></>}
              </button>
            </div>

            {error && <p className="text-red-400 text-xs">{error}</p>}

            <p className="text-white/25 text-[11px] tracking-wide">
              A 6 digit code will be sent to your email
            </p>
          </form>
        )}

        {/* ── OTP SCREEN ── */}
        {step === 'otp' && (
          <div className="space-y-8 animate-fade-in">
            <div className="space-y-2">
              <Mail className="h-8 w-8 text-[#C9A96E] mx-auto mb-4" />
              <h2 className="font-['Cormorant_Garamond'] text-2xl text-white font-light">
                Check your email
              </h2>
              <p className="text-white/40 text-xs">
                We sent a 6 digit code to<br />
                <span className="text-white/60">{email}</span>
              </p>
            </div>

            <div className={error && error.includes('Incorrect') ? 'animate-shake' : ''}>
              <OtpInput
                length={6}
                onComplete={handleVerifyOtp}
                disabled={otpLoading}
              />
            </div>

            {error && <p className="text-red-400 text-xs">{error}</p>}
            {otpLoading && <Loader2 className="h-4 w-4 text-[#C9A96E] animate-spin mx-auto" />}

            <div>
              {resendTimer > 0 ? (
                <p className="text-white/25 text-[11px]">Resend in 0:{resendTimer.toString().padStart(2, '0')}</p>
              ) : (
                <button onClick={handleResend} className="text-[#C9A96E]/60 text-[11px] hover:text-[#C9A96E] transition-colors">
                  Resend code
                </button>
              )}
            </div>

            <button
              onClick={() => { setStep('email'); setError(''); }}
              className="text-white/20 text-[11px] tracking-widest uppercase hover:text-white/40 transition-colors"
            >
              ← Back
            </button>
          </div>
        )}

        {/* ── REGISTER FINGERPRINT ── */}
        {step === 'register-fp' && (
          <div className="space-y-8 animate-fade-in">
            <Fingerprint className="h-16 w-16 text-[#C9A96E] mx-auto" />
            <div className="space-y-2">
              <h2 className="font-['Cormorant_Garamond'] text-2xl text-white font-light">
                Secure your access
              </h2>
              <p className="text-white/40 text-xs font-sans">
                Register your fingerprint so you<br />never need OTP again
              </p>
            </div>

            <button
              onClick={registerFingerprint}
              className="w-full bg-[#C9A96E] text-[#0D0D0D] font-medium py-3 rounded-lg text-sm hover:bg-[#B8935A] transition-colors"
            >
              Register Fingerprint
            </button>

            <button
              onClick={() => { setStep('success'); setTimeout(() => navigate('/admin'), 600); }}
              className="text-white/20 text-[11px] tracking-widest uppercase hover:text-white/40 transition-colors"
            >
              Skip for now →
            </button>
          </div>
        )}

        {/* ── SUCCESS ── */}
        {step === 'success' && (
          <div className="space-y-4 animate-fade-in">
            <div className="w-16 h-16 mx-auto rounded-full bg-[#C9A96E]/20 flex items-center justify-center">
              <ShieldCheck className="h-8 w-8 text-[#C9A96E]" />
            </div>
            <p className="text-white/60 text-sm">
              {hasCredential ? 'Fingerprint registered! 🤍' : 'Welcome back'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
