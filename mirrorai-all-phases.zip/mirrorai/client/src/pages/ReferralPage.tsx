import { useState, useEffect, useCallback } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Copy, Gift, Users, Crown, Share2 } from 'lucide-react';
import { format } from 'date-fns';

interface Referral {
  id: string;
  referred_id: string | null;
  reward_given: boolean;
  created_at: string;
  referred_name?: string;
}

const ReferralPage = () => {
  const { user, studioName } = useAuth();
  const { toast } = useToast();
  const [referralCode, setReferralCode] = useState<string | null>(null);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    if (!user) return;
    // Get referral code
    const { data: profile } = await (supabase
      .from('profiles')
      .select('referral_code') as any)
      .eq('user_id', user.id)
      .single();
    if (profile) setReferralCode((profile as any).referral_code);

    // Get referrals
    const { data: refs } = await (supabase
      .from('referrals' as any)
      .select('*') as any)
      .eq('referrer_id', user.id)
      .order('created_at', { ascending: false });
    if (refs) setReferrals(refs as Referral[]);
    setLoading(false);
  }, [user]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const referralLink = referralCode ? `${window.location.origin}/register?ref=${referralCode}` : '';

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({ title: 'Referral link copied!' });
  };

  const shareWhatsApp = () => {
    const text = `Hey! I use MirrorAI for my photography galleries and my clients love it. Try it here and get 3 months Pro for just ₹999:\n${referralLink}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const successfulRefs = referrals.filter(r => r.referred_id);
  const monthsEarned = referrals.filter(r => r.reward_given).length * 3;

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto">
        <h1 className="font-serif text-xl font-semibold text-foreground mb-1">Refer & Earn</h1>
        <p className="text-[12px] text-muted-foreground/60 mb-6">
          Invite photographers and earn free Pro months
        </p>

        {/* Reward info */}
        <div className="border border-primary/20 bg-primary/5 rounded-sm p-5 mb-6">
          <div className="flex items-start gap-3">
            <Gift className="h-5 w-5 text-primary mt-0.5 shrink-0" />
            <div>
              <h3 className="font-serif text-[15px] font-medium text-foreground">How it works</h3>
              <ul className="mt-2 space-y-1 text-[12px] text-muted-foreground">
                <li>• Share your unique referral link with other photographers</li>
                <li>• When they sign up and subscribe, <span className="text-primary font-medium">you get +3 months Pro free</span></li>
                <li>• They get their <span className="text-primary font-medium">first 3 months for ₹999</span> (instead of ₹3750)</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Referral link */}
        <div className="border border-border rounded-sm p-4 mb-6">
          <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/60 font-medium mb-2">Your Referral Link</p>
          <div className="flex gap-2">
            <Input value={referralLink} readOnly className="bg-background h-9 text-[12px] font-mono" />
            <Button variant="outline" size="icon" className="h-9 w-9 shrink-0" onClick={copyLink}>
              <Copy className="h-3.5 w-3.5" />
            </Button>
          </div>
          <div className="flex gap-2 mt-3">
            <Button variant="outline" size="sm" onClick={shareWhatsApp}
              className="text-[10px] h-8 uppercase tracking-[0.06em]">
              <Share2 className="mr-1.5 h-3 w-3" /> Share on WhatsApp
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="border border-border rounded-sm p-4 text-center">
            <p className="font-serif text-2xl font-semibold text-primary">{referrals.length}</p>
            <p className="text-[10px] text-muted-foreground/50 uppercase tracking-wide mt-1">Referred</p>
          </div>
          <div className="border border-border rounded-sm p-4 text-center">
            <p className="font-serif text-2xl font-semibold text-primary">{successfulRefs.length}</p>
            <p className="text-[10px] text-muted-foreground/50 uppercase tracking-wide mt-1">Signed Up</p>
          </div>
          <div className="border border-border rounded-sm p-4 text-center">
            <p className="font-serif text-2xl font-semibold text-primary">{monthsEarned}</p>
            <p className="text-[10px] text-muted-foreground/50 uppercase tracking-wide mt-1">Months Earned</p>
          </div>
        </div>

        {/* Referrals table */}
        {referrals.length > 0 && (
          <div className="border border-border rounded-sm">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground/60 font-medium">Referral History</p>
            </div>
            <div className="divide-y divide-border">
              {referrals.map(r => (
                <div key={r.id} className="flex items-center justify-between px-4 py-3">
                  <div>
                    <p className="text-[12px] text-foreground">{r.referred_name || 'Pending...'}</p>
                    <p className="text-[10px] text-muted-foreground/40">{format(new Date(r.created_at), 'MMM d, yyyy')}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    {r.referred_id ? (
                      <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium">Joined</span>
                    ) : (
                      <span className="text-[10px] bg-muted text-muted-foreground px-2 py-0.5 rounded-full">Pending</span>
                    )}
                    {r.reward_given && (
                      <span className="text-[10px] text-primary flex items-center gap-0.5">
                        <Crown className="h-3 w-3" /> +3 mo
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ReferralPage;
