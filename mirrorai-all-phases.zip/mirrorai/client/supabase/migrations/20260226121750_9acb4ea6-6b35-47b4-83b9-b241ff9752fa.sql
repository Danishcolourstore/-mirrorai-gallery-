
CREATE TABLE public.shoots (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  client_name text NOT NULL DEFAULT '',
  shoot_type text NOT NULL DEFAULT 'Wedding',
  shoot_date date NOT NULL DEFAULT CURRENT_DATE,
  start_time time,
  end_time time,
  location text,
  map_link text,
  shoot_vibe text,
  shot_list text,
  outfit_props text,
  mood_board_links text[] DEFAULT '{}',
  color_palette text[] DEFAULT '{}',
  reminder_timing text,
  status text NOT NULL DEFAULT 'confirmed',
  color_tag text NOT NULL DEFAULT '#C9A96E',
  event_id uuid REFERENCES public.events(id) ON DELETE SET NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.shoots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own shoots" ON public.shoots FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_shoots_updated_at BEFORE UPDATE ON public.shoots FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
