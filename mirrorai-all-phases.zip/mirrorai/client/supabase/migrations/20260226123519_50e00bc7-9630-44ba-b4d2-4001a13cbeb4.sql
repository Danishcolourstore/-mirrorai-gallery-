
ALTER TABLE public.studio_profiles 
  ADD COLUMN IF NOT EXISTS hero_sections_enabled jsonb NOT NULL DEFAULT '{"about": false, "portfolio": false, "services": false, "testimonials": false, "instagram": false}'::jsonb,
  ADD COLUMN IF NOT EXISTS button_text text NOT NULL DEFAULT 'See your forever. 🤍',
  ADD COLUMN IF NOT EXISTS button_position text NOT NULL DEFAULT 'floating',
  ADD COLUMN IF NOT EXISTS button_style text NOT NULL DEFAULT 'gold',
  ADD COLUMN IF NOT EXISTS about_portrait_url text,
  ADD COLUMN IF NOT EXISTS about_bio text,
  ADD COLUMN IF NOT EXISTS about_name text,
  ADD COLUMN IF NOT EXISTS whatsapp_button_text text NOT NULL DEFAULT 'Book a Shoot';
