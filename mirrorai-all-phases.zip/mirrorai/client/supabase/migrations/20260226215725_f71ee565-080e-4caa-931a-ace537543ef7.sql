
-- Create RPC to increment live_photo_count atomically
CREATE OR REPLACE FUNCTION public.increment_live_photo_count(event_id_param uuid)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  UPDATE events 
  SET live_photo_count = live_photo_count + 1
  WHERE id = event_id_param;
$$;

-- Ensure photos table is in realtime publication (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables 
    WHERE pubname = 'supabase_realtime' AND tablename = 'photos'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.photos;
  END IF;
END $$;
