ALTER TABLE events ADD COLUMN IF NOT EXISTS gallery_mode text DEFAULT 'mirrorai';

-- Use a trigger for validation instead of CHECK constraint
CREATE OR REPLACE FUNCTION public.validate_gallery_mode()
RETURNS trigger
LANGUAGE plpgsql
SET search_path TO 'public'
AS $function$
BEGIN
  IF NEW.gallery_mode NOT IN ('mirrorai', 'studio') THEN
    RAISE EXCEPTION 'gallery_mode must be mirrorai or studio';
  END IF;
  RETURN NEW;
END;
$function$;

CREATE TRIGGER validate_gallery_mode_trigger
  BEFORE INSERT OR UPDATE ON events
  FOR EACH ROW
  EXECUTE FUNCTION public.validate_gallery_mode();