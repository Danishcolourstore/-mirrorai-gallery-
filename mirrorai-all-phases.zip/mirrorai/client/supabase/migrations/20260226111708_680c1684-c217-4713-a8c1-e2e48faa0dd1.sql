
-- Add album selection columns to events
ALTER TABLE public.events
  ADD COLUMN IF NOT EXISTS album_selection_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS album_min_photos integer NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS album_max_photos integer NOT NULL DEFAULT 50,
  ADD COLUMN IF NOT EXISTS album_message text,
  ADD COLUMN IF NOT EXISTS album_deadline date,
  ADD COLUMN IF NOT EXISTS album_require_contact boolean NOT NULL DEFAULT false;

-- Album selections table
CREATE TABLE public.album_selections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  client_name text NOT NULL DEFAULT '',
  client_phone text NOT NULL DEFAULT '',
  selected_photo_ids uuid[] NOT NULL DEFAULT '{}',
  selection_order jsonb NOT NULL DEFAULT '[]',
  submitted_at timestamptz NOT NULL DEFAULT now(),
  is_reviewed boolean NOT NULL DEFAULT false,
  reviewed_at timestamptz
);

ALTER TABLE public.album_selections ENABLE ROW LEVEL SECURITY;

-- Anon can insert (clients not logged in)
CREATE POLICY "Anyone can insert album selections"
  ON public.album_selections FOR INSERT
  WITH CHECK (true);

-- Anon can read own submissions (by event)
CREATE POLICY "Anyone can read album selections"
  ON public.album_selections FOR SELECT
  USING (true);

-- Owners can update (mark as reviewed)
CREATE POLICY "Event owners can update album selections"
  ON public.album_selections FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.events
      WHERE events.id = album_selections.event_id
        AND events.user_id = auth.uid()
    )
  );

-- Admins can read all
CREATE POLICY "Admins can read all album selections"
  ON public.album_selections FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE INDEX idx_album_selections_event_id ON public.album_selections(event_id);
