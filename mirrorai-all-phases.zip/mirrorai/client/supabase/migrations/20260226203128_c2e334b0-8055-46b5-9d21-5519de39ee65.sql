
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS brand_name text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS brand_logo_url text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS brand_color text DEFAULT '#C4956A';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS brand_font text DEFAULT 'Cormorant Garamond';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS watermark_text text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS watermark_position text DEFAULT 'bottom-right';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS gallery_cover_style text DEFAULT 'cinematic';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS social_instagram text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS social_website text;
