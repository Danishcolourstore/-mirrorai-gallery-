
-- Photo comments table
CREATE TABLE public.photo_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  photo_id uuid NOT NULL REFERENCES public.photos(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  guest_name text NOT NULL DEFAULT 'Guest',
  comment text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.photo_comments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert comments" ON public.photo_comments FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can read comments" ON public.photo_comments FOR SELECT USING (true);
CREATE POLICY "Event owners can update comments" ON public.photo_comments FOR UPDATE USING (
  EXISTS (SELECT 1 FROM events WHERE events.id = photo_comments.event_id AND events.user_id = auth.uid())
);
CREATE POLICY "Event owners can delete comments" ON public.photo_comments FOR DELETE USING (
  EXISTS (SELECT 1 FROM events WHERE events.id = photo_comments.event_id AND events.user_id = auth.uid())
);
CREATE POLICY "Admins can manage comments" ON public.photo_comments FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Referrals table
CREATE TABLE public.referrals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id uuid NOT NULL,
  referred_id uuid,
  reward_given boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own referrals" ON public.referrals FOR SELECT USING (referrer_id = auth.uid() OR referred_id = auth.uid());
CREATE POLICY "Admins can manage referrals" ON public.referrals FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Anyone can insert referrals" ON public.referrals FOR INSERT WITH CHECK (true);

-- Admin emails table
CREATE TABLE public.admin_emails (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject text NOT NULL,
  message text NOT NULL,
  sent_to text NOT NULL DEFAULT 'all',
  recipient_count integer NOT NULL DEFAULT 0,
  sent_by uuid,
  sent_at timestamp with time zone NOT NULL DEFAULT now()
);
ALTER TABLE public.admin_emails ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage emails" ON public.admin_emails FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Add columns to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS referral_code text UNIQUE;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS referred_by uuid;

-- Add columns to events
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS delivery_status text NOT NULL DEFAULT 'ready';
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS status_updated_at timestamp with time zone;
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS expires_at timestamp with time zone;

-- Generate referral codes for existing profiles
UPDATE public.profiles SET referral_code = UPPER(SUBSTR(REPLACE(gen_random_uuid()::text, '-', ''), 1, 8)) WHERE referral_code IS NULL;
