
-- Add live camera fields to events table
ALTER TABLE public.events
  ADD COLUMN IF NOT EXISTS ftp_password text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS camera_connected boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS camera_model text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS last_photo_at timestamptz DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS live_photo_count integer NOT NULL DEFAULT 0;

-- Enable realtime for photos table (for live gallery updates)
ALTER PUBLICATION supabase_realtime ADD TABLE public.photos;
