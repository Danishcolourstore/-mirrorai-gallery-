
-- Add gallery owner fields to events
ALTER TABLE events ADD COLUMN IF NOT EXISTS owner_email text;
ALTER TABLE events ADD COLUMN IF NOT EXISTS owner_name text;
ALTER TABLE events ADD COLUMN IF NOT EXISTS owner_permissions jsonb DEFAULT '{"can_hide_photos": true, "can_download_all": true, "can_see_favorites": true}';

-- Create blog_posts table
CREATE TABLE IF NOT EXISTS public.blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  title text NOT NULL,
  slug text NOT NULL UNIQUE,
  content text,
  cover_url text,
  event_id uuid REFERENCES events(id) ON DELETE SET NULL,
  published boolean DEFAULT false,
  seo_title text,
  seo_description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.blog_posts ENABLE ROW LEVEL SECURITY;

-- RLS policies for blog_posts
CREATE POLICY "Users can manage own blog posts" ON public.blog_posts
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Public can read published blog posts" ON public.blog_posts
  FOR SELECT TO anon, authenticated
  USING (published = true);

CREATE POLICY "Admins can manage all blog posts" ON public.blog_posts
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'));
