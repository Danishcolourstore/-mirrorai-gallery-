
-- Add new columns to events table
ALTER TABLE public.events 
  ADD COLUMN IF NOT EXISTS chapters_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS sneak_peek_active boolean NOT NULL DEFAULT false;

-- Create sneak_peeks table
CREATE TABLE IF NOT EXISTS public.sneak_peeks (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  photo_ids uuid[] NOT NULL DEFAULT '{}',
  message text DEFAULT 'Here''s a little preview of your beautiful day. 🤍 Full gallery coming soon.',
  is_active boolean NOT NULL DEFAULT true,
  downloads_enabled boolean NOT NULL DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.sneak_peeks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Event owners can manage sneak peeks" ON public.sneak_peeks
  FOR ALL USING (EXISTS (SELECT 1 FROM events WHERE events.id = sneak_peeks.event_id AND events.user_id = auth.uid()));

CREATE POLICY "Public can view active sneak peeks" ON public.sneak_peeks
  FOR SELECT USING (is_active = true);

-- Create gallery_chapters table
CREATE TABLE IF NOT EXISTS public.gallery_chapters (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  cover_photo_id uuid,
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.gallery_chapters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Event owners can manage chapters" ON public.gallery_chapters
  FOR ALL USING (EXISTS (SELECT 1 FROM events WHERE events.id = gallery_chapters.event_id AND events.user_id = auth.uid()));

CREATE POLICY "Public can view chapters of published events" ON public.gallery_chapters
  FOR SELECT USING (EXISTS (SELECT 1 FROM events WHERE events.id = gallery_chapters.event_id AND events.is_published = true));

-- Create chapter_photos table
CREATE TABLE IF NOT EXISTS public.chapter_photos (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  chapter_id uuid NOT NULL REFERENCES public.gallery_chapters(id) ON DELETE CASCADE,
  photo_id uuid NOT NULL REFERENCES public.photos(id) ON DELETE CASCADE,
  order_index integer NOT NULL DEFAULT 0
);

ALTER TABLE public.chapter_photos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Event owners can manage chapter photos" ON public.chapter_photos
  FOR ALL USING (EXISTS (
    SELECT 1 FROM gallery_chapters gc 
    JOIN events e ON e.id = gc.event_id 
    WHERE gc.id = chapter_photos.chapter_id AND e.user_id = auth.uid()
  ));

CREATE POLICY "Public can view chapter photos" ON public.chapter_photos
  FOR SELECT USING (EXISTS (
    SELECT 1 FROM gallery_chapters gc 
    JOIN events e ON e.id = gc.event_id 
    WHERE gc.id = chapter_photos.chapter_id AND e.is_published = true
  ));

-- Update existing pixieset layout values to cascade
UPDATE public.events SET gallery_layout = 'cascade' WHERE gallery_layout = 'pixieset';
