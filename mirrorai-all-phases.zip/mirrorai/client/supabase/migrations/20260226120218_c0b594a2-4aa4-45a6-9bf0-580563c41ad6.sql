
-- Retouch logs table
CREATE TABLE IF NOT EXISTS public.retouch_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  photo_id uuid REFERENCES public.photos(id) ON DELETE CASCADE NOT NULL,
  event_id uuid REFERENCES public.events(id) ON DELETE CASCADE NOT NULL,
  retouch_type text NOT NULL,
  session_id text,
  status text NOT NULL DEFAULT 'pending',
  api_response_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.retouch_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert retouch logs" ON public.retouch_logs
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can read retouch logs" ON public.retouch_logs
  FOR SELECT USING (true);

CREATE POLICY "Event owners can manage retouch logs" ON public.retouch_logs
  FOR ALL USING (EXISTS (
    SELECT 1 FROM events WHERE events.id = retouch_logs.event_id AND events.user_id = auth.uid()
  ));

-- Add retouch columns to events
ALTER TABLE public.events
  ADD COLUMN IF NOT EXISTS retouch_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS retouch_limit integer NOT NULL DEFAULT 5;
