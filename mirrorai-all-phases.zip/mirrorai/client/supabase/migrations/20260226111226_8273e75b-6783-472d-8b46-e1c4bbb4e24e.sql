
-- Event views tracking
CREATE TABLE public.event_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  session_id text NOT NULL,
  device_type text NOT NULL DEFAULT 'desktop',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.event_views ENABLE ROW LEVEL SECURITY;

-- Anon can insert (tracking without login)
CREATE POLICY "Anyone can insert event views"
  ON public.event_views FOR INSERT
  WITH CHECK (true);

-- Photographers can read their own event views
CREATE POLICY "Owners can read own event views"
  ON public.event_views FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.events
      WHERE events.id = event_views.event_id
        AND events.user_id = auth.uid()
    )
  );

-- Admins can read all
CREATE POLICY "Admins can read all event views"
  ON public.event_views FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

-- Photo interactions tracking
CREATE TABLE public.photo_interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  photo_id uuid NOT NULL REFERENCES public.photos(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  interaction_type text NOT NULL,
  session_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.photo_interactions ENABLE ROW LEVEL SECURITY;

-- Anon can insert
CREATE POLICY "Anyone can insert photo interactions"
  ON public.photo_interactions FOR INSERT
  WITH CHECK (true);

-- Owners can read
CREATE POLICY "Owners can read own photo interactions"
  ON public.photo_interactions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.events
      WHERE events.id = photo_interactions.event_id
        AND events.user_id = auth.uid()
    )
  );

-- Admins can read all
CREATE POLICY "Admins can read all photo interactions"
  ON public.photo_interactions FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

-- Create indexes for performance
CREATE INDEX idx_event_views_event_id ON public.event_views(event_id);
CREATE INDEX idx_event_views_created_at ON public.event_views(created_at);
CREATE INDEX idx_photo_interactions_event_id ON public.photo_interactions(event_id);
CREATE INDEX idx_photo_interactions_photo_id ON public.photo_interactions(photo_id);
CREATE INDEX idx_photo_interactions_type ON public.photo_interactions(interaction_type);
