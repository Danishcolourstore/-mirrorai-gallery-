
-- Dual Story Mode columns on events
ALTER TABLE events ADD COLUMN IF NOT EXISTS dual_story_enabled boolean DEFAULT false;
ALTER TABLE events ADD COLUMN IF NOT EXISTS person1_name text DEFAULT 'Bride';
ALTER TABLE events ADD COLUMN IF NOT EXISTS person2_name text DEFAULT 'Groom';
ALTER TABLE events ADD COLUMN IF NOT EXISTS person1_face_token text;
ALTER TABLE events ADD COLUMN IF NOT EXISTS person2_face_token text;

-- Venue QR Scans table
CREATE TABLE IF NOT EXISTS public.venue_qr_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  guest_name text,
  guest_phone text,
  selfie_url text,
  face_token text,
  matched_photo_ids text[] DEFAULT '{}',
  scanned_at timestamptz DEFAULT now()
);

ALTER TABLE public.venue_qr_scans ENABLE ROW LEVEL SECURITY;

-- Anyone can insert scans on published events
CREATE POLICY "Anyone can insert QR scans on published events" ON public.venue_qr_scans
  FOR INSERT TO anon, authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM events WHERE events.id = venue_qr_scans.event_id AND events.is_published = true));

-- Event owners can read scans
CREATE POLICY "Event owners can read QR scans" ON public.venue_qr_scans
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM events WHERE events.id = venue_qr_scans.event_id AND events.user_id = auth.uid()));

-- Anyone can read own scans (by id)
CREATE POLICY "Anyone can read QR scans" ON public.venue_qr_scans
  FOR SELECT TO anon, authenticated
  USING (true);

-- Admins full access
CREATE POLICY "Admins can manage QR scans" ON public.venue_qr_scans
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'));
