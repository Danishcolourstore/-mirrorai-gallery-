
-- Add gallery_style to events
ALTER TABLE public.events ADD COLUMN IF NOT EXISTS gallery_style text NOT NULL DEFAULT 'standard';

-- Create studio_profiles table
CREATE TABLE IF NOT EXISTS public.studio_profiles (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL UNIQUE,
  studio_name text NOT NULL DEFAULT 'My Studio',
  tagline text,
  logo_url text,
  instagram text,
  whatsapp text,
  website_url text,
  accent_color text NOT NULL DEFAULT '#1A1A1A',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- RLS
ALTER TABLE public.studio_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own studio profile" ON public.studio_profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own studio profile" ON public.studio_profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own studio profile" ON public.studio_profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Public can read studio profiles" ON public.studio_profiles FOR SELECT USING (true);
