import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { S3Client, PutObjectCommand } from "npm:@aws-sdk/client-s3@3.888.0";
import { getSignedUrl } from "npm:@aws-sdk/s3-request-presigner@3.888.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, PUT, POST, DELETE, OPTIONS",
};

const R2_ENDPOINT = "https://c399000257553435a17d6ff4037df813.r2.cloudflarestorage.com";
const R2_BUCKET = "mirrorai";
const R2_PUBLIC_URL = "https://pub-9a5aa3188af54a99aac7dc284996a4ee.r2.dev";
const R2_REGION = "auto";
const PRESIGN_EXPIRES = 600;

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const accessKey = Deno.env.get("R2_ACCESS_KEY_ID");
    const secretKey = Deno.env.get("R2_SECRET_ACCESS_KEY");
    if (!accessKey || !secretKey) {
      console.error("[r2-presign] R2 credentials missing", {
        hasAccessKey: !!accessKey,
        hasSecretKey: !!secretKey,
      });
      return json({ error: "R2 credentials missing" }, 500);
    }

    const body = await req.json().catch(() => ({} as Record<string, unknown>));
    const path = typeof body.path === "string" ? body.path : "";
    const contentType = typeof body.contentType === "string" ? body.contentType : "application/octet-stream";

    if (!path) {
      return json({ error: "Missing 'path' in request body" }, 400);
    }

    console.log("[r2-presign] Request", { path, contentType, bucket: R2_BUCKET, endpoint: R2_ENDPOINT });

    const s3 = new S3Client({
      region: R2_REGION,
      endpoint: R2_ENDPOINT,
      credentials: {
        accessKeyId: accessKey,
        secretAccessKey: secretKey,
      },
    });

    const command = new PutObjectCommand({
      Bucket: R2_BUCKET,
      Key: path,
      ContentType: contentType,
    });

    const presignedUrl = await getSignedUrl(s3, command, { expiresIn: PRESIGN_EXPIRES });
    const publicUrl = `${R2_PUBLIC_URL}/${path}`;

    console.log("[r2-presign] Success", { path });
    return json({ presignedUrl, publicUrl });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("[r2-presign] Error", { message, error });
    return json({ error: message }, 500);
  }
});
