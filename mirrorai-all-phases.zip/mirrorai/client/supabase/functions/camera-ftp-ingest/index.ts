import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const R2_ENDPOINT = "https://c399000257553435a17d6ff4037df813.r2.cloudflarestorage.com";
const R2_BUCKET = "mirrorai";
const R2_PUBLIC_URL = "https://pub-9a5aa3188af54a99aac7dc284996a4ee.r2.dev";
const R2_REGION = "auto";
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const MAX_RETRIES = 3;

// AWS SigV4 signing helpers
async function hmacSHA256(key: Uint8Array, message: string): Promise<Uint8Array> {
  const cryptoKey = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(message)));
}
async function sha256(data: Uint8Array): Promise<string> {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", data))].map(b => b.toString(16).padStart(2, "0")).join("");
}
function toHex(bytes: Uint8Array): string {
  return [...bytes].map(b => b.toString(16).padStart(2, "0")).join("");
}
async function getSignatureKey(key: string, dateStamp: string, region: string, service: string) {
  const kDate = await hmacSHA256(new TextEncoder().encode("AWS4" + key), dateStamp);
  const kRegion = await hmacSHA256(kDate, region);
  const kService = await hmacSHA256(kRegion, service);
  return hmacSHA256(kService, "aws4_request");
}
async function signRequest(method: string, path: string, body: Uint8Array, contentType: string, accessKey: string, secretKey: string) {
  const now = new Date();
  const amzDate = now.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const dateStamp = amzDate.slice(0, 8);
  const host = R2_ENDPOINT.replace("https://", "");
  const payloadHash = await sha256(body);
  const canonicalHeaders = `content-type:${contentType}\nhost:${host}\nx-amz-content-sha256:${payloadHash}\nx-amz-date:${amzDate}\n`;
  const signedHeaders = "content-type;host;x-amz-content-sha256;x-amz-date";
  const canonicalRequest = [method, path, "", canonicalHeaders, signedHeaders, payloadHash].join("\n");
  const credentialScope = `${dateStamp}/${R2_REGION}/s3/aws4_request`;
  const stringToSign = ["AWS4-HMAC-SHA256", amzDate, credentialScope, await sha256(new TextEncoder().encode(canonicalRequest))].join("\n");
  const signingKey = await getSignatureKey(secretKey, dateStamp, R2_REGION, "s3");
  const signature = toHex(await hmacSHA256(signingKey, stringToSign));
  return {
    "x-amz-date": amzDate, "x-amz-content-sha256": payloadHash, "content-type": contentType, "host": host,
    "Authorization": `AWS4-HMAC-SHA256 Credential=${accessKey}/${credentialScope}, SignedHeaders=${signedHeaders}, Signature=${signature}`,
  };
}

async function uploadToR2WithRetry(objectPath: string, body: Uint8Array, contentType: string, accessKey: string, secretKey: string): Promise<void> {
  let lastError: Error | null = null;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const headers = await signRequest("PUT", objectPath, body, contentType, accessKey, secretKey);
      const r2Response = await fetch(`${R2_ENDPOINT}${objectPath}`, { method: "PUT", headers, body });
      if (!r2Response.ok) {
        const errText = await r2Response.text();
        throw new Error(`R2 upload failed (${r2Response.status}): ${errText}`);
      }
      return; // success
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      console.warn(`R2 upload attempt ${attempt}/${MAX_RETRIES} failed:`, lastError.message);
      if (attempt < MAX_RETRIES) await new Promise(r => setTimeout(r, 1000 * attempt));
    }
  }
  throw lastError!;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const accessKey = Deno.env.get("R2_ACCESS_KEY_ID");
    const secretKey = Deno.env.get("R2_SECRET_ACCESS_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    if (!accessKey || !secretKey) throw new Error("R2 credentials not configured");

    const supabase = createClient(supabaseUrl, serviceKey);
    const formData = await req.formData();
    const file = formData.get("file") as File;
    const eventId = formData.get("event_id") as string;
    const cameraModel = (formData.get("camera_model") as string) || null;
    const ftpPassword = formData.get("ftp_password") as string | null;
    const isTest = formData.get("test") === "true";

    if (!file && !isTest) {
      return new Response(JSON.stringify({ error: "Missing file" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!eventId) {
      return new Response(JSON.stringify({ error: "Missing event_id" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // File size check
    if (file && file.size > MAX_FILE_SIZE) {
      return new Response(JSON.stringify({ error: "File too large. Maximum size is 50MB." }), {
        status: 413, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Authenticate: JWT bearer token OR ftp_password
    let authenticatedUserId: string | null = null;

    const authHeader = req.headers.get("Authorization");
    if (authHeader?.startsWith("Bearer ")) {
      const token = authHeader.replace("Bearer ", "");
      const { data, error } = await supabase.auth.getUser(token);
      if (!error && data?.user) {
        authenticatedUserId = data.user.id;
      }
    }

    if (!authenticatedUserId && ftpPassword) {
      const { data: eventData } = await supabase
        .from("events")
        .select("id, user_id, ftp_password")
        .eq("id", eventId)
        .single();
      if (eventData && eventData.ftp_password === ftpPassword) {
        authenticatedUserId = eventData.user_id;
      } else {
        return new Response(JSON.stringify({ error: "Invalid FTP credentials" }), {
          status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    if (!authenticatedUserId) {
      return new Response(JSON.stringify({ error: "Not authenticated — provide Bearer token or ftp_password" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Test connection mode — just verify credentials
    if (isTest) {
      return new Response(
        JSON.stringify({ success: true, message: "Connection verified" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Only accept JPEG, WebP, PNG
    const allowedTypes = ["image/jpeg", "image/webp", "image/png"];
    if (!allowedTypes.includes(file.type)) {
      return new Response(JSON.stringify({ error: `Unsupported file type: ${file.type}. Only JPEG, WebP, PNG accepted.` }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const ext = file.name?.split(".").pop() ?? "jpg";
    const path = `${authenticatedUserId}/${eventId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
    const body = new Uint8Array(await file.arrayBuffer());
    const objectPath = `/${R2_BUCKET}/${path}`;
    const contentType = file.type || "application/octet-stream";

    // Upload with retry
    await uploadToR2WithRetry(objectPath, body, contentType, accessKey, secretKey);

    const publicUrl = `${R2_PUBLIC_URL}/${path}`;

    // Insert photo record
    const { error: insertError } = await supabase.from("photos").insert({
      event_id: eventId,
      user_id: authenticatedUserId,
      url: publicUrl,
      file_name: file.name || `camera-${Date.now()}.${ext}`,
      file_size: body.length,
    });
    if (insertError) {
      console.error("DB insert error:", insertError);
      return new Response(JSON.stringify({ error: `Database insert failed: ${insertError.message}` }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Update event live stats
    await supabase.from("events").update({
      camera_connected: true,
      camera_model: cameraModel,
      last_photo_at: new Date().toISOString(),
    }).eq("id", eventId);

    // Increment live_photo_count atomically
    await supabase.rpc("increment_live_photo_count", { event_id_param: eventId }).catch((e: any) => {
      console.warn("increment_live_photo_count RPC failed:", e?.message);
    });

    return new Response(
      JSON.stringify({ success: true, photo_url: publicUrl, status: "ok" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Camera ingest error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
