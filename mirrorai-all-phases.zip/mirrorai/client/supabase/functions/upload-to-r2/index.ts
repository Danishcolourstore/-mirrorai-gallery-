import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";
import { S3Client, PutObjectCommand } from "npm:@aws-sdk/client-s3@3.888.0";
import { getSignedUrl } from "npm:@aws-sdk/s3-request-presigner@3.888.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type, x-client-info, apikey, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, PUT, POST, DELETE, OPTIONS",
};

const R2_ENDPOINT = "https://c399000257553435a17d6ff4037df813.r2.cloudflarestorage.com";
const R2_BUCKET = "mirrorai";
const R2_PUBLIC_URL = "https://pub-9a5aa3188af54a99aac7dc284996a4ee.r2.dev";
const R2_REGION = "auto";
const PRESIGN_EXPIRES = 600;

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function sanitizeFileName(fileName: string) {
  const trimmed = fileName.trim();
  if (!trimmed) return "photo.jpg";
  return trimmed.replace(/[^a-zA-Z0-9._-]/g, "_");
}

function buildObjectKey(userId: string, eventId: string, fileName: string) {
  const safe = sanitizeFileName(fileName);
  const ext = safe.includes(".") ? safe.split(".").pop() : "jpg";
  return `${userId}/${eventId}/${Date.now()}-${crypto.randomUUID()}.${ext}`;
}

async function requireUserId(authHeader: string): Promise<string> {
  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY");

  if (!supabaseUrl || !supabaseAnonKey) {
    console.error("[upload-to-r2] Missing backend auth env vars", {
      hasUrl: !!supabaseUrl,
      hasAnon: !!supabaseAnonKey,
    });
    throw new Error("Server auth configuration missing");
  }

  const supabase = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: { Authorization: authHeader } },
  });

  const token = authHeader.replace("Bearer ", "");
  const { data, error } = await supabase.auth.getClaims(token);
  if (error || !data?.claims?.sub) {
    console.error("[upload-to-r2] JWT validation failed", { error: error?.message });
    throw new Error("Unauthorized");
  }

  return data.claims.sub;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const accessKey = Deno.env.get("R2_ACCESS_KEY_ID");
    const secretKey = Deno.env.get("R2_SECRET_ACCESS_KEY");
    if (!accessKey || !secretKey) {
      console.error("[upload-to-r2] R2 credentials missing", {
        hasAccessKey: !!accessKey,
        hasSecretKey: !!secretKey,
      });
      return json({ error: "R2 credentials missing" }, 500);
    }

    const userId = await requireUserId(authHeader);
    const body = await req.json().catch(() => ({} as Record<string, unknown>));

    if (body.ping === true) {
      console.log("[upload-to-r2] ping ok", { userId });
      return json({ ok: true });
    }

    const fileName = typeof body.fileName === "string" ? body.fileName : "";
    const contentType = typeof body.contentType === "string" ? body.contentType : "application/octet-stream";
    const eventId = typeof body.eventId === "string" ? body.eventId : "";

    if (!fileName || !eventId) {
      return json({ error: "Missing fileName or eventId" }, 400);
    }

    console.log("[upload-to-r2] presign requested", {
      userId,
      eventId,
      fileName,
      contentType,
      bucket: R2_BUCKET,
      endpoint: R2_ENDPOINT,
    });

    const key = buildObjectKey(userId, eventId, fileName);

    const s3 = new S3Client({
      region: R2_REGION,
      endpoint: R2_ENDPOINT,
      credentials: {
        accessKeyId: accessKey,
        secretAccessKey: secretKey,
      },
    });

    const command = new PutObjectCommand({
      Bucket: R2_BUCKET,
      Key: key,
      ContentType: contentType,
    });

    const presignedUrl = await getSignedUrl(s3, command, { expiresIn: PRESIGN_EXPIRES });
    const publicUrl = `${R2_PUBLIC_URL}/${key}`;

    console.log("[upload-to-r2] presign generated", {
      userId,
      key,
      expiresIn: PRESIGN_EXPIRES,
      publicUrl,
    });

    return json({ presignedUrl, publicUrl, path: key });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    console.error("[upload-to-r2] fatal error", { message, error });

    if (message === "Unauthorized") {
      return json({ error: "Unauthorized" }, 401);
    }

    return json({ error: message }, 500);
  }
});
