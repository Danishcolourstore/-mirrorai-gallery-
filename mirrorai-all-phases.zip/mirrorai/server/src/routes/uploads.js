
export function uploadsRoute(app){
  app.post('/uploads/presign', (req,res)=>{
    res.status(501).json({message:'R2 presign not yet configured'});
  });
}
