
export function paymentsRoute(app){
  app.post('/payments/create', (req,res)=>{
    res.status(501).json({message:'Payments disabled in dev'});
  });
}
