import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_, res) => {
  res.json({ status: 'MirrorAI Server Running' });
});

app.listen(4000, () => {
  console.log('MirrorAI backend running on http://localhost:4000');
});
